package com.basit.dosya

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.basit.dosya.databinding.FragmentFolderBinding
import java.io.File
import java.util.Locale

/** Son dosyaları listeler. Basit salt-okunur liste; FolderFragment'ın bağlam menüsü yok. */
class RecentFilesFragment : Fragment() {

    companion object {
        fun newInstance(files: List<File>) = RecentFilesFragment().apply {
            arguments = Bundle().apply {
                putStringArrayList("files", ArrayList(files.map { it.absolutePath }))
            }
        }
    }

    private var _b: FragmentFolderBinding? = null
    private val b get() = _b!!
    private val selection = LinkedHashSet<String>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, s: Bundle?): View {
        _b = FragmentFolderBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, s: Bundle?) {
        super.onViewCreated(view, s)
        val main = requireActivity() as MainActivity
        val paths = arguments?.getStringArrayList("files") ?: return
        val files = paths.map { File(it) }.filter { it.exists() }

        val adapter = FileAdapter(selection, onClick = { f ->
            val ext = f.extension.lowercase(Locale.ROOT)
            when {
                ext in MainActivity.TEXT_EXTS -> main.openTextFile(f)
                ext in MediaViewActivity.IMAGE_EXTS -> MediaViewActivity.open(requireContext(), f.absolutePath)
                ext in MediaViewActivity.VIDEO_EXTS -> MediaViewActivity.open(requireContext(), f.absolutePath)
                ext == "pdf" -> PdfViewActivity.open(requireContext(), f.absolutePath)
                else -> main.openTextFile(f)
            }
        }, onLong = {})

        b.rv.layoutManager = LinearLayoutManager(requireContext())
        b.rv.addItemDecoration(DividerItemDecoration(requireContext(), DividerItemDecoration.VERTICAL))
        b.rv.adapter = adapter
        adapter.items = files
        b.tvEmpty.text = "Son dosya bulunamadı"
        b.tvEmpty.visibility = if (files.isEmpty()) View.VISIBLE else View.GONE
        b.rv.visibility = if (files.isEmpty()) View.GONE else View.VISIBLE

        // Bağlam barları gizli
        b.ctxBarNormal.visibility = View.GONE
        b.ctxBarPaste.visibility = View.GONE
    }

    override fun onDestroyView() { _b = null; super.onDestroyView() }
}
