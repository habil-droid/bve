package com.basit.dosya

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.os.IBinder
import android.view.View
import android.webkit.MimeTypeMap
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.basit.dosya.databinding.ActivityBrowseBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BrowseActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PATH = "path"
        const val EXTRA_ROOT_LABEL = "root_label"
        const val EXTRA_BIN = "bin_mode"

        fun open(ctx: Context, dir: File, rootLabel: String = dir.name, bin: Boolean = false) {
            ctx.startActivity(Intent(ctx, BrowseActivity::class.java).apply {
                putExtra(EXTRA_PATH, dir.absolutePath)
                putExtra(EXTRA_ROOT_LABEL, rootLabel)
                putExtra(EXTRA_BIN, bin)
            })
        }
    }

    private lateinit var b: ActivityBrowseBinding
    private lateinit var adapter: FileAdapter

    private val selection = LinkedHashSet<String>()
    private var currentDir: File? = null
    private lateinit var rootDir: File
    private lateinit var rootLabel: String
    private var binMode = false

    private var musicSvc: MusicService? = null
    private val musicConn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, s: IBinder?) {
            musicSvc = (s as MusicService.LocalBinder).get()
            musicSvc?.addCb(::refreshPlayer)
            refreshPlayer()
        }
        override fun onServiceDisconnected(n: ComponentName?) { musicSvc = null }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityBrowseBinding.inflate(layoutInflater)
        setContentView(b.root)

        val path = intent.getStringExtra(EXTRA_PATH) ?: run { finish(); return }
        rootLabel = intent.getStringExtra(EXTRA_ROOT_LABEL) ?: "Bellek"
        binMode = intent.getBooleanExtra(EXTRA_BIN, false)
        rootDir = File(path)
        currentDir = rootDir

        adapter = FileAdapter(selection, ::onItemClick, ::onItemLong)
        b.rv.layoutManager = LinearLayoutManager(this)
        b.rv.addItemDecoration(DividerItemDecoration(this, DividerItemDecoration.VERTICAL))
        b.rv.adapter = adapter

        setupContextBars()

        b.btnNewWindow.setOnClickListener {
            val dir = currentDir ?: return@setOnClickListener
            startActivity(Intent(this, BrowseActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
                putExtra(EXTRA_PATH, dir.absolutePath)
                putExtra(EXTRA_ROOT_LABEL, rootLabel)
                putExtra(EXTRA_BIN, binMode)
            })
        }

        onBackPressedDispatcher.addCallback(this) { handleBack() }

        loadDir(rootDir)
    }

    override fun onResume() {
        super.onResume()
        MusicService.instance?.let {
            bindService(Intent(this, MusicService::class.java), musicConn, Context.BIND_AUTO_CREATE)
        }
        refreshPlayer()
    }

    override fun onPause() {
        musicSvc?.removeCb(::refreshPlayer)
        try { unbindService(musicConn) } catch (_: Exception) {}
        musicSvc = null
        super.onPause()
    }

    // ---------- navigation ----------

    private fun handleBack() {
        when {
            selection.isNotEmpty() -> clearSel()
            currentDir != rootDir -> {
                currentDir?.parentFile?.let { loadDir(it) }
            }
            else -> finish()
        }
    }

    private fun loadDir(dir: File) {
        currentDir = dir
        buildBreadcrumb()
        lifecycleScope.launch {
            val files = withContext(Dispatchers.IO) {
                if (binMode) {
                    dir.listFiles()?.filter { it.name != "index.json" }
                        ?.sortedWith(NaturalSort.fileComparator) ?: emptyList()
                } else {
                    dir.listFiles()?.sortedWith(NaturalSort.fileComparator) ?: emptyList()
                }
            }
            adapter.items = files
            b.rv.visibility = if (files.isEmpty()) View.GONE else View.VISIBLE
            b.tvEmpty.visibility = if (files.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    // ---------- breadcrumb ----------

    private fun buildBreadcrumb() {
        b.breadcrumbBar.removeAllViews()
        val dir = currentDir ?: return

        // Collect path segments from rootDir to currentDir
        val segments = mutableListOf<Pair<String, File>>() // label, dir
        var f: File? = dir
        while (f != null) {
            val label = if (f.absolutePath == rootDir.absolutePath) rootLabel else f.name
            segments.add(0, label to f)
            if (f.absolutePath == rootDir.absolutePath) break
            f = f.parentFile
        }

        val d = resources.displayMetrics.density
        segments.forEachIndexed { i, (label, target) ->
            if (i > 0) {
                val sep = TextView(this).apply {
                    text = " › "
                    textSize = 12f
                    setTextColor(ContextCompat.getColor(this@BrowseActivity, R.color.text_dim))
                }
                b.breadcrumbBar.addView(sep)
            }
            val btn = TextView(this).apply {
                text = label
                textSize = 13f
                val isCurrent = i == segments.size - 1
                setTextColor(ContextCompat.getColor(
                    this@BrowseActivity,
                    if (isCurrent) R.color.text_main else R.color.accent
                ))
                setTypeface(null, if (isCurrent) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
                setPadding((4 * d).toInt(), (4 * d).toInt(), (4 * d).toInt(), (4 * d).toInt())
                background = ContextCompat.getDrawable(this@BrowseActivity, R.drawable.bg_breadcrumb_btn)
                isClickable = !isCurrent
                isFocusable = !isCurrent
                if (!isCurrent) setOnClickListener { loadDir(target) }
            }
            b.breadcrumbBar.addView(btn)
        }
        // scroll to end
        b.breadcrumbScroll.post { b.breadcrumbScroll.fullScroll(View.FOCUS_RIGHT) }
    }

    // ---------- item interaction ----------

    private fun onItemClick(f: File) {
        if (selection.isNotEmpty()) { toggleSel(f); return }
        if (f.isDirectory) { loadDir(f); return }
        val ext = f.extension.lowercase(Locale.ROOT)
        when {
            ext in MainActivity.TEXT_EXTS -> {
                startActivity(Intent(this, ViewerActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
                    putExtra("path", f.absolutePath)
                })
            }
            ext in setOf("mp3", "wav", "m4a", "ogg", "flac", "aac", "opus") -> {
                playMusic(f)
            }
            ext == "zip" -> zipDialog(f)
            else -> openWith(f)
        }
    }

    private fun onItemLong(f: File) {
        toggleSel(f)
    }

    private fun toggleSel(f: File) {
        val p = f.absolutePath
        if (selection.contains(p)) selection.remove(p) else selection.add(p)
        if (selection.isEmpty()) clearSel() else showCtxBar()
        adapter.notifyDataSetChanged()
    }

    private fun clearSel() {
        selection.clear()
        hideCtxBars()
        adapter.notifyDataSetChanged()
    }

    private fun selected(): List<File> = adapter.items.filter { selection.contains(it.absolutePath) }

    // ---------- context bars ----------

    private fun setupContextBars() {
        listOf(b.ctxDel, b.ctxDel2).forEach { it.setOnClickListener { doDelete() } }
        listOf(b.ctxRename, b.ctxRename2).forEach { it.setOnClickListener { doRename() } }
        listOf(b.ctxZip, b.ctxZip2).forEach { it.setOnClickListener { doZip() } }
        listOf(b.ctxShare, b.ctxShare2).forEach { it.setOnClickListener { doShare() } }
        b.ctxCut.setOnClickListener { doCut() }
        b.ctxCopy.setOnClickListener { doCopy() }
        b.ctxPaste.setOnClickListener { doPaste() }
    }

    private fun showCtxBar() {
        val paste = AppClipboard.hasContent()
        b.ctxBarNormal.visibility = if (!paste) View.VISIBLE else View.GONE
        b.ctxBarPaste.visibility = if (paste) View.VISIBLE else View.GONE
    }

    private fun hideCtxBars() {
        b.ctxBarNormal.visibility = View.GONE
        b.ctxBarPaste.visibility = View.GONE
    }

    // ---------- operations ----------

    private fun doDelete() {
        val files = selected(); if (files.isEmpty()) return
        if (binMode) {
            MaterialAlertDialogBuilder(this)
                .setTitle("Kalıcı sil")
                .setMessage("${files.size} öğe geri alınamaz biçimde silinecek.")
                .setPositiveButton("Sil") { _, _ ->
                    val dlg = progress("Siliniyor…")
                    lifecycleScope.launch {
                        withContext(Dispatchers.IO) { files.forEach { FileOps.permDelete(it) } }
                        dlg.dismiss(); clearSel(); loadDir(currentDir!!)
                    }
                }
                .setNegativeButton("İptal", null).show()
        } else {
            val dlg = progress("Çöp kutusuna taşınıyor…")
            lifecycleScope.launch {
                withContext(Dispatchers.IO) { files.forEach { FileOps.toBin(it); scan(it) } }
                dlg.dismiss(); clearSel(); loadDir(currentDir!!)
            }
        }
    }

    private fun doRename() {
        val f = selected().singleOrNull() ?: return toast("Tek öğe seç")
        val et = EditText(this).apply { setText(f.name); setSelection(0, f.name.lastIndexOf('.').takeIf { it > 0 } ?: f.name.length) }
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 16, 48, 0); addView(et) }
        MaterialAlertDialogBuilder(this)
            .setTitle("Yeniden adlandır")
            .setView(wrap)
            .setPositiveButton("Tamam") { _, _ ->
                val name = et.text.toString().trim()
                if (name.isEmpty() || name.contains('/')) return@setPositiveButton toast("Geçersiz ad")
                val target = File(f.parentFile, name)
                if (target.exists()) return@setPositiveButton toast("Bu adla dosya zaten var")
                if (f.renameTo(target)) { scan(f); scan(target); clearSel(); loadDir(currentDir!!) }
                else toast("Adlandırılamadı")
            }
            .setNegativeButton("İptal", null).show()
    }

    private fun doZip() {
        val files = selected(); if (files.isEmpty()) return
        val destDir = currentDir ?: return
        val name = "arsiv_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) + ".zip"
        val destZip = FileOps.uniqueIn(destDir, name)
        val dlg = progress("Sıkıştırılıyor…")
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) { FileOps.zipFiles(files, destZip) }
            dlg.dismiss()
            toast(if (ok) "Oluşturuldu: ${destZip.name}" else "Sıkıştırılamadı")
            scan(destZip); clearSel(); loadDir(destDir)
        }
    }

    private fun doShare() {
        val files = selected().filter { it.isFile }
        if (files.isEmpty()) return toast("Klasör paylaşmak için önce ZIP")
        try {
            val i = if (files.size == 1) {
                Intent(Intent.ACTION_SEND).apply {
                    type = mimeOf(files[0]); putExtra(Intent.EXTRA_STREAM, uriFor(files[0]))
                }
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                    type = "*/*"; putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(files.map { uriFor(it) }))
                }
            }
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "Paylaş"))
            clearSel()
        } catch (_: Exception) { toast("Paylaşılamadı") }
    }

    private fun doCut() {
        val files = selected(); if (files.isEmpty()) return
        AppClipboard.set(files, cut = true)
        toast("${files.size} öğe kesildi — yapıştırılacak klasöre git")
        clearSel()
    }

    private fun doCopy() {
        val files = selected(); if (files.isEmpty()) return
        AppClipboard.set(files, cut = false)
        toast("${files.size} öğe kopyalandı — yapıştırılacak klasöre git")
        clearSel()
    }

    private fun doPaste() {
        val cb = AppClipboard.files; val isMove = AppClipboard.isCut
        val dest = currentDir ?: return
        val dlg = progress(if (isMove) "Taşınıyor…" else "Kopyalanıyor…")
        lifecycleScope.launch {
            var ok = 0
            withContext(Dispatchers.IO) {
                for (f in cb) {
                    val done = if (isMove) FileOps.moveInto(f, dest) else FileOps.copyInto(f, dest)
                    if (done) ok++
                    scan(f); scan(File(dest, f.name))
                }
            }
            dlg.dismiss()
            AppClipboard.clear()
            toast("$ok öğe tamam")
            clearSel(); loadDir(dest)
        }
    }

    private fun zipDialog(f: File) {
        MaterialAlertDialogBuilder(this)
            .setTitle(f.name)
            .setItems(arrayOf("Buraya ayıkla", "Şununla aç")) { _, i ->
                if (i == 0) {
                    val dest = FileOps.uniqueIn(f.parentFile ?: return@setItems, f.nameWithoutExtension)
                    val dlg = progress("Ayıklanıyor…")
                    lifecycleScope.launch {
                        val ok = withContext(Dispatchers.IO) { FileOps.unzip(f, dest) }
                        dlg.dismiss()
                        toast(if (ok) "Ayıklandı" else "Ayıklanamadı")
                        loadDir(currentDir!!)
                    }
                } else openWith(f)
            }.show()
    }

    // ---------- music ----------

    private fun playMusic(file: File) {
        val dir = file.parentFile ?: return
        val playlist = dir.listFiles()
            ?.filter { it.extension.lowercase(Locale.ROOT) in setOf("mp3", "wav", "m4a", "ogg", "flac", "aac", "opus") }
            ?.sortedWith(NaturalSort.fileComparator) ?: return
        val idx = playlist.indexOfFirst { it.absolutePath == file.absolutePath }
        val svc = Intent(this, MusicService::class.java)
        startForegroundService(svc)
        bindService(svc, object : ServiceConnection {
            override fun onServiceConnected(n: ComponentName?, s: IBinder?) {
                val ms = (s as MusicService.LocalBinder).get()
                ms.play(playlist, if (idx >= 0) idx else 0)
                try { unbindService(this) } catch (_: Exception) {}
            }
            override fun onServiceDisconnected(n: ComponentName?) {}
        }, Context.BIND_AUTO_CREATE)
    }

    private fun refreshPlayer() {
        val svc = MusicService.instance
        if (svc == null || !svc.isPlaying && svc.currentFile() == null) {
            b.playerBar.visibility = View.GONE; return
        }
        b.playerBar.visibility = View.VISIBLE
        b.tvNowPlaying.text = svc.currentFile()?.nameWithoutExtension ?: ""
        b.btnPlayerPlayPause.setImageResource(if (svc.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        b.btnPlayerMode.text = if (svc.playMode == MusicService.MODE_REPEAT_ONE) "1×" else "Sıra"
    }

    private fun bindPlayerButtons() {
        b.btnPlayerPlayPause.setOnClickListener { MusicService.instance?.togglePlayPause() }
        b.btnPlayerStop.setOnClickListener { MusicService.instance?.stop(); b.playerBar.visibility = View.GONE }
        b.btnPlayerPrev.setOnClickListener { MusicService.instance?.prev(); refreshPlayer() }
        b.btnPlayerNext.setOnClickListener { MusicService.instance?.next(); refreshPlayer() }
        b.btnPlayerMode.setOnClickListener {
            val svc = MusicService.instance ?: return@setOnClickListener
            svc.playMode = if (svc.playMode == MusicService.MODE_REPEAT_ONE)
                MusicService.MODE_SEQUENTIAL else MusicService.MODE_REPEAT_ONE
            refreshPlayer()
        }
    }

    // ---------- helpers ----------

    private fun uriFor(f: File): Uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
    private fun mimeOf(f: File) = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase(Locale.ROOT)) ?: "*/*"

    private fun openWith(f: File) {
        try {
            startActivity(Intent.createChooser(
                Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uriFor(f), mimeOf(f))
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }, "Şununla aç"
            ))
        } catch (_: Exception) { toast("Açacak uygulama bulunamadı") }
    }

    private fun scan(f: File) = MediaScannerConnection.scanFile(this, arrayOf(f.absolutePath), null, null)

    private fun progress(msg: String) = MaterialAlertDialogBuilder(this)
        .setView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(48, 40, 48, 40)
            addView(ProgressBar(this@BrowseActivity))
            addView(TextView(this@BrowseActivity).apply { text = msg; setPadding(28, 8, 0, 0); textSize = 14f })
        }).setCancelable(false).show()

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onStart() { super.onStart(); bindPlayerButtons() }
}
