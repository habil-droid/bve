package com.basit.dosya

import android.os.Environment
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Dosya işlemleri: kopyala/taşı/sıkıştır/ayıkla + geri dönüşüm kutusu. */
object FileOps {

    // ---------- biçimleme ----------

    fun fmtSize(b: Long): String {
        if (b < 1024) return "$b B"
        val kb = b / 1024.0
        if (kb < 1024) return String.format("%.1f kB", kb).replace('.', ',')
        val mb = kb / 1024.0
        if (mb < 1024) return String.format("%.1f MB", mb).replace('.', ',')
        val gb = mb / 1024.0
        return String.format("%.1f GB", gb).replace('.', ',')
    }

    fun sizeOf(f: File): Long {
        if (f.isFile) return f.length()
        var t = 0L
        f.listFiles()?.forEach { t += sizeOf(it) }
        return t
    }

    // ---------- kopyala / taşı ----------

    fun uniqueIn(destDir: File, name: String): File {
        var f = File(destDir, name)
        if (!f.exists()) return f
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (f.exists()) {
            f = File(destDir, "$base ($i)$ext")
            i++
        }
        return f
    }

    private fun copyFile(src: File, dest: File): Boolean = try {
        FileInputStream(src).use { inp ->
            FileOutputStream(dest).use { out -> inp.copyTo(out, 64 * 1024) }
        }
        dest.setLastModified(src.lastModified())
        true
    } catch (_: Exception) {
        dest.delete(); false
    }

    /** src'yi destDir içine kopyalar (klasörse özyinelemeli). Çakışmada " (1)" eklenir. */
    fun copyInto(src: File, destDir: File): Boolean {
        val target = uniqueIn(destDir, src.name)
        return if (src.isDirectory) {
            if (!target.mkdirs()) return false
            var ok = true
            src.listFiles()?.forEach { child ->
                if (child.isDirectory) {
                    if (!copyDirInto(child, target)) ok = false
                } else {
                    if (!copyFile(child, File(target, child.name))) ok = false
                }
            }
            ok
        } else copyFile(src, target)
    }

    private fun copyDirInto(srcDir: File, destParent: File): Boolean {
        val target = File(destParent, srcDir.name)
        if (!target.exists() && !target.mkdirs()) return false
        var ok = true
        srcDir.listFiles()?.forEach { child ->
            if (child.isDirectory) {
                if (!copyDirInto(child, target)) ok = false
            } else {
                if (!copyFile(child, File(target, child.name))) ok = false
            }
        }
        return ok
    }

    /** Önce renameTo dener (aynı bölüm), olmazsa kopyala+sil. */
    fun moveInto(src: File, destDir: File): Boolean {
        val target = uniqueIn(destDir, src.name)
        if (src.renameTo(target)) return true
        return if (copyInto(src, destDir)) src.deleteRecursively() else false
    }

    // ---------- zip ----------

    fun zipFiles(files: List<File>, destZip: File): Boolean = try {
        ZipOutputStream(FileOutputStream(destZip)).use { zos ->
            for (root in files) addToZip(zos, root, root.parentFile?.absolutePath ?: "")
        }
        true
    } catch (_: Exception) {
        destZip.delete(); false
    }

    private fun addToZip(zos: ZipOutputStream, f: File, basePath: String) {
        val rel = f.absolutePath.removePrefix(basePath).trimStart('/')
        if (f.isDirectory) {
            zos.putNextEntry(ZipEntry("$rel/"))
            zos.closeEntry()
            f.listFiles()?.forEach { addToZip(zos, it, basePath) }
        } else {
            zos.putNextEntry(ZipEntry(rel))
            FileInputStream(f).use { it.copyTo(zos, 64 * 1024) }
            zos.closeEntry()
        }
    }

    /** Zip-slip korumalı ayıklama. */
    fun unzip(zip: File, destDir: File): Boolean = try {
        if (!destDir.exists()) destDir.mkdirs()
        val destCanon = destDir.canonicalPath
        ZipInputStream(FileInputStream(zip)).use { zis ->
            var e: ZipEntry? = zis.nextEntry
            while (e != null) {
                val out = File(destDir, e.name)
                if (!out.canonicalPath.startsWith(destCanon)) {
                    e = zis.nextEntry; continue
                }
                if (e.isDirectory) out.mkdirs()
                else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { zis.copyTo(it, 64 * 1024) }
                }
                e = zis.nextEntry
            }
        }
        true
    } catch (_: Exception) {
        false
    }

    // ---------- geri dönüşüm kutusu ----------

    fun binDir(): File {
        val d = File(Environment.getExternalStorageDirectory(), ".geri_donusum")
        if (!d.exists()) d.mkdirs()
        return d
    }

    private fun indexFile() = File(binDir(), "index.json")

    private fun indexLoad(): JSONObject = try {
        val f = indexFile()
        if (f.exists()) JSONObject(f.readText()) else JSONObject()
    } catch (_: Exception) {
        JSONObject()
    }

    private fun indexSave(o: JSONObject) {
        try { indexFile().writeText(o.toString()) } catch (_: Exception) {}
    }

    /** Dosyayı kutuya taşır; orijinal yolu index'e yazar. */
    fun toBin(f: File): Boolean {
        val bin = binDir()
        val target = uniqueIn(bin, f.name)
        val moved = if (f.renameTo(target)) true
        else if (copyInto(f, bin)) f.deleteRecursively() else false
        if (!moved) return false
        val idx = indexLoad()
        idx.put(target.name, JSONObject().apply {
            put("orig", f.absolutePath)
            put("time", System.currentTimeMillis())
        })
        indexSave(idx)
        return true
    }

    fun binOriginal(binName: String): String? =
        indexLoad().optJSONObject(binName)?.optString("orig")?.takeIf { it.isNotEmpty() }

    /** Kutudaki öğeyi orijinal yerine geri taşır. */
    fun restore(binFile: File): Boolean {
        val idx = indexLoad()
        val orig = idx.optJSONObject(binFile.name)?.optString("orig")
        val destDir: File = if (!orig.isNullOrEmpty()) {
            File(orig).parentFile ?: Environment.getExternalStorageDirectory()
        } else Environment.getExternalStorageDirectory()
        if (!destDir.exists()) destDir.mkdirs()
        val ok = moveInto(binFile, destDir)
        if (ok) { idx.remove(binFile.name); indexSave(idx) }
        return ok
    }

    /** Kutudan kalıcı silme. */
    fun permDelete(binFile: File): Boolean {
        val ok = binFile.deleteRecursively()
        if (ok) {
            val idx = indexLoad(); idx.remove(binFile.name); indexSave(idx)
        }
        return ok
    }

    fun emptyBin(): Boolean {
        var ok = true
        binDir().listFiles()?.forEach {
            if (it.name != "index.json" && !it.deleteRecursively()) ok = false
        }
        indexSave(JSONObject())
        return ok
    }
}
