package com.basit.dosya

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.basit.dosya.databinding.ActivityViewerBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File

/**
 * Çok sekmeli metin görüntüleyici — ayrı Android görevi.
 * Üst: Ana Sayfa | Adres çubuğu (tam yol) | Sekme sayısı
 * Alt: Geri Al | Tümünü Seç | Tümünü Kopyala | Kaydet
 */
class ViewerActivity : AppCompatActivity() {

    private lateinit var b: ActivityViewerBinding

    private data class Tab(val path: String, var text: String? = null, var dirty: Boolean = false) {
        val name: String get() = File(path).name
    }

    private val tabs = ArrayList<Tab>()
    private var active = -1
    private var loading = false
    private val prefs by lazy { getSharedPreferences("viewer", MODE_PRIVATE) }

    // Geri alma (undo) yığını — her sekme kendi yığınını yönetir
    private val undoStackMap = HashMap<String, ArrayDeque<String>>()
    private val undoHandler = Handler(Looper.getMainLooper())
    private val saveStateRunnable = Runnable {
        val t = tabs.getOrNull(active) ?: return@Runnable
        val current = b.etBody.text.toString()
        val stack = undoStackMap.getOrPut(t.path) { ArrayDeque() }
        if (stack.lastOrNull() != current) {
            stack.addLast(current)
            if (stack.size > 40) stack.removeFirst()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityViewerBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.etBody.setHorizontallyScrolling(false)

        // Üst çubuk butonları
        b.btnHome.setOnClickListener {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            )
        }
        b.btnTabCount.setOnClickListener { showTabSwitcher() }

        // Alt eylem çubuğu
        b.btnUndo.setOnClickListener { doUndo() }
        b.btnSelectAll.setOnClickListener { b.etBody.selectAll() }
        b.btnCopyAll.setOnClickListener { copyToClipboard(b.etBody.text.toString()) }
        b.btnSave.setOnClickListener { saveActive() }

        // Arama (gizli — etBody uzun basınca açılabilir)
        b.btnFindNext.setOnClickListener { findNext() }
        b.btnFindClose.setOnClickListener { b.findRow.visibility = View.GONE }

        b.etBody.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, c: Int, d: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, c: Int, d: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (loading) return
                val t = tabs.getOrNull(active) ?: return
                if (!t.dirty) { t.dirty = true; rebuildTabCount() }
                // Undo yığınına 600ms gecikmeyle kaydet
                undoHandler.removeCallbacks(saveStateRunnable)
                undoHandler.postDelayed(saveStateRunnable, 600)
            }
        })

        onBackPressedDispatcher.addCallback(this,
            object : androidx.activity.OnBackPressedCallback(true) {
                override fun handleOnBackPressed() { attemptExit() }
            })

        restoreTabs()
        intent?.getStringExtra("path")?.let { addTab(it) }
        if (tabs.isEmpty()) { finish(); return }
        if (active !in tabs.indices) active = tabs.size - 1
        activate(active)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.getStringExtra("path")?.let { addTab(it) }
    }

    override fun onPause() { super.onPause(); persistTabs() }

    // ---------- sekme yönetimi ----------

    private fun restoreTabs() {
        try {
            val arr = JSONArray(prefs.getString("tabs", "[]"))
            for (i in 0 until arr.length()) {
                val p = arr.getString(i)
                if (File(p).exists()) tabs.add(Tab(p))
            }
            active = prefs.getInt("active", tabs.size - 1)
        } catch (_: Exception) {}
    }

    private fun persistTabs() {
        val arr = JSONArray()
        tabs.forEach { arr.put(it.path) }
        prefs.edit().putString("tabs", arr.toString()).putInt("active", active).apply()
    }

    private fun addTab(path: String) {
        val ex = tabs.indexOfFirst { it.path == path }
        if (ex >= 0) { activate(ex); return }
        if (!File(path).exists()) { toast("Dosya bulunamadı"); return }
        tabs.add(Tab(path))
        activate(tabs.size - 1)
        persistTabs()
    }

    private fun stashCurrent() {
        val t = tabs.getOrNull(active) ?: return
        if (t.text != null) t.text = b.etBody.text.toString()
    }

    private fun activate(idx: Int) {
        if (idx !in tabs.indices) return
        stashCurrent()
        active = idx
        val t = tabs[idx]
        b.tvPath.text = t.path
        rebuildTabCount()
        if (t.text != null) {
            loading = true; b.etBody.setText(t.text); loading = false
        } else {
            lifecycleScope.launch {
                val content = withContext(Dispatchers.IO) {
                    try { File(t.path).readText() } catch (_: Exception) { null }
                }
                if (content == null) { toast("Okunamadı"); doClose(idx); return@launch }
                t.text = content
                // Undo yığınını başlat
                undoStackMap.getOrPut(t.path) { ArrayDeque() }.also {
                    if (it.isEmpty()) it.addLast(content)
                }
                if (active == idx) {
                    loading = true; b.etBody.setText(content); b.etBody.setSelection(0); loading = false
                }
            }
        }
        persistTabs()
    }

    private fun rebuildTabCount() {
        b.btnTabCount.text = "${tabs.size}"
        val hasDirty = tabs.any { it.dirty }
        b.btnTabCount.setTextColor(
            ContextCompat.getColor(this, if (hasDirty) R.color.danger else R.color.accent)
        )
    }

    private fun showTabSwitcher() {
        if (tabs.size == 1) {
            toast(tabs[0].name)
            return
        }
        val names = tabs.mapIndexed { i, t ->
            buildString {
                if (t.dirty) append("● ")
                append(t.name)
                if (i == active) append(" ✓")
            }
        }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Açık dosyalar (${tabs.size})")
            .setItems(names) { _, i -> activate(i) }
            .setNegativeButton("Kapat aktifi") { _, _ -> closeTabAt(active) }
            .show()
    }

    private fun closeTabAt(idx: Int) {
        stashCurrent()
        val t = tabs.getOrNull(idx) ?: return
        if (t.dirty) {
            MaterialAlertDialogBuilder(this)
                .setTitle(t.name)
                .setMessage("Kaydedilmemiş değişiklikler.")
                .setPositiveButton("Kaydet ve kapat") { _, _ -> saveTab(t) { doClose(idx) } }
                .setNegativeButton("Kapat") { _, _ -> doClose(idx) }
                .setNeutralButton("İptal", null)
                .show()
        } else doClose(idx)
    }

    private fun doClose(idx: Int) {
        if (idx !in tabs.indices) return
        undoStackMap.remove(tabs[idx].path)
        tabs.removeAt(idx)
        if (tabs.isEmpty()) { persistTabs(); finish(); return }
        active = when {
            idx < active -> active - 1
            idx == active -> (idx - 1).coerceAtLeast(0)
            else -> active
        }
        loading = true; b.etBody.setText(tabs[active].text ?: ""); loading = false
        b.tvPath.text = tabs[active].path
        if (tabs[active].text == null) activate(active) else rebuildTabCount()
        persistTabs()
    }

    private fun attemptExit() {
        stashCurrent()
        val dirty = tabs.filter { it.dirty }
        if (dirty.isEmpty()) { persistTabs(); finish(); return }
        MaterialAlertDialogBuilder(this)
            .setTitle("Kaydedilmemiş değişiklikler")
            .setMessage("${dirty.size} dosyada kaydedilmemiş değişiklik var.")
            .setPositiveButton("Tümünü kaydet") { _, _ ->
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) {
                        dirty.forEach { try { File(it.path).writeText(it.text ?: "") } catch (_: Exception) {} }
                    }
                    persistTabs(); finish()
                }
            }
            .setNegativeButton("Kaydetme") { _, _ -> persistTabs(); finish() }
            .setNeutralButton("İptal", null)
            .show()
    }

    // ---------- eylemler ----------

    private fun saveActive() {
        stashCurrent()
        val t = tabs.getOrNull(active) ?: return
        saveTab(t) { toast("Kaydedildi: ${t.name}") }
    }

    private fun saveTab(t: Tab, done: () -> Unit) {
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try { File(t.path).writeText(t.text ?: ""); true } catch (_: Exception) { false }
            }
            if (ok) { t.dirty = false; rebuildTabCount(); done() }
            else toast("Kaydedilemedi")
        }
    }

    private fun copyToClipboard(text: String) {
        if (text.isEmpty()) return toast("Metin boş")
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("metin", text))
        toast("Kopyalandı (${text.length} karakter)")
    }

    private fun doUndo() {
        val t = tabs.getOrNull(active) ?: return
        val stack = undoStackMap[t.path] ?: return
        if (stack.size <= 1) { toast("Geri alınacak bir şey yok"); return }
        stack.removeLast() // mevcut durumu çıkar
        val prev = stack.lastOrNull() ?: return
        loading = true
        b.etBody.setText(prev)
        b.etBody.setSelection(prev.length)
        t.text = prev
        loading = false
        if (!t.dirty) { t.dirty = true; rebuildTabCount() }
        toast("Geri alındı")
    }

    private fun findNext() {
        val q = b.etFind.text.toString(); if (q.isEmpty()) return
        val body = b.etBody.text.toString()
        val from = b.etBody.selectionEnd.coerceAtLeast(0)
        var idx = body.indexOf(q, from, ignoreCase = true)
        if (idx < 0) idx = body.indexOf(q, 0, ignoreCase = true)
        if (idx < 0) { toast("Bulunamadı"); return }
        b.etBody.requestFocus(); b.etBody.setSelection(idx, idx + q.length)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
