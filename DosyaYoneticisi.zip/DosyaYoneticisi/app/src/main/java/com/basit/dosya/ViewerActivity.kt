package com.basit.dosya

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.basit.dosya.databinding.ActivityViewerBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File

/**
 * Çok sekmeli metin görüntüleyici/düzenleyici.
 * - Sekmeler kalıcıdır: geri dönüp başka bir txt açınca yeni sekme eklenir,
 *   eskiler durur (yollar cihaz hafızasında saklanır).
 * - Yazı boyutu A− / A+ ile ayarlanır ve hatırlanır.
 * - Kaydet yanında: Tümünü / İlk yarıyı / Son yarıyı kopyala.
 */
class ViewerActivity : AppCompatActivity() {

    private lateinit var b: ActivityViewerBinding

    private data class Tab(
        val path: String,
        var text: String? = null,   // null = henüz yüklenmedi
        var dirty: Boolean = false
    ) {
        val name: String get() = File(path).name
    }

    private val tabs = ArrayList<Tab>()
    private var active = -1
    private var loading = false

    private val prefs by lazy { getSharedPreferences("viewer", MODE_PRIVATE) }
    private var textSize = 15f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityViewerBinding.inflate(layoutInflater)
        setContentView(b.root)

        textSize = prefs.getFloat("size", 15f)
        applyTextSize()
        b.etBody.setHorizontallyScrolling(false)

        b.btnBack.setOnClickListener { attemptExit() }
        b.btnSave.setOnClickListener { saveActive() }
        b.btnFind.setOnClickListener {
            b.findRow.visibility =
                if (b.findRow.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            if (b.findRow.visibility == View.VISIBLE) b.etFind.requestFocus()
        }
        b.btnFindClose.setOnClickListener { b.findRow.visibility = View.GONE }
        b.btnFindNext.setOnClickListener { findNext() }

        b.btnZoomOut.setOnClickListener { changeSize(-1.5f) }
        b.btnZoomIn.setOnClickListener { changeSize(+1.5f) }

        b.btnCopyAll.setOnClickListener { copyPart(0) }
        b.btnCopyFirst.setOnClickListener { copyPart(1) }
        b.btnCopySecond.setOnClickListener { copyPart(2) }

        b.etBody.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, c: Int, d: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, c: Int, d: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (loading) return
                val t = tabs.getOrNull(active) ?: return
                if (!t.dirty) { t.dirty = true; rebuildStrip() }
            }
        })

        onBackPressedDispatcher.addCallback(this) { attemptExit() }

        restoreTabs()
        intent?.getStringExtra("path")?.let { addTab(it) }
        if (tabs.isEmpty()) { finish(); return }
        if (active !in tabs.indices) activate(tabs.size - 1) else activate(active)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.getStringExtra("path")?.let { addTab(it) }
    }

    override fun onPause() {
        super.onPause()
        persistTabs()
    }

    // ---------- sekme yönetimi ----------

    private fun restoreTabs() {
        try {
            val arr = JSONArray(prefs.getString("tabs", "[]"))
            for (i in 0 until arr.length()) {
                val p = arr.getString(i)
                if (File(p).exists()) tabs.add(Tab(p))
            }
            active = prefs.getInt("active", tabs.size - 1)
        } catch (_: Exception) {}
    }

    private fun persistTabs() {
        val arr = JSONArray()
        tabs.forEach { arr.put(it.path) }
        prefs.edit()
            .putString("tabs", arr.toString())
            .putInt("active", active)
            .putFloat("size", textSize)
            .apply()
    }

    private fun addTab(path: String) {
        val existing = tabs.indexOfFirst { it.path == path }
        if (existing >= 0) { activate(existing); return }
        if (!File(path).exists()) { toast("Dosya bulunamadı"); return }
        tabs.add(Tab(path))
        activate(tabs.size - 1)
        persistTabs()
    }

    private fun stashCurrent() {
        val t = tabs.getOrNull(active) ?: return
        if (t.text != null) t.text = b.etBody.text.toString()
    }

    private fun activate(idx: Int) {
        if (idx !in tabs.indices) return
        stashCurrent()
        active = idx
        val t = tabs[idx]
        b.tvPath.text = t.path
        rebuildStrip()
        if (t.text != null) {
            loading = true
            b.etBody.setText(t.text)
            loading = false
        } else {
            lifecycleScope.launch {
                val f = File(t.path)
                if (f.length() > 2_000_000) toast("Büyük dosya — açılması sürebilir")
                val content = withContext(Dispatchers.IO) {
                    try { f.readText() } catch (_: Exception) { null }
                }
                if (content == null) {
                    toast("Okunamadı"); closeTabAt(idx, force = true); return@launch
                }
                t.text = content
                if (active == idx) {
                    loading = true
                    b.etBody.setText(content)
                    b.etBody.setSelection(0)
                    loading = false
                }
            }
        }
        persistTabs()
    }

    private fun rebuildStrip() {
        b.tabStrip.removeAllViews()
        val d = resources.displayMetrics.density
        fun dp(v: Float) = (v * d).toInt()
        tabs.forEachIndexed { i, t ->
            val isActive = i == active
            val chip = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = ContextCompat.getDrawable(
                    this@ViewerActivity,
                    if (isActive) R.drawable.bg_chip_accent else R.drawable.bg_chip
                )
                setPadding(dp(12f), 0, dp(6f), 0)
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, dp(38f)
                )
                lp.marginEnd = dp(6f)
                layoutParams = lp
                setOnClickListener { if (i != active) activate(i) }
            }
            val name = TextView(this).apply {
                text = (if (t.dirty) "• " else "") + t.name
                textSize = 12f
                maxEms = 9
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
                setTextColor(
                    ContextCompat.getColor(
                        this@ViewerActivity,
                        if (isActive) R.color.on_accent else R.color.text_main
                    )
                )
            }
            val close = TextView(this).apply {
                text = "✕"
                textSize = 12f
                setPadding(dp(8f), dp(6f), dp(8f), dp(6f))
                setTextColor(
                    ContextCompat.getColor(
                        this@ViewerActivity,
                        if (isActive) R.color.on_accent else R.color.text_dim
                    )
                )
                setOnClickListener { closeTabAt(i) }
            }
            chip.addView(name)
            chip.addView(close)
            b.tabStrip.addView(chip)
        }
    }

    private fun closeTabAt(idx: Int, force: Boolean = false) {
        val t = tabs.getOrNull(idx) ?: return
        if (idx == active) stashCurrent()
        if (t.dirty && !force) {
            MaterialAlertDialogBuilder(this)
                .setTitle(t.name)
                .setMessage("Kaydedilmemiş değişiklikler var.")
                .setPositiveButton("Kaydet ve kapat") { _, _ ->
                    saveTab(t) { doClose(idx) }
                }
                .setNegativeButton("Kaydetmeden kapat") { _, _ -> doClose(idx) }
                .setNeutralButton("İptal", null)
                .show()
        } else doClose(idx)
    }

    private fun doClose(idx: Int) {
        if (idx !in tabs.indices) return
        tabs.removeAt(idx)
        if (tabs.isEmpty()) { persistTabs(); finish(); return }
        active = when {
            idx < active -> active - 1
            idx == active -> (idx - 1).coerceAtLeast(0)
            else -> active
        }
        val t = tabs[active]
        b.tvPath.text = t.path
        loading = true
        b.etBody.setText(t.text ?: "")
        loading = false
        if (t.text == null) activate(active)
        rebuildStrip()
        persistTabs()
    }

    private fun attemptExit() {
        stashCurrent()
        val dirtyOnes = tabs.filter { it.dirty }
        if (dirtyOnes.isEmpty()) { persistTabs(); finish(); return }
        MaterialAlertDialogBuilder(this)
            .setTitle("Kaydedilmemiş değişiklikler")
            .setMessage("${dirtyOnes.size} sekmede kaydedilmemiş değişiklik var.")
            .setPositiveButton("Tümünü kaydet ve çık") { _, _ ->
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) {
                        dirtyOnes.forEach { t ->
                            try { File(t.path).writeText(t.text ?: "") } catch (_: Exception) {}
                        }
                    }
                    persistTabs(); finish()
                }
            }
            .setNegativeButton("Kaydetmeden çık") { _, _ -> persistTabs(); finish() }
            .setNeutralButton("İptal", null)
            .show()
    }

    // ---------- kaydet / kopyala / boyut / ara ----------

    private fun saveActive() {
        stashCurrent()
        val t = tabs.getOrNull(active) ?: return
        saveTab(t) { toast("Kaydedildi") }
    }

    private fun saveTab(t: Tab, onDone: () -> Unit) {
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try { File(t.path).writeText(t.text ?: ""); true } catch (_: Exception) { false }
            }
            if (ok) { t.dirty = false; rebuildStrip(); onDone() }
            else toast("Kaydedilemedi")
        }
    }

    /** part: 0=tümü, 1=ilk yarı, 2=son yarı. Yarılar satır sınırında bölünür. */
    private fun copyPart(part: Int) {
        val full = b.etBody.text.toString()
        if (full.isEmpty()) return toast("Metin boş")
        val piece = when (part) {
            1 -> full.substring(0, splitPoint(full))
            2 -> full.substring(splitPoint(full))
            else -> full
        }
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("metin", piece))
        toast("Panoya kopyalandı (${piece.length} karakter)")
    }

    private fun splitPoint(s: String): Int {
        val mid = s.length / 2
        val nl = s.lastIndexOf('\n', mid)
        if (nl > s.length / 4) return nl + 1
        val sp = s.lastIndexOf(' ', mid)
        if (sp > s.length / 4) return sp + 1
        return mid
    }

    private fun changeSize(delta: Float) {
        textSize = (textSize + delta).coerceIn(10f, 34f)
        applyTextSize()
        prefs.edit().putFloat("size", textSize).apply()
    }

    private fun applyTextSize() {
        b.etBody.setTextSize(TypedValue.COMPLEX_UNIT_SP, textSize)
    }

    private fun findNext() {
        val q = b.etFind.text.toString()
        if (q.isEmpty()) return
        val body = b.etBody.text.toString()
        val from = b.etBody.selectionEnd.coerceAtLeast(0)
        var idx = body.indexOf(q, from, ignoreCase = true)
        if (idx < 0) idx = body.indexOf(q, 0, ignoreCase = true)
        if (idx < 0) { toast("Bulunamadı"); return }
        b.etBody.requestFocus()
        b.etBody.setSelection(idx, idx + q.length)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
