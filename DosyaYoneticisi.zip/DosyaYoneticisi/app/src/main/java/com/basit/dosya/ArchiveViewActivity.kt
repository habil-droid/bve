package com.basit.dosya

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.basit.dosya.databinding.ActivityArchiveViewBinding
import com.basit.dosya.databinding.ItemFileBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.zip.ZipFile

/**
 * Arşiv (ZIP/RAR) içine göz atma. Girdiye dokun → önbelleğe çıkar → uygun
 * yerleşik görüntüleyiciyle aç. "Tümünü Ayıkla" arşivin yanına klasör açar.
 * RAR: junrar ile RAR4 desteklenir; RAR5 ve şifreli arşivler dürüstçe bildirilir.
 */
class ArchiveViewActivity : AppCompatActivity() {

    companion object {
        fun open(ctx: Context, path: String) {
            ctx.startActivity(Intent(ctx, ArchiveViewActivity::class.java).putExtra("path", path))
        }
    }

    data class Entry(val name: String, val size: Long, val isDir: Boolean)

    private lateinit var b: ActivityArchiveViewBinding
    private lateinit var archiveFile: File
    private var isRar = false

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityArchiveViewBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnBack.setOnClickListener { finish() }

        val path = intent.getStringExtra("path")
        val f = path?.let { File(it) }
        if (f == null || !f.exists()) { finish(); return }
        archiveFile = f
        isRar = f.extension.lowercase(Locale.ROOT) == "rar"
        b.tvTitle.text = f.name

        b.btnExtractAll.setOnClickListener { extractAll() }

        b.rvEntries.layoutManager = LinearLayoutManager(this)
        b.rvEntries.addItemDecoration(DividerItemDecoration(this, DividerItemDecoration.VERTICAL))

        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { listEntries() }
            when (result.second) {
                "rar5" -> fail("Bu RAR5 formatında — dahili destek yalnızca RAR4. ZArchiver ile açabilirsin.")
                "encrypted" -> fail("Arşiv şifreli — dahili açma desteklenmiyor.")
                "fail" -> fail("Arşiv okunamadı (bozuk olabilir).")
                else -> {
                    val entries = result.first
                    b.tvInfo.text = "${entries.count { !it.isDir }} dosya, ${entries.count { it.isDir }} klasör"
                    b.rvEntries.adapter = EntryAdapter(entries) { e -> previewEntry(e) }
                }
            }
        }
    }

    private fun fail(msg: String) {
        b.tvEmpty.text = msg
        b.tvEmpty.visibility = View.VISIBLE
        b.rvEntries.visibility = View.GONE
        b.btnExtractAll.visibility = View.GONE
    }

    // ---------- listeleme ----------

    private fun listEntries(): Pair<List<Entry>, String> = try {
        if (isRar) listRar() else Pair(listZip(), "ok")
    } catch (_: Exception) { Pair(emptyList(), "fail") }

    private fun listZip(): List<Entry> =
        ZipFile(archiveFile).use { zip ->
            zip.entries().asSequence().map {
                Entry(it.name.trimEnd('/'), it.size, it.isDirectory)
            }.sortedWith(compareBy({ !it.isDir }, { it.name.lowercase(Locale.ROOT) })).toList()
        }

    private fun listRar(): Pair<List<Entry>, String> = try {
        com.github.junrar.Archive(archiveFile).use { arch ->
            if (arch.isEncrypted) return Pair(emptyList(), "encrypted")
            val list = ArrayList<Entry>()
            var fh = arch.nextFileHeader()
            while (fh != null) {
                val name = fh.fileName.trim().replace('\\', '/')
                list.add(Entry(name, fh.fullUnpackSize, fh.isDirectory))
                fh = arch.nextFileHeader()
            }
            Pair(list.sortedWith(compareBy({ !it.isDir }, { it.name.lowercase(Locale.ROOT) })), "ok")
        }
    } catch (e: com.github.junrar.exception.UnsupportedRarV5Exception) {
        Pair(emptyList(), "rar5")
    } catch (_: Exception) { Pair(emptyList(), "fail") }

    // ---------- önizleme ----------

    private fun previewEntry(e: Entry) {
        if (e.isDir) { Toast.makeText(this, "Klasör — Tümünü Ayıkla ile çıkar", Toast.LENGTH_SHORT).show(); return }
        val dlg = progress("Çıkarılıyor…")
        lifecycleScope.launch {
            val out = withContext(Dispatchers.IO) { extractOne(e) }
            dlg.dismiss()
            if (out == null) { Toast.makeText(this@ArchiveViewActivity, "Çıkarılamadı", Toast.LENGTH_SHORT).show(); return@launch }
            openPreview(out)
        }
    }

    private fun extractOne(e: Entry): File? = try {
        val previewDir = File(cacheDir, "arsiv_onizleme").apply { mkdirs() }
        val safe = e.name.substringAfterLast('/')
        val out = File(previewDir, safe)
        if (isRar) {
            com.github.junrar.Archive(archiveFile).use { arch ->
                var fh = arch.nextFileHeader()
                while (fh != null) {
                    if (fh.fileName.trim().replace('\\', '/') == e.name) {
                        FileOutputStream(out).use { os -> arch.extractFile(fh, os) }
                        return out
                    }
                    fh = arch.nextFileHeader()
                }
            }
            null
        } else {
            ZipFile(archiveFile).use { zip ->
                val entry = zip.entries().asSequence().firstOrNull { it.name.trimEnd('/') == e.name } ?: return null
                zip.getInputStream(entry).use { ins ->
                    FileOutputStream(out).use { ins.copyTo(it, 64 * 1024) }
                }
            }
            out
        }
    } catch (_: Exception) { null }

    private fun openPreview(f: File) {
        val ext = f.extension.lowercase(Locale.ROOT)
        when {
            ext in MediaViewActivity.IMAGE_EXTS || ext in MediaViewActivity.VIDEO_EXTS ->
                MediaViewActivity.open(this, f.absolutePath)
            ext == "pdf" -> PdfViewActivity.open(this, f.absolutePath)
            ext in MainActivity.TEXT_EXTS -> openInMainAsText(f)
            ext == "docx" -> {
                val text = DocxReader.readDocx(f)
                if (text != null) openTextViaCache(f.nameWithoutExtension, text) else openWith(f)
            }
            ext == "pptx" -> {
                val text = DocxReader.readPptx(f)
                if (text != null) openTextViaCache(f.nameWithoutExtension, text) else openWith(f)
            }
            ext == "xlsx" -> {
                val text = XlsxReader.read(f)
                if (text != null) openTextViaCache(f.nameWithoutExtension, text) else openWith(f)
            }
            else -> openWith(f)
        }
    }

    private fun openTextViaCache(name: String, content: String) {
        try {
            val tmp = File(cacheDir, "$name.txt")
            tmp.writeText(content)
            openInMainAsText(tmp)
        } catch (_: Exception) { Toast.makeText(this, "Açılamadı", Toast.LENGTH_SHORT).show() }
    }

    private fun openInMainAsText(f: File) {
        startActivity(Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("openTextPath", f.absolutePath)
        })
    }

    private fun openWith(f: File) {
        try {
            val uri: Uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            val mime = MimeTypeMap.getSingleton()
                .getMimeTypeFromExtension(f.extension.lowercase(Locale.ROOT)) ?: "*/*"
            startActivity(Intent.createChooser(
                Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, mime)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }, "Şununla aç"))
        } catch (_: Exception) { Toast.makeText(this, "Açacak uygulama yok", Toast.LENGTH_SHORT).show() }
    }

    // ---------- tümünü ayıkla ----------

    private fun extractAll() {
        val destDir = FileOps.uniqueIn(archiveFile.parentFile ?: return, archiveFile.nameWithoutExtension)
        val dlg = progress("Ayıklanıyor…")
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                if (isRar) FileOps.unrar(archiveFile, destDir)
                else if (FileOps.unzip(archiveFile, destDir)) "ok" else "fail"
            }
            dlg.dismiss()
            val msg = when (result) {
                "ok" -> "Ayıklandı: ${destDir.name}"
                "rar5" -> "RAR5 formatı — dahili ayıklama yalnızca RAR4"
                "encrypted" -> "Şifreli arşiv desteklenmiyor"
                else -> "Ayıklanamadı"
            }
            Toast.makeText(this@ArchiveViewActivity, msg, Toast.LENGTH_LONG).show()
        }
    }

    private fun progress(msg: String) = MaterialAlertDialogBuilder(this)
        .setView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(48, 40, 48, 40)
            addView(ProgressBar(context))
            addView(TextView(context).apply { text = msg; setPadding(28, 8, 0, 0); textSize = 14f })
        }).setCancelable(false).show()

    // ---------- adapter ----------

    inner class EntryAdapter(
        private val items: List<Entry>,
        private val onClick: (Entry) -> Unit
    ) : RecyclerView.Adapter<EntryAdapter.VH>() {

        inner class VH(val ib: ItemFileBinding) : RecyclerView.ViewHolder(ib.root)

        override fun onCreateViewHolder(p: ViewGroup, t: Int) =
            VH(ItemFileBinding.inflate(LayoutInflater.from(p.context), p, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val e = items[pos]
            h.ib.tvName.text = e.name
            h.ib.tvSub.text = if (e.isDir) "klasör" else FileOps.fmtSize(e.size)
            h.ib.tvDate.text = ""
            val ext = e.name.substringAfterLast('.', "").lowercase(Locale.ROOT)
            val icon = when {
                e.isDir -> R.drawable.ic_folder
                ext in MediaViewActivity.IMAGE_EXTS -> R.drawable.ic_image
                ext in MediaViewActivity.VIDEO_EXTS -> R.drawable.ic_video
                ext in setOf("mp3","wav","m4a","ogg","flac") -> R.drawable.ic_music_note
                ext == "pdf" -> R.drawable.ic_pdf
                ext in setOf("doc","docx","ppt","pptx") -> R.drawable.ic_docx
                ext in setOf("zip","rar","7z") -> R.drawable.ic_zip
                ext in MainActivity.TEXT_EXTS -> R.drawable.ic_text
                else -> R.drawable.ic_file
            }
            h.ib.ivIcon.setImageResource(icon)
            h.ib.ivIcon.imageTintList = android.content.res.ColorStateList.valueOf(
                ContextCompat.getColor(this@ArchiveViewActivity, R.color.accent))
            h.ib.rowRoot.setOnClickListener { onClick(e) }
            h.ib.rowRoot.setOnLongClickListener { true }
        }
    }
}
