package com.basit.dosya

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.basit.dosya.databinding.FragmentTextEditorBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Tek dosyalık metin görüntüleyici/düzenleyici. Sekme YOK.
 * Kapatılınca (geri tuşu veya kaydettikten sonra) MainActivity.closeTextFile()
 * çağrılır ve klasör görünümüne dönülür.
 */
class TextEditorFragment : Fragment() {

    companion object {
        private const val ARG_PATH = "path"
        fun newInstance(path: String) = TextEditorFragment().apply {
            arguments = Bundle().apply { putString(ARG_PATH, path) }
        }
    }

    private var _b: FragmentTextEditorBinding? = null
    private val b get() = _b!!
    private lateinit var filePath: File
    private var fileContent: String? = null
    private var isDirty = false
    private var loading = false

    private val undoStack = ArrayDeque<String>(40)
    private val undoHandler = Handler(Looper.getMainLooper())
    private val saveUndoRunnable = Runnable {
        if (!loading) {
            val current = b.etBody.text.toString()
            if (undoStack.lastOrNull() != current) {
                undoStack.addLast(current)
                if (undoStack.size > 40) undoStack.removeFirst()
            }
        }
    }

    private fun main() = requireActivity() as MainActivity

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, s: Bundle?): View {
        filePath = File(arguments?.getString(ARG_PATH) ?: "")
        _b = FragmentTextEditorBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, s: Bundle?) {
        super.onViewCreated(view, s)

        b.btnUndo.setOnClickListener { doUndo() }
        b.btnClearAll.setOnClickListener { doClearAll() }
        b.btnScrollEnds.setOnClickListener { toggleScrollEnds() }
        b.btnCopyAll.setOnClickListener { doCopyAll() }
        b.btnSave.setOnClickListener { doSave() }

        b.etBody.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, c: Int, d: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, c: Int, d: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (loading) return
                isDirty = true
                undoHandler.removeCallbacks(saveUndoRunnable)
                undoHandler.postDelayed(saveUndoRunnable, 600)
            }
        })

        loadContent()
    }

    override fun onDestroyView() {
        undoHandler.removeCallbacksAndMessages(null)
        _b = null
    }

    /** Geri tuşu / kapatma isteği — kayıtsız değişiklik varsa sorar. */
    fun requestClose() {
        if (!isDirty) { main().closeTextFile(); return }
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(filePath.name)
            .setMessage("Kaydedilmemiş değişiklikler var.")
            .setPositiveButton("Kaydet ve kapat") { _, _ ->
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) {
                        try { filePath.writeText(b.etBody.text.toString()) } catch (_: Exception) {}
                    }
                    main().closeTextFile()
                }
            }
            .setNegativeButton("Kaydetmeden kapat") { _, _ -> main().closeTextFile() }
            .setNeutralButton("İptal", null)
            .show()
    }

    private fun loadContent() {
        if (!filePath.exists()) { toast("Dosya bulunamadı"); main().closeTextFile(); return }
        lifecycleScope.launch {
            val content = withContext(Dispatchers.IO) {
                try { filePath.readText() } catch (_: Exception) { null }
            }
            if (_b == null) return@launch
            if (content == null) { toast("Okunamadı: ${filePath.name}"); main().closeTextFile(); return@launch }
            fileContent = content
            loading = true; b.etBody.setText(content); b.etBody.setSelection(0); loading = false
            undoStack.addLast(content)
        }
    }

    private var atBottom = false

    /** Bir kez bas: en aşağı in. Tekrar bas: en yukarı çık. */
    private fun toggleScrollEnds() {
        val len = b.etBody.text?.length ?: 0
        if (!atBottom) {
            b.etBody.requestFocus()
            b.etBody.setSelection(len)
            // Görünümü en alta kaydır
            b.etBody.post {
                val layout = b.etBody.layout ?: return@post
                val line = layout.lineForOffset(len)
                val y = layout.getLineBottom(line)
                b.etBody.scrollTo(0, maxOf(0, y - b.etBody.height + b.etBody.paddingBottom + b.etBody.paddingTop))
            }
            b.tvScrollEnds.text = "En Üst"
            atBottom = true
        } else {
            b.etBody.requestFocus()
            b.etBody.setSelection(0)
            b.etBody.post { b.etBody.scrollTo(0, 0) }
            b.tvScrollEnds.text = "En Alt"
            atBottom = false
        }
    }

    private fun doUndo() {
        if (undoStack.size <= 1) { toast("Geri alınacak yok"); return }
        undoStack.removeLast()
        val prev = undoStack.lastOrNull() ?: return
        loading = true
        b.etBody.setText(prev)
        b.etBody.setSelection(prev.length)
        loading = false
        toast("Geri alındı")
    }

    private fun doClearAll() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Tümünü sil")
            .setMessage("Editördeki tüm metin silinecek. Kaydetmeden önce geri alabilirsin.")
            .setPositiveButton("Sil") { _, _ -> b.etBody.setText("") }
            .setNegativeButton("İptal", null).show()
    }

    private fun doCopyAll() {
        val text = b.etBody.text.toString()
        if (text.isEmpty()) { toast("Metin boş"); return }
        (requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("metin", text))
        toast("Kopyalandı (${text.length} karakter)")
    }

    private fun doSave() {
        val content = b.etBody.text.toString()
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try { filePath.writeText(content); true } catch (_: Exception) { false }
            }
            if (ok) { isDirty = false; toast("Kaydedildi: ${filePath.name}") }
            else toast("Kaydedilemedi")
        }
    }

    private fun toast(s: String) = Toast.makeText(requireContext(), s, Toast.LENGTH_SHORT).show()
}
