package com.basit.dosya

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.basit.dosya.databinding.FragmentTextEditorBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class TextEditorFragment : Fragment() {

    companion object {
        private const val ARG_TAB_ID = "tabId"
        fun newInstance(tabId: String) = TextEditorFragment().apply {
            arguments = Bundle().apply { putString(ARG_TAB_ID, tabId) }
        }
    }

    private var _b: FragmentTextEditorBinding? = null
    private val b get() = _b!!
    private lateinit var tabId: String
    private var loading = false

    // Undo yığını
    private val undoStack = ArrayDeque<String>(40)
    private val undoHandler = Handler(Looper.getMainLooper())
    private val saveUndoRunnable = Runnable {
        if (!loading) {
            val current = b.etBody.text.toString()
            if (undoStack.lastOrNull() != current) {
                undoStack.addLast(current)
                if (undoStack.size > 40) undoStack.removeFirst()
            }
        }
    }

    private fun main() = requireActivity() as MainActivity
    private fun tabData() = main().getTabData(tabId)

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, s: Bundle?): View {
        tabId = arguments?.getString(ARG_TAB_ID) ?: ""
        _b = FragmentTextEditorBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, s: Bundle?) {
        super.onViewCreated(view, s)

        b.btnUndo.setOnClickListener { doUndo() }
        b.btnClearAll.setOnClickListener { doClearAll() }
        b.btnCopyAll.setOnClickListener { doCopyAll() }
        b.btnSave.setOnClickListener { doSave() }

        b.etBody.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, c: Int, d: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, c: Int, d: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (loading) return
                val td = tabData() ?: return
                if (!td.isDirty) {
                    td.isDirty = true
                    main().updateTabStrip()
                }
                // Undo yığınını 600ms sonra güncelle
                undoHandler.removeCallbacks(saveUndoRunnable)
                undoHandler.postDelayed(saveUndoRunnable, 600)
            }
        })

        loadContent()
    }

    override fun onDestroyView() {
        undoHandler.removeCallbacksAndMessages(null)
        // Mevcut içeriği tab verisine yaz
        tabData()?.fileContent = _b?.etBody?.text?.toString()
        _b = null
    }

    private fun loadContent() {
        val td = tabData() ?: return
        if (td.fileContent != null) {
            loading = true
            b.etBody.setText(td.fileContent)
            b.etBody.setSelection(0)
            loading = false
            if (undoStack.isEmpty()) undoStack.addLast(td.fileContent!!)
        } else {
            val f = td.filePath ?: return
            viewLifecycleOwner.lifecycleScope.launch {
                val content = withContext(Dispatchers.IO) {
                    try { f.readText() } catch (_: Exception) { null }
                }
                if (_b == null) return@launch
                if (content == null) { toast("Okunamadı: ${f.name}"); return@launch }
                td.fileContent = content
                loading = true; b.etBody.setText(content); b.etBody.setSelection(0); loading = false
                if (undoStack.isEmpty()) undoStack.addLast(content)
            }
        }
    }

    fun hasUnsavedChanges(): Boolean = tabData()?.isDirty == true

    fun getFilePath(): File? = tabData()?.filePath

    // ---------- eylemler ----------

    private fun doUndo() {
        if (undoStack.size <= 1) { toast("Geri alınacak yok"); return }
        undoStack.removeLast()
        val prev = undoStack.lastOrNull() ?: return
        loading = true
        b.etBody.setText(prev)
        b.etBody.setSelection(prev.length)
        tabData()?.fileContent = prev
        loading = false
        toast("Geri alındı")
    }

    private fun doClearAll() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Tümünü sil")
            .setMessage("Editördeki tüm metin silinecek. Kaydetmeden önce geri alabilirsin.")
            .setPositiveButton("Sil") { _, _ ->
                loading = false // let it record as dirty
                b.etBody.setText("")
                tabData()?.fileContent = ""
            }
            .setNegativeButton("İptal", null).show()
    }

    private fun doCopyAll() {
        val text = b.etBody.text.toString()
        if (text.isEmpty()) { toast("Metin boş"); return }
        (requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("metin", text))
        toast("Kopyalandı (${text.length} karakter)")
    }

    private fun doSave() {
        val td = tabData() ?: return
        val f = td.filePath ?: return
        val content = b.etBody.text.toString()
        td.fileContent = content
        viewLifecycleOwner.lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try { f.writeText(content); true } catch (_: Exception) { false }
            }
            if (ok) {
                td.isDirty = false
                main().updateTabStrip()
                toast("Kaydedildi: ${f.name}")
            } else toast("Kaydedilemedi")
        }
    }

    private fun toast(s: String) = Toast.makeText(requireContext(), s, Toast.LENGTH_SHORT).show()
}
