package com.basit.dosya

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.basit.dosya.databinding.FragmentTextEditorBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Metin görüntüleyici/düzenleyici — İKİ MOD:
 *  - Küçük dosyalar (< eşik) DÜZENLEME: EditText (undo, kaydet).
 *  - Büyük dosyalar veya salt-okunur açılış GÖRÜNTÜLEME: ScrollView+TextView
 *    (akıcı kaydırma). EditText büyük metinlerde DynamicLayout yüzünden takılıyordu;
 *    salt-okunur TextView bunu tamamen çözer. "Düzenle" ile düzenleme moduna geçilir.
 */
class TextEditorFragment : Fragment() {

    companion object {
        private const val ARG_PATH = "path"
        private const val ARG_RO = "readOnly"
        // Bu boyutun üzerindeki dosyalar önce hızlı görüntüleme modunda açılır
        private const val EDIT_THRESHOLD = 60_000  // ~60 KB
        fun newInstance(path: String, readOnly: Boolean = false) = TextEditorFragment().apply {
            arguments = Bundle().apply { putString(ARG_PATH, path); putBoolean(ARG_RO, readOnly) }
        }
    }

    private var _b: FragmentTextEditorBinding? = null
    private val b get() = _b!!
    private lateinit var filePath: File
    private var fileContent: String? = null
    private var isDirty = false
    private var loading = false
    private var editMode = false      // true = EditText düzenleme; false = hızlı görüntüleme
    private var forcedReadOnly = false // docx vb. salt-okunur açılış

    private val undoStack = ArrayDeque<String>(40)
    private val undoHandler = Handler(Looper.getMainLooper())
    private val saveUndoRunnable = Runnable {
        if (!loading && editMode) {
            val current = b.etBody.text.toString()
            if (undoStack.lastOrNull() != current) {
                undoStack.addLast(current)
                if (undoStack.size > 40) undoStack.removeFirst()
            }
        }
    }

    private fun main() = requireActivity() as MainActivity

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, s: Bundle?): View {
        filePath = File(arguments?.getString(ARG_PATH) ?: "")
        _b = FragmentTextEditorBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, s: Bundle?) {
        super.onViewCreated(view, s)
        forcedReadOnly = arguments?.getBoolean(ARG_RO, false) == true

        b.btnUndo.setOnClickListener { if (editMode) doUndo() else enterEditMode() }
        b.btnClearAll.setOnClickListener { if (editMode) doClearAll() }
        b.btnScrollEnds.setOnClickListener { toggleScrollEnds() }
        b.btnCopyAll.setOnClickListener { doCopyAll() }
        b.btnSave.setOnClickListener { if (editMode) doSave() else enterEditMode() }

        b.etBody.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, c: Int, d: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, c: Int, d: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (loading || !editMode) return
                isDirty = true
                undoHandler.removeCallbacks(saveUndoRunnable)
                undoHandler.postDelayed(saveUndoRunnable, 600)
            }
        })

        loadContent()
    }

    override fun onDestroyView() {
        undoHandler.removeCallbacksAndMessages(null)
        _b = null
        super.onDestroyView()
    }

    fun requestClose() {
        if (!isDirty) { main().closeTextFile(); return }
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(filePath.name)
            .setMessage("Kaydedilmemiş değişiklikler var.")
            .setPositiveButton("Kaydet ve kapat") { _, _ ->
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) {
                        try { filePath.writeText(b.etBody.text.toString()) } catch (_: Exception) {}
                    }
                    main().closeTextFile()
                }
            }
            .setNegativeButton("Kaydetmeden kapat") { _, _ -> main().closeTextFile() }
            .setNeutralButton("İptal", null)
            .show()
    }

    private fun loadContent() {
        if (!filePath.exists()) { toast("Dosya bulunamadı"); main().closeTextFile(); return }
        lifecycleScope.launch {
            val content = withContext(Dispatchers.IO) {
                try { filePath.readText() } catch (_: Exception) { null }
            }
            if (_b == null) return@launch
            if (content == null) { toast("Okunamadı: ${filePath.name}"); main().closeTextFile(); return@launch }
            fileContent = content

            // Büyük dosya veya salt-okunur → hızlı görüntüleme; küçük → düzenleme
            val big = content.length > EDIT_THRESHOLD
            if (forcedReadOnly || big) showViewMode(content, canEdit = !forcedReadOnly)
            else enterEditModeWith(content)
        }
    }

    // ---------- hızlı görüntüleme modu ----------

    private fun showViewMode(content: String, canEdit: Boolean) {
        editMode = false
        b.etBody.visibility = View.GONE
        b.viewScroll.visibility = View.VISIBLE
        b.tvView.text = content
        // Görüntüleme modunda düzenleme butonlarını uyarla
        b.btnSave.visibility = if (canEdit) View.VISIBLE else View.GONE
        b.btnUndo.visibility = if (canEdit) View.VISIBLE else View.GONE
        b.btnClearAll.visibility = View.GONE
        // Kaydet/Undo düğmeleri "Düzenle" işlevi görür (etiketleri değişmez ama davranış enter-edit)
    }

    private fun enterEditMode() {
        val content = fileContent ?: b.tvView.text.toString()
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Düzenleme modu")
            .setMessage("Büyük dosyalarda düzenleme modu ağır olabilir. Devam edilsin mi?")
            .setPositiveButton("Düzenle") { _, _ -> enterEditModeWith(content) }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun enterEditModeWith(content: String) {
        editMode = true
        b.viewScroll.visibility = View.GONE
        b.etBody.visibility = View.VISIBLE
        b.btnSave.visibility = View.VISIBLE
        b.btnUndo.visibility = View.VISIBLE
        b.btnClearAll.visibility = View.VISIBLE
        loading = true
        b.etBody.setText(content)
        b.etBody.setSelection(0)
        loading = false
        if (undoStack.isEmpty()) undoStack.addLast(content)
    }

    private var atBottom = false

    /** Bir kez bas: en aşağı in. Tekrar bas: en yukarı çık. */
    private fun toggleScrollEnds() {
        if (editMode) {
            val et = b.etBody
            if (!atBottom) {
                val len = et.text?.length ?: 0
                et.requestFocus(); et.setSelection(len)
                et.post {
                    val ch = et.layout?.height ?: 0
                    val vis = et.height - et.paddingTop - et.paddingBottom
                    et.scrollTo(0, maxOf(0, ch - vis))
                }
                b.tvScrollEnds.text = "En Üst"; atBottom = true
            } else {
                et.requestFocus(); et.setSelection(0)
                et.post { et.scrollTo(0, 0) }
                b.tvScrollEnds.text = "En Alt"; atBottom = false
            }
        } else {
            if (!atBottom) {
                b.viewScroll.post { b.viewScroll.fullScroll(View.FOCUS_DOWN) }
                b.tvScrollEnds.text = "En Üst"; atBottom = true
            } else {
                b.viewScroll.post { b.viewScroll.fullScroll(View.FOCUS_UP) }
                b.tvScrollEnds.text = "En Alt"; atBottom = false
            }
        }
    }

    private fun doUndo() {
        if (undoStack.size <= 1) { toast("Geri alınacak yok"); return }
        undoStack.removeLast()
        val prev = undoStack.lastOrNull() ?: return
        loading = true
        b.etBody.setText(prev)
        b.etBody.setSelection(prev.length.coerceAtMost(prev.length))
        loading = false
    }

    private fun doClearAll() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Tümünü sil")
            .setMessage("Tüm metin silinecek.")
            .setPositiveButton("Sil") { _, _ -> b.etBody.setText("") }
            .setNegativeButton("İptal", null).show()
    }

    private fun doCopyAll() {
        val text = if (editMode) b.etBody.text.toString() else b.tvView.text.toString()
        val cm = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("metin", text))
        toast("Panoya kopyalandı")
    }

    private fun doSave() {
        val content = b.etBody.text.toString()
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try { filePath.writeText(content); true } catch (_: Exception) { false }
            }
            if (ok) { isDirty = false; fileContent = content; toast("Kaydedildi") }
            else toast("Kaydedilemedi")
        }
    }

    private fun toast(s: String) = Toast.makeText(requireContext(), s, Toast.LENGTH_SHORT).show()
}
