package com.basit.dosya

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.basit.dosya.databinding.ActivityPdfViewBinding
import java.io.File

class PdfViewActivity : AppCompatActivity() {

    companion object {
        fun open(ctx: Context, path: String) {
            ctx.startActivity(Intent(ctx, PdfViewActivity::class.java).putExtra("path", path))
        }
    }

    private lateinit var b: ActivityPdfViewBinding
    private var renderer: PdfRenderer? = null
    private var pfd: ParcelFileDescriptor? = null

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityPdfViewBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnBack.setOnClickListener { finish() }

        val path = intent.getStringExtra("path")
        val file = path?.let { File(it) }
        if (file == null || !file.exists()) { finish(); return }
        b.tvTitle.text = file.name

        try {
            pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(pfd!!)
        } catch (e: Exception) {
            Toast.makeText(this, "PDF açılamadı: ${e.message}", Toast.LENGTH_LONG).show()
            finish(); return
        }

        val count = renderer!!.pageCount
        b.tvPageNum.text = "$count sayfa"
        b.rvPages.layoutManager = LinearLayoutManager(this)
        b.rvPages.adapter = PdfPageAdapter(renderer!!, resources.displayMetrics.widthPixels)
    }

    override fun onDestroy() {
        super.onDestroy()
        renderer?.close()
        pfd?.close()
    }

    inner class PdfPageAdapter(
        private val r: PdfRenderer,
        private val width: Int
    ) : RecyclerView.Adapter<PdfPageAdapter.VH>() {

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val iv: ImageView = v.findViewById(R.id.ivPage)
        }

        override fun getItemCount() = r.pageCount
        override fun onCreateViewHolder(p: ViewGroup, t: Int) =
            VH(LayoutInflater.from(p.context).inflate(R.layout.item_pdf_page, p, false))

        override fun onBindViewHolder(h: VH, pos: Int) {
            // Release previous bitmap
            (h.iv.drawable as? android.graphics.drawable.BitmapDrawable)?.bitmap?.recycle()
            h.iv.setImageBitmap(null)
            Thread {
                val bm: Bitmap? = try {
                    synchronized(r) {
                        val page = r.openPage(pos)
                        val scale = width.toFloat() / page.width
                        val bm = Bitmap.createBitmap(
                            (page.width * scale).toInt(),
                            (page.height * scale).toInt(),
                            Bitmap.Config.ARGB_8888
                        )
                        bm.eraseColor(android.graphics.Color.WHITE)
                        page.render(bm, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        page.close()
                        bm
                    }
                } catch (_: Exception) { null }
                h.iv.post { if (!isDestroyed) h.iv.setImageBitmap(bm) }
            }.start()
        }
    }
}
