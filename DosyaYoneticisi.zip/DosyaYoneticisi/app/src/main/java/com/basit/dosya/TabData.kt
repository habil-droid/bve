package com.basit.dosya

import java.io.File

enum class TabType { HOME, FOLDER, FILE }

data class TabData(
    val id: String,
    val type: TabType,
    // --- FOLDER ---
    var currentPath: File? = null,
    val navHistory: ArrayDeque<File> = ArrayDeque(),
    var rootLabel: String = "",
    var binMode: Boolean = false,
    // --- FILE ---
    var filePath: File? = null,
    var fileContent: String? = null,
    var isDirty: Boolean = false,
    var parentFolderTabId: String? = null
) {
    val title: String
        get() = when (type) {
            TabType.HOME -> "Ana Sayfa"
            TabType.FOLDER -> currentPath?.name?.ifEmpty { rootLabel } ?: rootLabel
            TabType.FILE -> filePath?.name ?: "Dosya"
        }
}
