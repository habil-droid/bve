package com.basit.dosya

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.basit.dosya.databinding.ActivityMediaFolderBinding
import java.io.File

/**
 * Görüntü/Video/Müzik kategorilerini klasör klasör gösterir (grid).
 * Bir klasöre dokununca — tutarlılık için — ana sistemdeki (MainActivity) klasör
 * görünümüne yönlendirir. Böylece müzik player barı her yerde AYNI şekilde çalışır.
 */
class MediaFolderActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_TYPE = "type"
        const val EXTRA_TITLE = "title"

        fun open(ctx: Context, type: Int, title: String) {
            ctx.startActivity(Intent(ctx, MediaFolderActivity::class.java).apply {
                putExtra(EXTRA_TYPE, type)
                putExtra(EXTRA_TITLE, title)
            })
        }
    }

    private lateinit var b: ActivityMediaFolderBinding
    private var mediaType = FolderGridAdapter.TYPE_IMAGE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMediaFolderBinding.inflate(layoutInflater)
        setContentView(b.root)

        mediaType = intent.getIntExtra(EXTRA_TYPE, FolderGridAdapter.TYPE_IMAGE)
        b.tvTitle.text = intent.getStringExtra(EXTRA_TITLE) ?: "Medya"
        b.btnBack.setOnClickListener { finish() }

        val adapter = FolderGridAdapter(mediaType) { item ->
            // Klasörü ana sistemde aç → tek tip klasör görünümü + tutarlı müzik player
            startActivity(Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra("openFolderPath", item.dirPath)
                putExtra("openFolderLabel", item.name)
            })
            finish()
        }
        b.rv.layoutManager = GridLayoutManager(this, 3)
        b.rv.adapter = adapter

        Thread {
            val folders = when (mediaType) {
                FolderGridAdapter.TYPE_MUSIC -> queryMediaFolders(android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, android.provider.MediaStore.Audio.Media.DATA)
                FolderGridAdapter.TYPE_VIDEO -> queryMediaFolders(android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI, android.provider.MediaStore.Video.Media.DATA)
                else -> queryMediaFolders(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, android.provider.MediaStore.Images.Media.DATA)
            }.sortedWith(Comparator { a, c -> NaturalSort.fileComparator.compare(File(a.dirPath), File(c.dirPath)) })
            runOnUiThread { adapter.items = folders }
        }.start()
    }

    private fun queryMediaFolders(uri: android.net.Uri, dataColumn: String): List<FolderGridAdapter.FolderItem> {
        val map = LinkedHashMap<String, MutableList<String>>()
        try {
            contentResolver.query(uri, arrayOf(dataColumn), null, null, "$dataColumn ASC")?.use { c ->
                val di = c.getColumnIndex(dataColumn)
                while (c.moveToNext()) {
                    val p = c.getString(di) ?: continue
                    val dir = File(p).parent ?: continue
                    map.getOrPut(dir) { mutableListOf() }.add(p)
                }
            }
        } catch (_: Exception) {}
        return map.entries.map { (dir, files) ->
            FolderGridAdapter.FolderItem(dir, File(dir).name, files.size, files.firstOrNull())
        }
    }
}
