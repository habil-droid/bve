package com.basit.dosya

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.basit.dosya.databinding.ActivityMediaFolderBinding
import java.io.File

class MediaFolderActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_TYPE = "type"
        const val EXTRA_TITLE = "title"

        fun open(ctx: Context, type: Int, title: String) {
            ctx.startActivity(Intent(ctx, MediaFolderActivity::class.java).apply {
                putExtra(EXTRA_TYPE, type)
                putExtra(EXTRA_TITLE, title)
            })
        }
    }

    private lateinit var b: ActivityMediaFolderBinding
    private var mediaType = FolderGridAdapter.TYPE_IMAGE
    private var musicSvc: MusicService? = null
    private val musicConn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, s: IBinder?) {
            musicSvc = (s as MusicService.LocalBinder).get()
            musicSvc?.addCb(::refreshPlayer)
            refreshPlayer()
        }
        override fun onServiceDisconnected(n: ComponentName?) { musicSvc = null }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMediaFolderBinding.inflate(layoutInflater)
        setContentView(b.root)

        mediaType = intent.getIntExtra(EXTRA_TYPE, FolderGridAdapter.TYPE_IMAGE)
        b.tvTitle.text = intent.getStringExtra(EXTRA_TITLE) ?: "Medya"
        b.btnBack.setOnClickListener { finish() }

        val adapter = FolderGridAdapter(mediaType) { item ->
            BrowseActivity.open(this, File(item.dirPath), item.name)
        }
        b.rv.layoutManager = GridLayoutManager(this, 3)
        b.rv.adapter = adapter

        Thread {
            val folders = when (mediaType) {
                FolderGridAdapter.TYPE_MUSIC -> queryMusicFolders()
                FolderGridAdapter.TYPE_VIDEO -> queryMediaFolders(android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI, android.provider.MediaStore.Video.Media.DATA)
                else -> queryMediaFolders(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, android.provider.MediaStore.Images.Media.DATA)
            }.sortedWith(Comparator { a, b -> NaturalSort.fileComparator.compare(File(a.dirPath), File(b.dirPath)) })
            runOnUiThread { adapter.items = folders }
        }.start()

        b.btnPlayerPlayPause.setOnClickListener { MusicService.instance?.togglePlayPause() }
        b.btnPlayerStop.setOnClickListener { MusicService.instance?.stop(); b.playerBar.visibility = View.GONE }
        b.btnPlayerMode.setOnClickListener {
            val svc = MusicService.instance ?: return@setOnClickListener
            svc.playMode = if (svc.playMode == MusicService.MODE_REPEAT_ONE) MusicService.MODE_SEQUENTIAL else MusicService.MODE_REPEAT_ONE
            refreshPlayer()
        }
    }

    override fun onResume() {
        super.onResume()
        MusicService.instance?.let {
            bindService(Intent(this, MusicService::class.java), musicConn, Context.BIND_AUTO_CREATE)
        }
        refreshPlayer()
    }

    override fun onPause() {
        musicSvc?.removeCb(::refreshPlayer)
        try { unbindService(musicConn) } catch (_: Exception) {}
        musicSvc = null
        super.onPause()
    }

    private fun refreshPlayer() {
        val svc = MusicService.instance
        if (svc == null || (!svc.isPlaying && svc.currentFile() == null)) {
            b.playerBar.visibility = View.GONE; return
        }
        b.playerBar.visibility = View.VISIBLE
        b.tvNowPlaying.text = svc.currentFile()?.nameWithoutExtension ?: ""
        b.btnPlayerPlayPause.setImageResource(if (svc.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        b.btnPlayerMode.setImageResource(if (svc.playMode == MusicService.MODE_REPEAT_ONE) R.drawable.ic_repeat_one else R.drawable.ic_seq_play)
    }

    private fun queryMediaFolders(uri: android.net.Uri, dataColumn: String): List<FolderGridAdapter.FolderItem> {
        val map = LinkedHashMap<String, MutableList<String>>() // dirPath -> files
        try {
            contentResolver.query(
                uri, arrayOf(dataColumn),
                null, null, "$dataColumn ASC"
            )?.use { c ->
                val di = c.getColumnIndex(dataColumn)
                while (c.moveToNext()) {
                    val p = c.getString(di) ?: continue
                    val dir = File(p).parent ?: continue
                    map.getOrPut(dir) { mutableListOf() }.add(p)
                }
            }
        } catch (_: Exception) {}
        return map.entries.map { (dir, files) ->
            FolderGridAdapter.FolderItem(
                dirPath = dir,
                name = File(dir).name,
                count = files.size,
                firstFilePath = files.firstOrNull()
            )
        }
    }

    private fun queryMusicFolders(): List<FolderGridAdapter.FolderItem> {
        val uri = android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val col = android.provider.MediaStore.Audio.Media.DATA
        return queryMediaFolders(uri, col)
    }
}
