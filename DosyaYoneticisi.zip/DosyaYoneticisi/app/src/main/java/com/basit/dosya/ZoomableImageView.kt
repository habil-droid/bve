package com.basit.dosya

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Matrix
import android.graphics.RectF
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.appcompat.widget.AppCompatImageView
import kotlin.math.max
import kotlin.math.min

/**
 * Parmakla yakınlaştırılabilen (pinch-zoom), kaydırılabilen ve çift dokunuşla
 * zoom yapılan görüntü görünümü. 90° adımlı döndürmeyi de destekler.
 *
 * Kenardayken (zoom = min) yatay sürükleme dışarıya (fling ile medya değiştirme)
 * bırakılır: [onEdgeSwipe] geri çağrısı sol/sağ yönü bildirir.
 */
@SuppressLint("ClickableViewAccessibility")
class ZoomableImageView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, def: Int = 0
) : AppCompatImageView(context, attrs, def) {

    private val mat = Matrix()
    private val baseMat = Matrix()       // fit + rotation
    private var minScale = 1f
    private var maxScale = 5f
    private var rotationDeg = 0

    var onEdgeSwipe: ((dir: Int) -> Unit)? = null   // -1 = önceki, +1 = sonraki
    var onSingleTap: (() -> Unit)? = null

    private val scaleDetector = ScaleGestureDetector(context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val cur = currentScale()
                var factor = d.scaleFactor
                if (cur * factor < minScale) factor = minScale / cur
                if (cur * factor > maxScale) factor = maxScale / cur
                mat.postScale(factor, factor, d.focusX, d.focusY)
                clamp()
                imageMatrix = mat
                return true
            }
        })

    private val gestureDetector = GestureDetector(context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                onSingleTap?.invoke(); return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (currentScale() > minScale * 1.1f) {
                    // Sıfırla
                    mat.set(baseMat); imageMatrix = mat
                } else {
                    val target = minScale * 2.5f
                    val f = target / currentScale()
                    mat.postScale(f, f, e.x, e.y); clamp(); imageMatrix = mat
                }
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (currentScale() <= minScale * 1.02f) {
                    // Yakınlaşmamış: yatay kaydırmayı medya değiştirmeye bırak
                    return false
                }
                mat.postTranslate(-dx, -dy); clamp(); imageMatrix = mat
                return true
            }

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vX: Float, vY: Float): Boolean {
                if (currentScale() <= minScale * 1.02f) {
                    val dX = e2.x - (e1?.x ?: e2.x)
                    val dY = e2.y - (e1?.y ?: e2.y)
                    if (Math.abs(dX) > 100 && Math.abs(dX) > Math.abs(dY) * 1.5f) {
                        onEdgeSwipe?.invoke(if (dX < 0) +1 else -1)
                        return true
                    }
                }
                return false
            }
        })

    init {
        scaleType = ScaleType.MATRIX
        setOnTouchListener { _, ev ->
            scaleDetector.onTouchEvent(ev)
            gestureDetector.onTouchEvent(ev)
            true
        }
    }

    /** Yeni görüntü ayarlandığında zoom/rotation sıfırlanır. */
    fun resetForNewImage(deg: Int = 0) {
        rotationDeg = deg
        post { fitImage() }
    }

    fun setRotationDegrees(deg: Int) {
        rotationDeg = ((deg % 360) + 360) % 360
        fitImage()
    }

    private fun fitImage() {
        val d = drawable ?: return
        val vw = width.toFloat(); val vh = height.toFloat()
        if (vw <= 0 || vh <= 0) return
        val dw = d.intrinsicWidth.toFloat(); val dh = d.intrinsicHeight.toFloat()
        if (dw <= 0 || dh <= 0) return

        baseMat.reset()
        // Döndürmeyi görüntü merkezinde uygula
        baseMat.postRotate(rotationDeg.toFloat(), dw / 2f, dh / 2f)
        // Döndürülmüş sınırların ölçeğini hesapla
        val rotated = RectF(0f, 0f, dw, dh)
        val m = Matrix(); m.setRotate(rotationDeg.toFloat(), dw / 2f, dh / 2f)
        m.mapRect(rotated)
        val scale = min(vw / rotated.width(), vh / rotated.height())
        baseMat.postScale(scale, scale)
        // Ortala
        val after = RectF(0f, 0f, dw, dh)
        baseMat.mapRect(after)
        baseMat.postTranslate((vw - after.width()) / 2f - after.left, (vh - after.height()) / 2f - after.top)

        minScale = 1f
        maxScale = 6f
        mat.set(baseMat)
        imageMatrix = mat
    }

    private fun currentScale(): Float {
        val v = FloatArray(9); mat.getValues(v)
        val sx = v[Matrix.MSCALE_X]; val sy = v[Matrix.MSKEW_Y]
        return max(0.0001f, kotlin.math.hypot(sx, sy))
    }

    private fun baseScale(): Float {
        val v = FloatArray(9); baseMat.getValues(v)
        return kotlin.math.hypot(v[Matrix.MSCALE_X], v[Matrix.MSKEW_Y])
    }

    /** Görüntüyü görünüm içinde tut (boşluk bırakma / taşma engelle). */
    private fun clamp() {
        val d = drawable ?: return
        val r = RectF(0f, 0f, d.intrinsicWidth.toFloat(), d.intrinsicHeight.toFloat())
        mat.mapRect(r)
        val vw = width.toFloat(); val vh = height.toFloat()
        var dx = 0f; var dy = 0f
        if (r.width() <= vw) dx = (vw - r.width()) / 2f - r.left
        else {
            if (r.left > 0) dx = -r.left
            if (r.right < vw) dx = vw - r.right
        }
        if (r.height() <= vh) dy = (vh - r.height()) / 2f - r.top
        else {
            if (r.top > 0) dy = -r.top
            if (r.bottom < vh) dy = vh - r.bottom
        }
        mat.postTranslate(dx, dy)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        fitImage()
    }
}
