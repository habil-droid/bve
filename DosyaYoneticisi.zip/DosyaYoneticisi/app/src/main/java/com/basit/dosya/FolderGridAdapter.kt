package com.basit.dosya

import android.graphics.Bitmap
import android.media.ThumbnailUtils
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.basit.dosya.databinding.ItemFolderGridBinding
import java.io.File

class FolderGridAdapter(
    private val mediaType: Int, // TYPE_IMAGE / TYPE_VIDEO / TYPE_MUSIC
    private val onClick: (FolderItem) -> Unit
) : RecyclerView.Adapter<FolderGridAdapter.VH>() {

    companion object {
        const val TYPE_IMAGE = 1
        const val TYPE_VIDEO = 2
        const val TYPE_MUSIC = 3
    }

    data class FolderItem(
        val dirPath: String,
        val name: String,
        val count: Int,
        val firstFilePath: String?
    )

    var items: List<FolderItem> = emptyList()
        set(v) { field = v; notifyDataSetChanged() }

    class VH(val b: ItemFolderGridBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(ItemFolderGridBinding.inflate(LayoutInflater.from(p.context), p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val item = items[pos]
        h.b.tvFolderName.text = item.name
        h.b.tvFolderCount.text = "(${item.count})"
        h.b.ivThumb.setImageResource(
            when (mediaType) {
                TYPE_IMAGE -> R.drawable.ic_image
                TYPE_VIDEO -> R.drawable.ic_video
                else -> R.drawable.ic_music_note
            }
        )
        h.b.ivThumb.imageTintList = android.content.res.ColorStateList.valueOf(
            ContextCompat.getColor(h.b.root.context, R.color.accent)
        )
        item.firstFilePath?.let { fp ->
            h.b.ivThumb.tag = fp
            Thread {
                val bm: Bitmap? = try {
                    when (mediaType) {
                        TYPE_IMAGE -> ThumbnailUtils.createImageThumbnail(
                            java.io.File(fp), android.util.Size(120, 120), null
                        )
                        TYPE_VIDEO -> ThumbnailUtils.createVideoThumbnail(
                            java.io.File(fp), android.util.Size(120, 120), null
                        )
                        else -> null
                    }
                } catch (_: Exception) { null }
                h.b.ivThumb.post {
                    if (h.b.ivThumb.tag == fp && bm != null) {
                        h.b.ivThumb.setImageBitmap(bm)
                        h.b.ivThumb.imageTintList = null
                    }
                }
            }.start()
        }
        h.b.root.setOnClickListener { onClick(item) }
    }
}
