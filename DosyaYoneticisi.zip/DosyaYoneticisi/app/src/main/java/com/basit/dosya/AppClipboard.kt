package com.basit.dosya

import java.io.File

object AppClipboard {
    var files: List<File> = emptyList()
    var isCut: Boolean = false
    fun hasContent() = files.isNotEmpty()
    fun set(fs: List<File>, cut: Boolean) { files = fs; isCut = cut }
    fun clear() { files = emptyList(); isCut = false }
}
