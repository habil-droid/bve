package com.basit.dosya

import java.io.File
import java.util.Locale

object NaturalSort {
    val fileComparator: Comparator<File> = Comparator { a, b ->
        if (a.isDirectory != b.isDirectory) return@Comparator if (a.isDirectory) -1 else 1
        cmp(a.name.lowercase(Locale("tr")), b.name.lowercase(Locale("tr")))
    }

    private fun cmp(a: String, b: String): Int {
        var i = 0; var j = 0
        while (i < a.length && j < b.length) {
            val ca = a[i]; val cb = b[j]
            if (ca.isDigit() && cb.isDigit()) {
                var na = 0L; var nb = 0L
                while (i < a.length && a[i].isDigit()) { na = na * 10 + (a[i++] - '0') }
                while (j < b.length && b[j].isDigit()) { nb = nb * 10 + (b[j++] - '0') }
                if (na != nb) return na.compareTo(nb)
            } else {
                if (ca != cb) return ca.compareTo(cb)
                i++; j++
            }
        }
        return a.length - b.length
    }
}
