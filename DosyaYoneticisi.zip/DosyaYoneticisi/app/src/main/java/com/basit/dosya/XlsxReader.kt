package com.basit.dosya

import java.io.File
import java.util.zip.ZipFile

/**
 * XLSX okuyucu — xl/sharedStrings.xml + xl/worksheets/sheetN.xml parse eder,
 * satırları " | " ile ayrılmış düz metin tabloya çevirir. Biçim/formül kaybolur,
 * hücre DEĞERLERİ okunur.
 */
object XlsxReader {

    fun read(f: File): String? = try {
        ZipFile(f).use { zip ->
            // 1) Paylaşılan dizeler
            val shared = ArrayList<String>()
            zip.getEntry("xl/sharedStrings.xml")?.let { e ->
                val raw = zip.getInputStream(e).bufferedReader().readText()
                Regex("<si>(.*?)</si>", RegexOption.DOT_MATCHES_ALL).findAll(raw).forEach { m ->
                    val texts = Regex("<t[^>]*>(.*?)</t>", RegexOption.DOT_MATCHES_ALL)
                        .findAll(m.groupValues[1]).joinToString("") { it.groupValues[1] }
                    shared.add(unescape(texts))
                }
            }

            // 2) Sayfalar
            val sheets = zip.entries().asSequence()
                .filter { it.name.matches(Regex("xl/worksheets/sheet[0-9]+\\.xml")) }
                .sortedBy { it.name }.toList()
            if (sheets.isEmpty()) return null

            val sb = StringBuilder()
            sheets.forEachIndexed { si, entry ->
                if (sheets.size > 1) sb.append("═══ Sayfa ${si + 1} ═══\n")
                val raw = zip.getInputStream(entry).bufferedReader().readText()
                Regex("<row[^>]*>(.*?)</row>", RegexOption.DOT_MATCHES_ALL).findAll(raw).forEach { row ->
                    val cells = ArrayList<String>()
                    Regex("<c([^>]*)(?:/>|>(.*?)</c>)", RegexOption.DOT_MATCHES_ALL)
                        .findAll(row.groupValues[1]).forEach { c ->
                            val attrs = c.groupValues[1]
                            val body = c.groupValues[2]
                            val type = Regex("t=\"([^\"]+)\"").find(attrs)?.groupValues?.get(1)
                            val v = Regex("<v>(.*?)</v>", RegexOption.DOT_MATCHES_ALL).find(body)?.groupValues?.get(1)
                            val cell = when (type) {
                                "s" -> v?.toIntOrNull()?.let { shared.getOrNull(it) } ?: ""
                                "inlineStr" -> Regex("<t[^>]*>(.*?)</t>", RegexOption.DOT_MATCHES_ALL)
                                    .findAll(body).joinToString("") { it.groupValues[1] }.let(::unescape)
                                else -> unescape(v ?: "")
                            }
                            cells.add(cell)
                        }
                    if (cells.any { it.isNotBlank() }) sb.append(cells.joinToString(" | ")).append('\n')
                }
                sb.append('\n')
            }
            sb.toString().trim().ifEmpty { null }
        }
    } catch (_: Exception) { null }

    fun unescape(s: String): String = s
        .replace("&lt;", "<").replace("&gt;", ">")
        .replace("&quot;", "\"").replace("&apos;", "'")
        .replace("&amp;", "&")
}

/**
 * Eski ikili DOC/XLS için DENEYSEL kaba metin çıkarma: dosyadaki UTF-16LE
 * karakter dizilerini tarar. Word 97 .doc'ta gövde metni çoğunlukla böyle
 * gömülüdür — biçim, tablolar ve sayısal hücreler KAYBOLUR, ama yazılar okunur.
 */
object OleTextExtractor {

    fun extract(f: File, maxBytes: Int = 6_000_000): String? = try {
        val bytes = f.inputStream().use { ins ->
            val cap = minOf(f.length(), maxBytes.toLong()).toInt()
            val buf = ByteArray(cap)
            var off = 0
            while (off < cap) {
                val r = ins.read(buf, off, cap - off)
                if (r <= 0) break
                off += r
            }
            buf.copyOf(off)
        }

        val sb = StringBuilder()
        val cur = StringBuilder()
        var i = 0
        fun flush() {
            if (cur.length >= 16) { sb.append(cur.toString().trim()).append('\n') }
            cur.setLength(0)
        }
        while (i + 1 < bytes.size) {
            val lo = bytes[i].toInt() and 0xFF
            val hi = bytes[i + 1].toInt() and 0xFF
            val ch = (hi shl 8) or lo
            val ok = ch == 9 || ch == 10 || ch == 13 ||
                (ch in 0x20..0x7E) ||           // temel Latin
                (ch in 0xC0..0x17F) ||          // Latin-1 ek + Latin Extended-A (Türkçe ğışçöü İĞŞ dahil)
                (ch in 0x2010..0x2030)          // tire/tırnak/üç nokta
            if (ok) {
                cur.append(if (ch == 13) '\n' else ch.toChar())
                i += 2
            } else {
                flush()
                i += 1  // hizalama kaymışsa tek bayt ilerleyip yeniden dene
            }
        }
        flush()

        val out = sb.toString()
            .replace(Regex("[ \\t]{2,}"), " ")
            .replace(Regex("\n{3,}"), "\n\n")
            .trim()
        out.takeIf { it.length >= 40 }
    } catch (_: Exception) { null }
}
