package com.basit.dosya

import java.io.File
import java.util.zip.ZipFile

object DocxReader {

    /**
     * DOCX → metin: word/document.xml içindeki w:t etiketlerini okur.
     * Biçim/tablo kaybı olur ama içerik okunabilir.
     */
    fun readDocx(f: File): String? = try {
        ZipFile(f).use { zip ->
            val entry = zip.getEntry("word/document.xml") ?: return null
            val raw = zip.getInputStream(entry).bufferedReader().readText()
            extractText(raw)
        }
    } catch (_: Exception) { null }

    /**
     * PPTX → metin: ppt/slides/slide*.xml slayt metinlerini birleştirir.
     */
    fun readPptx(f: File): String? = try {
        val sb = StringBuilder()
        ZipFile(f).use { zip ->
            val slides = zip.entries().asSequence()
                .filter { it.name.matches(Regex("ppt/slides/slide[0-9]+\\.xml")) }
                .sortedBy { it.name }
                .toList()
            if (slides.isEmpty()) return null
            slides.forEachIndexed { i, entry ->
                sb.append("--- Slayt ${i + 1} ---\n")
                val raw = zip.getInputStream(entry).bufferedReader().readText()
                sb.append(extractText(raw)).append("\n\n")
            }
        }
        sb.toString().trim().ifEmpty { null }
    } catch (_: Exception) { null }

    /**
     * DOC (eski ikili format) için metin çıkarmak çok karmaşık; null döner
     * → çağıran dışarı yönlendirir.
     */
    fun readDoc(f: File): String? = null

    // XML etiketlerini kaldır, boşlukları temizle
    private fun extractText(xml: String): String {
        // Önce paragraflar arasına satır sonu ekle
        val withBreaks = xml
            .replace(Regex("<w:p[ >/]"), "\n<w:p ")
            .replace(Regex("<a:p[ >/]"), "\n<a:p ")
        // Tüm etiketleri kaldır
        return withBreaks.replace(Regex("<[^>]+>"), "")
            .replace(Regex("[ \\t]+"), " ")
            .replace(Regex("\n{3,}"), "\n\n")
            .trim()
    }
}
