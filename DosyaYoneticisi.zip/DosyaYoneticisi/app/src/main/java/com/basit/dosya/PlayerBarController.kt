package com.basit.dosya

import android.view.View
import android.widget.SeekBar
import com.basit.dosya.databinding.PlayerBarBinding

/**
 * Uygulama içi müzik player barını yöneten yardımcı. Home ve Folder fragment'ları
 * paylaşır. İlerleme çubuğu (SeekBar) dahil. `shouldShow` kuralı ile nerede
 * görüneceği belirlenir.
 */
class PlayerBarController(
    private val pb: PlayerBarBinding,
    private val shouldShow: () -> Boolean
) {
    private var userSeeking = false
    private val cb: () -> Unit = { refresh() }

    fun onResume() {
        MusicService.instance?.addCb(cb)
        setupButtons()
        refresh()
    }

    fun onPause() {
        MusicService.instance?.removeCb(cb)
    }

    private fun setupButtons() {
        pb.playerPrev.setOnClickListener { MusicService.instance?.prev() }
        pb.playerPlayPause.setOnClickListener { MusicService.instance?.togglePlayPause() }
        pb.playerNext.setOnClickListener { MusicService.instance?.next() }
        pb.playerStop.setOnClickListener { MusicService.instance?.stop(); refresh() }
        pb.playerMode.setOnClickListener {
            val svc = MusicService.instance ?: return@setOnClickListener
            svc.playMode = if (svc.playMode == MusicService.MODE_REPEAT_ONE)
                MusicService.MODE_SEQUENTIAL else MusicService.MODE_REPEAT_ONE
            refresh()
        }
        pb.playerSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {}
            override fun onStartTrackingTouch(sb: SeekBar?) { userSeeking = true }
            override fun onStopTrackingTouch(sb: SeekBar?) {
                userSeeking = false
                MusicService.instance?.seekTo((sb?.progress ?: 0).toLong())
            }
        })
    }

    fun refresh() {
        val svc = MusicService.instance
        if (svc == null || svc.currentFile() == null || !shouldShow()) {
            pb.root.visibility = View.GONE
            return
        }
        pb.root.visibility = View.VISIBLE
        pb.playerTitle.text = svc.currentFile()?.nameWithoutExtension ?: ""
        pb.playerPlayPause.setImageResource(if (svc.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        pb.playerMode.text = if (svc.playMode == MusicService.MODE_REPEAT_ONE) "1×" else "Sıra"
        val dur = svc.duration()
        pb.playerSeek.max = if (dur > 0) dur else 1
        if (!userSeeking) pb.playerSeek.progress = svc.position()
    }
}
