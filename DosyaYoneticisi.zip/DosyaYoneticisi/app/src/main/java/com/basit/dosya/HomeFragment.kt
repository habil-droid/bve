package com.basit.dosya

import android.database.Cursor
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.basit.dosya.databinding.FragmentHomeBinding
import java.io.File

class HomeFragment : Fragment() {

    private var _b: FragmentHomeBinding? = null
    private val b get() = _b!!
    private var player: PlayerBarController? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, s: Bundle?): View {
        _b = FragmentHomeBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, s: Bundle?) {
        super.onViewCreated(view, s)
        val main = requireActivity() as MainActivity
        b.tileInternal.setOnClickListener { main.openFolderRoot(Environment.getExternalStorageDirectory(), "Ana Bellek") }
        b.tileSd.setOnClickListener {
            val sd = main.sdRoot()
            if (sd != null) main.openFolderRoot(sd, "SD Kart") else main.showMsg("SD kart bulunamadı")
        }
        b.tileDownloads.setOnClickListener {
            main.openFolderRoot(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "İndirilenler")
        }
        b.tileImages.setOnClickListener { main.openMediaCategory(FolderGridAdapter.TYPE_IMAGE, "Resimler") }
        b.tileVideos.setOnClickListener { main.openMediaCategory(FolderGridAdapter.TYPE_VIDEO, "Videolar") }
        b.tileMusic.setOnClickListener { main.openMediaCategory(FolderGridAdapter.TYPE_MUSIC, "Müzikler") }
        b.tileBin.setOnClickListener { main.openFolderRoot(FileOps.binDir(), "Çöp Kutusu", binMode = true) }
        b.tileRecent.setOnClickListener { showRecentFiles(main) }
        player = PlayerBarController(b.playerBar) { MusicService.instance?.currentFile() != null }
    }

    override fun onResume() {
        super.onResume()
        refresh()
        player?.onResume()
    }

    override fun onPause() { super.onPause(); player?.onPause() }
    override fun onDestroyView() { player = null; _b = null; super.onDestroyView() }

    private fun refresh() {
        val main = requireActivity() as MainActivity
        val ctx = requireContext()

        // Ana bellek doluluk
        try {
            val st = StatFs(Environment.getExternalStorageDirectory().absolutePath)
            val total = st.blockCountLong * st.blockSizeLong
            val free = st.availableBlocksLong * st.blockSizeLong
            val used = total - free
            val pct = if (total > 0) (used * 100 / total).toInt() else 0
            b.subInternal.text = "%$pct · " + FileOps.fmtSize(used) + " / " + FileOps.fmtSize(total)
            b.pbInternal.progress = pct
        } catch (_: Exception) {}

        // SD kart doluluk
        val sd = main.sdRoot()
        if (sd != null) {
            b.tileSd.alpha = 1f
            try {
                val st = StatFs(sd.absolutePath)
                val total = st.blockCountLong * st.blockSizeLong
                val free = st.availableBlocksLong * st.blockSizeLong
                val used = total - free
                val pct = if (total > 0) (used * 100 / total).toInt() else 0
                b.subSd.text = "%$pct · " + FileOps.fmtSize(used) + " / " + FileOps.fmtSize(total)
                b.pbSd.progress = pct
            } catch (_: Exception) {}
        } else {
            b.tileSd.alpha = 0.4f; b.subSd.text = "yok"; b.pbSd.progress = 0
        }

        // Çöp kutusu
        val binCount = FileOps.binDir().list()?.count { it != "index.json" } ?: 0
        b.subBin.text = if (binCount > 0) "$binCount öğe" else ""

    }

    private fun showRecentFiles(main: MainActivity) {
        // Son 30 gün içinde değiştirilmiş dosyalar (MediaStore üzerinden)
        val files = mutableListOf<File>()
        val ctx = requireContext()
        val cutoff = System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000
        val uri = MediaStore.Files.getContentUri("external")
        var cursor: Cursor? = null
        try {
            cursor = ctx.contentResolver.query(
                uri,
                arrayOf(MediaStore.Files.FileColumns.DATA, MediaStore.Files.FileColumns.DATE_MODIFIED),
                "${MediaStore.Files.FileColumns.DATE_MODIFIED} > ?",
                arrayOf((cutoff / 1000).toString()),
                "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
            )
            cursor?.use { c ->
                val di = c.getColumnIndex(MediaStore.Files.FileColumns.DATA)
                var count = 0
                while (c.moveToNext() && count < 60) {
                    val path = c.getString(di) ?: continue
                    val f = File(path)
                    if (f.isFile && f.exists() && !f.name.startsWith(".")) {
                        files.add(f); count++
                    }
                }
            }
        } catch (_: Exception) {}

        if (files.isEmpty()) { main.showMsg("Son 30 günde değiştirilmiş dosya bulunamadı"); return }
        // Sanal bir "Son Dosyalar" klasörü aç — kullanıcı listedeki dosyayı açabilir
        main.openRecentFiles(files)
    }
}
