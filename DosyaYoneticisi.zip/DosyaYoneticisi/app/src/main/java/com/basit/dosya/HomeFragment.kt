package com.basit.dosya

import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.basit.dosya.databinding.FragmentHomeBinding
import java.io.File

class HomeFragment : Fragment() {

    private var _b: FragmentHomeBinding? = null
    private val b get() = _b!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, s: Bundle?): View {
        _b = FragmentHomeBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, s: Bundle?) {
        super.onViewCreated(view, s)
        val main = requireActivity() as MainActivity

        b.tileInternal.setOnClickListener { main.openFolderTab(Environment.getExternalStorageDirectory(), "Ana Bellek") }
        b.tileSd.setOnClickListener {
            val sd = main.sdRoot()
            if (sd != null) main.openFolderTab(sd, "SD Kart")
            else main.showMsg("SD kart bulunamadı")
        }
        b.tileDownloads.setOnClickListener {
            main.openFolderTab(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "İndirilenler")
        }
        b.tileImages.setOnClickListener { main.openMediaCategory(FolderGridAdapter.TYPE_IMAGE, "Resimler") }
        b.tileVideos.setOnClickListener { main.openMediaCategory(FolderGridAdapter.TYPE_VIDEO, "Videolar") }
        b.tileMusic.setOnClickListener { main.openMediaCategory(FolderGridAdapter.TYPE_MUSIC, "Müzikler") }
        b.tileBin.setOnClickListener { main.openFolderTab(FileOps.binDir(), "Çöp Kutusu", binMode = true) }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val main = requireActivity() as MainActivity
        try {
            val st = StatFs(Environment.getExternalStorageDirectory().absolutePath)
            val total = st.blockCountLong * st.blockSizeLong
            val free = st.availableBlocksLong * st.blockSizeLong
            b.subInternal.text = FileOps.fmtSize(total - free) + " / " + FileOps.fmtSize(total)
        } catch (_: Exception) {}

        val sd = main.sdRoot()
        if (sd != null) {
            try {
                val st = StatFs(sd.absolutePath)
                val total = st.blockCountLong * st.blockSizeLong
                val free = st.availableBlocksLong * st.blockSizeLong
                b.subSd.text = FileOps.fmtSize(total - free) + " / " + FileOps.fmtSize(total)
            } catch (_: Exception) {}
            b.tileSd.alpha = 1f
        } else {
            b.tileSd.alpha = 0.4f
            b.subSd.text = "yok"
        }

        val binCount = FileOps.binDir().list()?.count { it != "index.json" } ?: 0
        b.subBin.text = if (binCount > 0) "$binCount öğe" else ""

        // SD kart grid
        if (sd != null) {
            b.tvNoSd.visibility = View.GONE
            b.rvSdCard.visibility = View.VISIBLE
            val folders = sd.listFiles()
                ?.filter { it.isDirectory && !it.name.startsWith(".") }
                ?.sortedWith(NaturalSort.fileComparator) ?: emptyList()
            val adapter = FolderGridAdapter(FolderGridAdapter.TYPE_FOLDER) { item ->
                main.openFolderTab(File(item.dirPath), item.name)
            }
            b.rvSdCard.layoutManager = GridLayoutManager(requireContext(), 4)
            b.rvSdCard.adapter = adapter
            adapter.items = folders.map {
                FolderGridAdapter.FolderItem(it.absolutePath, it.name, it.list()?.size ?: 0, null)
            }
        } else {
            b.rvSdCard.visibility = View.GONE
            b.tvNoSd.visibility = View.VISIBLE
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
