package com.basit.dosya

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.os.IBinder
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.basit.dosya.databinding.FragmentFolderBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FolderFragment : Fragment() {

    private var _b: FragmentFolderBinding? = null
    private val b get() = _b!!
    private lateinit var adapter: FileAdapter
    private val selection = LinkedHashSet<String>()

    private val TEXT_EXTS = setOf("txt", "log", "md", "json", "csv", "srt", "ini")
    private val MUSIC_EXTS = setOf("mp3", "wav", "m4a", "ogg", "flac", "aac", "opus")

    private fun main() = requireActivity() as MainActivity

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, s: Bundle?): View {
        _b = FragmentFolderBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, s: Bundle?) {
        super.onViewCreated(view, s)
        adapter = FileAdapter(selection, ::onItemClick, ::onItemLong)
        b.rv.layoutManager = LinearLayoutManager(requireContext())
        b.rv.addItemDecoration(DividerItemDecoration(requireContext(), DividerItemDecoration.VERTICAL))
        b.rv.adapter = adapter
        setupContextBars()
        loadCurrentDir()
    }

    override fun onResume() {
        super.onResume()
        loadCurrentDir()
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }

    // ---------- navigation ----------

    private fun loadCurrentDir() {
        val dir = main().currentDir() ?: return
        val binMode = main().currentBinMode()
        viewLifecycleOwner.lifecycleScope.launch {
            val files = withContext(Dispatchers.IO) {
                if (binMode) {
                    dir.listFiles()?.filter { it.name != "index.json" }
                        ?.sortedWith(NaturalSort.fileComparator) ?: emptyList()
                } else {
                    dir.listFiles()?.sortedWith(NaturalSort.fileComparator) ?: emptyList()
                }
            }
            if (_b == null) return@launch
            adapter.items = files
            b.rv.visibility = if (files.isEmpty()) View.GONE else View.VISIBLE
            b.tvEmpty.visibility = if (files.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    // ---------- item interaction ----------

    private fun onItemClick(f: File) {
        if (selection.isNotEmpty()) { toggleSel(f); return }
        if (f.isDirectory) {
            if (main().currentBinMode()) {
                toast("Kutudaki klasörler önce geri yüklenmeli")
            } else {
                main().navigateInto(f)
            }
            return
        }
        val ext = f.extension.lowercase(Locale.ROOT)
        when {
            ext in TEXT_EXTS -> main().openTextFile(f)
            ext in MUSIC_EXTS -> playMusic(f)
            ext == "zip" -> zipDialog(f)
            else -> openWith(f)
        }
    }

    private fun onItemLong(f: File) { toggleSel(f) }

    private fun toggleSel(f: File) {
        val p = f.absolutePath
        if (selection.contains(p)) selection.remove(p) else selection.add(p)
        if (selection.isEmpty()) clearSelection() else showCtxBar()
        adapter.notifyDataSetChanged()
    }

    private fun clearSelection() {
        selection.clear()
        hideCtxBars()
        adapter.notifyDataSetChanged()
    }

    private fun selected(): List<File> = adapter.items.filter { selection.contains(it.absolutePath) }

    // ---------- context bars ----------

    private fun setupContextBars() {
        listOf(b.ctxDel, b.ctxDel2).forEach { it.setOnClickListener { doDelete() } }
        listOf(b.ctxRename, b.ctxRename2).forEach { it.setOnClickListener { doRename() } }
        listOf(b.ctxZip, b.ctxZip2).forEach { it.setOnClickListener { doZip() } }
        listOf(b.ctxShare, b.ctxShare2).forEach { it.setOnClickListener { doShare() } }
        b.ctxCut.setOnClickListener { doCut() }
        b.ctxCopy.setOnClickListener { doCopy() }
        b.ctxPaste.setOnClickListener { doPaste() }
    }

    private fun showCtxBar() {
        val hasCb = AppClipboard.hasContent()
        b.ctxBarNormal.visibility = if (!hasCb) View.VISIBLE else View.GONE
        b.ctxBarPaste.visibility = if (hasCb) View.VISIBLE else View.GONE
    }

    private fun hideCtxBars() {
        b.ctxBarNormal.visibility = View.GONE
        b.ctxBarPaste.visibility = View.GONE
    }

    // ---------- operations ----------

    private fun doDelete() {
        val files = selected(); if (files.isEmpty()) return
        val isBin = main().currentBinMode()
        if (isBin) {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Kalıcı sil")
                .setMessage("${files.size} öğe geri alınamaz biçimde silinecek.")
                .setPositiveButton("Sil") { _, _ ->
                    val dlg = progress("Siliniyor…")
                    viewLifecycleOwner.lifecycleScope.launch {
                        withContext(Dispatchers.IO) { files.forEach { FileOps.permDelete(it) } }
                        dlg.dismiss(); clearSelection(); loadCurrentDir()
                    }
                }.setNegativeButton("İptal", null).show()
        } else {
            val dlg = progress("Çöp kutusuna taşınıyor…")
            viewLifecycleOwner.lifecycleScope.launch {
                withContext(Dispatchers.IO) { files.forEach { FileOps.toBin(it); scan(it) } }
                dlg.dismiss(); clearSelection(); loadCurrentDir()
            }
        }
    }

    private fun doRename() {
        val f = selected().singleOrNull() ?: return toast("Tek öğe seç")
        val et = EditText(requireContext()).apply {
            setText(f.name)
            setSelection(0, f.name.lastIndexOf('.').takeIf { it > 0 } ?: f.name.length)
        }
        val wrap = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 16, 48, 0); addView(et)
        }
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Yeniden adlandır").setView(wrap)
            .setPositiveButton("Tamam") { _, _ ->
                val name = et.text.toString().trim()
                if (name.isEmpty() || name.contains('/')) return@setPositiveButton toast("Geçersiz ad")
                val target = File(f.parentFile, name)
                if (target.exists()) return@setPositiveButton toast("Bu adla dosya zaten var")
                if (f.renameTo(target)) { scan(f); scan(target); clearSelection(); loadCurrentDir() }
                else toast("Adlandırılamadı")
            }.setNegativeButton("İptal", null).show()
    }

    private fun doZip() {
        val files = selected(); if (files.isEmpty()) return
        val destDir = main().currentDir() ?: return
        val name = "arsiv_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) + ".zip"
        val destZip = FileOps.uniqueIn(destDir, name)
        val dlg = progress("Sıkıştırılıyor…")
        viewLifecycleOwner.lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) { FileOps.zipFiles(files, destZip) }
            dlg.dismiss()
            toast(if (ok) "Oluşturuldu: ${destZip.name}" else "Sıkıştırılamadı")
            scan(destZip); clearSelection(); loadCurrentDir()
        }
    }

    private fun doShare() {
        val files = selected().filter { it.isFile }
        if (files.isEmpty()) return toast("Klasör paylaşmak için önce ZIP")
        try {
            val i = if (files.size == 1) {
                Intent(Intent.ACTION_SEND).apply { type = mimeOf(files[0]); putExtra(Intent.EXTRA_STREAM, uriFor(files[0])) }
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                    type = "*/*"; putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(files.map { uriFor(it) }))
                }
            }
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "Paylaş"))
            clearSelection()
        } catch (_: Exception) { toast("Paylaşılamadı") }
    }

    private fun doCut() {
        val f = selected(); if (f.isEmpty()) return
        AppClipboard.set(f, cut = true)
        toast("${f.size} öğe kesildi — klasöre gidip Yapıştır")
        clearSelection()
    }

    private fun doCopy() {
        val f = selected(); if (f.isEmpty()) return
        AppClipboard.set(f, cut = false)
        toast("${f.size} öğe kopyalandı — klasöre gidip Yapıştır")
        clearSelection()
    }

    private fun doPaste() {
        val cb = AppClipboard.files; val isMove = AppClipboard.isCut
        val dest = main().currentDir() ?: return
        val dlg = progress(if (isMove) "Taşınıyor…" else "Kopyalanıyor…")
        viewLifecycleOwner.lifecycleScope.launch {
            var ok = 0
            withContext(Dispatchers.IO) {
                for (f in cb) {
                    val done = if (isMove) FileOps.moveInto(f, dest) else FileOps.copyInto(f, dest)
                    if (done) ok++
                    scan(f); scan(File(dest, f.name))
                }
            }
            dlg.dismiss(); AppClipboard.clear()
            toast("$ok öğe tamam"); clearSelection(); loadCurrentDir()
        }
    }

    private fun zipDialog(f: File) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(f.name)
            .setItems(arrayOf("Buraya ayıkla", "Şununla aç")) { _, i ->
                if (i == 0) {
                    val dest = FileOps.uniqueIn(f.parentFile ?: return@setItems, f.nameWithoutExtension)
                    val dlg = progress("Ayıklanıyor…")
                    viewLifecycleOwner.lifecycleScope.launch {
                        val ok = withContext(Dispatchers.IO) { FileOps.unzip(f, dest) }
                        dlg.dismiss()
                        toast(if (ok) "Ayıklandı" else "Ayıklanamadı")
                        loadCurrentDir()
                    }
                } else openWith(f)
            }.show()
    }

    private fun restoreSelected() {
        val files = selected(); if (files.isEmpty()) return
        val dlg = progress("Geri yükleniyor…")
        viewLifecycleOwner.lifecycleScope.launch {
            var ok = 0
            withContext(Dispatchers.IO) { files.forEach { if (FileOps.restore(it)) ok++ } }
            dlg.dismiss(); toast("$ok öğe geri yüklendi"); clearSelection(); loadCurrentDir()
        }
    }

    // ---------- music ----------

    private fun playMusic(file: File) {
        val dir = file.parentFile ?: return
        val playlist = dir.listFiles()
            ?.filter { it.extension.lowercase(Locale.ROOT) in MUSIC_EXTS }
            ?.sortedWith(NaturalSort.fileComparator) ?: return
        val idx = playlist.indexOfFirst { it.absolutePath == file.absolutePath }
        val svc = Intent(requireContext(), MusicService::class.java)
        requireContext().startForegroundService(svc)
        requireContext().bindService(svc, object : ServiceConnection {
            override fun onServiceConnected(n: ComponentName?, s: IBinder?) {
                val ms = (s as MusicService.LocalBinder).get()
                ms.play(playlist, if (idx >= 0) idx else 0)
                try { requireContext().unbindService(this) } catch (_: Exception) {}
            }
            override fun onServiceDisconnected(n: ComponentName?) {}
        }, Context.BIND_AUTO_CREATE)
    }

    // ---------- helpers ----------

    private fun uriFor(f: File): Uri =
        FileProvider.getUriForFile(requireContext(), "${requireContext().packageName}.fileprovider", f)
    private fun mimeOf(f: File) =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase(Locale.ROOT)) ?: "*/*"
    private fun openWith(f: File) {
        try {
            startActivity(Intent.createChooser(
                Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uriFor(f), mimeOf(f))
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }, "Şununla aç"
            ))
        } catch (_: Exception) { toast("Açacak uygulama bulunamadı") }
    }
    private fun scan(f: File) {
        try { MediaScannerConnection.scanFile(requireContext(), arrayOf(f.absolutePath), null, null) } catch (_: Exception) {}
    }
    private fun progress(msg: String) = MaterialAlertDialogBuilder(requireContext())
        .setView(LinearLayout(requireContext()).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(48, 40, 48, 40)
            addView(ProgressBar(requireContext()))
            addView(TextView(requireContext()).apply { text = msg; setPadding(28, 8, 0, 0); textSize = 14f })
        }).setCancelable(false).show()
    private fun toast(s: String) = Toast.makeText(requireContext(), s, Toast.LENGTH_SHORT).show()
}
