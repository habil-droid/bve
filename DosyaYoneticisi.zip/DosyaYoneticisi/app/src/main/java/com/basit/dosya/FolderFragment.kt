package com.basit.dosya

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.os.IBinder
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.basit.dosya.databinding.FragmentFolderBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FolderFragment : Fragment() {

    private var _b: FragmentFolderBinding? = null
    private val b get() = _b!!
    private lateinit var adapter: FileAdapter
    private var player: PlayerBarController? = null
    private val selection = LinkedHashSet<String>()
    private var anchorIdx = -1     // aralık seçimi için anchor indeksi
    private var masterList: List<File> = emptyList()  // tüm dosyalar (arama öncesi)
    private var searchQuery = ""   // aktif arama metni

    private val TEXT_EXTS = setOf("txt", "log", "md", "json", "csv", "srt", "ini")
    private val MUSIC_EXTS = setOf("mp3", "wav", "m4a", "ogg", "flac", "aac", "opus")
    private val ARCHIVE_EXTS = setOf("zip", "rar", "7z")
    private val OFFICE_EXTS = setOf("pdf", "doc", "docx", "pptx", "ppt", "xlsx", "xls")

    private fun main() = requireActivity() as MainActivity

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, s: Bundle?): View {
        _b = FragmentFolderBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, s: Bundle?) {
        super.onViewCreated(view, s)
        adapter = FileAdapter(selection, ::onItemClick, ::onItemLong)
        b.rv.layoutManager = LinearLayoutManager(requireContext())
        b.rv.addItemDecoration(DividerItemDecoration(requireContext(), DividerItemDecoration.VERTICAL))
        b.rv.adapter = adapter
        setupContextBars()

        // Çöp kutusu toplu eylemleri
        if (main().currentBinMode()) {
            b.binActionsRow.visibility = View.VISIBLE
            b.btnRestoreAll.setOnClickListener {
                MaterialAlertDialogBuilder(requireContext())
                    .setTitle("Tümünü geri getir")
                    .setMessage("Kutudaki tüm öğeler orijinal konumlarına geri yüklenecek.")
                    .setPositiveButton("Geri getir") { _, _ ->
                        val dlg = progress("Geri yükleniyor…")
                        viewLifecycleOwner.lifecycleScope.launch {
                            val n = withContext(Dispatchers.IO) { FileOps.restoreAll() }
                            dlg.dismiss(); toast("$n öğe geri yüklendi"); loadCurrentDir()
                        }
                    }.setNegativeButton("İptal", null).show()
            }
            b.btnEmptyBin.setOnClickListener {
                MaterialAlertDialogBuilder(requireContext())
                    .setTitle("Çöp kutusunu boşalt")
                    .setMessage("Kutudaki TÜM öğeler geri alınamaz biçimde silinecek.")
                    .setPositiveButton("Hepsini sil") { _, _ ->
                        val dlg = progress("Siliniyor…")
                        viewLifecycleOwner.lifecycleScope.launch {
                            withContext(Dispatchers.IO) { FileOps.emptyBin() }
                            dlg.dismiss(); toast("Çöp kutusu boşaltıldı"); loadCurrentDir()
                        }
                    }.setNegativeButton("İptal", null).show()
            }
        }

        loadCurrentDir()
        updateCtxBars()
        player = PlayerBarController(b.playerBar) {
            val svc = MusicService.instance
            svc?.currentFile() != null && svc.sourceFolderPath == main().currentDir()?.absolutePath
        }
    }

    override fun onResume() {
        super.onResume()
        searchQuery = main().currentSearchQuery()
        loadCurrentDir()
        updateCtxBars()
        player?.onResume()
    }

    override fun onPause() {
        super.onPause()
        player?.onPause()
    }

    override fun onDestroyView() { player = null; _b = null; super.onDestroyView() }

    // ---------- navigation ----------

    fun refreshList() = loadCurrentDir()
    fun loadDirFromMain() = loadCurrentDir()

    private var searchJob: kotlinx.coroutines.Job? = null

    fun applySearch(q: String) {
        searchQuery = q
        searchJob?.cancel()
        if (q.isBlank()) { adapter.searchBase = null; applyFilter(); return }
        // ÖZYİNELEMELİ arama: bu klasör ve TÜM alt klasörleri (300ms bekleme, max 400 sonuç)
        searchJob = viewLifecycleOwner.lifecycleScope.launch {
            kotlinx.coroutines.delay(300)
            val base = main().currentDir() ?: return@launch
            val showHidden = main().showHiddenFiles()
            val results = withContext(Dispatchers.IO) {
                val out = ArrayList<File>(128)
                try {
                    base.walkTopDown()
                        .onEnter { d -> showHidden || !d.name.startsWith(".") }
                        .forEach { f ->
                            if (out.size >= 400) return@forEach
                            if (f == base) return@forEach
                            if (!showHidden && f.name.startsWith(".")) return@forEach
                            if (f.name.contains(q, ignoreCase = true)) out.add(f)
                        }
                } catch (_: Exception) {}
                out.sortedWith(NaturalSort.fileComparator)
            }
            if (_b == null || searchQuery != q) return@launch
            adapter.searchBase = base
            adapter.items = results
            b.rv.visibility = if (results.isEmpty()) View.GONE else View.VISIBLE
            b.tvEmpty.visibility = if (results.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun loadCurrentDir() {
        val dir = main().currentDir() ?: return
        val showHidden = main().showHiddenFiles()
        val binMode = main().currentBinMode()
        viewLifecycleOwner.lifecycleScope.launch {
            val files = withContext(Dispatchers.IO) {
                val all = if (binMode)
                    dir.listFiles()?.filter { it.name != "index.json" } ?: emptyList()
                else
                    dir.listFiles()?.toList() ?: emptyList()
                all.filter { f -> showHidden || !f.name.startsWith(".") }
                    .sortedWith(NaturalSort.fileComparator)
            }
            if (_b == null) return@launch
            masterList = files
            if (searchQuery.isBlank()) { adapter.searchBase = null; applyFilter() }
            else applySearch(searchQuery)
        }
    }

    private fun applyFilter() {
        val shown = masterList
        adapter.items = shown
        if (_b == null) return
        b.rv.visibility = if (shown.isEmpty()) View.GONE else View.VISIBLE
        b.tvEmpty.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
    }

    // ---------- item interaction ----------

    private fun onItemClick(f: File) {
        if (selection.isNotEmpty()) { toggleSel(f); return }
        if (main().currentBinMode()) { binItemDialog(f); return }
        if (f.isDirectory) { main().navigateInto(f); return }
        val ext = f.extension.lowercase(Locale.ROOT)
        when {
            ext in TEXT_EXTS -> main().openTextFile(f)
            ext in MUSIC_EXTS -> playMusic(f)
            ext in MediaViewActivity.IMAGE_EXTS -> MediaViewActivity.open(requireContext(), f.absolutePath)
            ext in MediaViewActivity.VIDEO_EXTS -> MediaViewActivity.open(requireContext(), f.absolutePath)
            ext == "pdf" -> PdfViewActivity.open(requireContext(), f.absolutePath)
            ext == "docx" -> openDocx(f)
            ext == "pptx" -> openPptx(f)
            ext == "xlsx" -> openXlsx(f)
            ext in setOf("doc", "xls", "ppt") -> openLegacyOffice(f)
            ext in setOf("zip", "rar") -> archiveDialog(f)
            ext == "7z" -> openWith(f)  // 7z: dahili destek yok, harici gerekir
            else -> openWith(f)
        }
    }

    private fun onItemLong(f: File) {
        val curIdx = adapter.items.indexOf(f)
        if (anchorIdx >= 0 && selection.isNotEmpty() && curIdx >= 0) {
            // Aralık seçimi: anchor'dan bu noktaya kadar seç
            val lo = minOf(anchorIdx, curIdx)
            val hi = maxOf(anchorIdx, curIdx)
            for (i in lo..hi) adapter.items.getOrNull(i)?.let { selection.add(it.absolutePath) }
            anchorIdx = -1
            updateCtxBars(); adapter.notifyDataSetChanged()
        } else {
            anchorIdx = if (selection.isEmpty()) curIdx else -1
            toggleSel(f)
        }
    }

    private fun toggleSel(f: File) {
        val p = f.absolutePath
        if (selection.contains(p)) selection.remove(p) else selection.add(p)
        if (selection.isEmpty()) { anchorIdx = -1; clearSelection() } else updateCtxBars()
        adapter.notifyDataSetChanged()
    }

    private fun clearSelection() {
        selection.clear(); anchorIdx = -1
        updateCtxBars(); adapter.notifyDataSetChanged()
    }

    private fun selected(): List<File> = adapter.items.filter { selection.contains(it.absolutePath) }

    // ---------- context bars ----------

    private fun setupContextBars() {
        listOf(b.ctxDel, b.ctxDel2).forEach { it.setOnClickListener { doDelete() } }
        listOf(b.ctxRename, b.ctxRename2).forEach { it.setOnClickListener { doRename() } }
        listOf(b.ctxZip, b.ctxZip2).forEach { it.setOnClickListener { doZip() } }
        listOf(b.ctxShare, b.ctxShare2).forEach { it.setOnClickListener { doShare() } }
        b.ctxCut.setOnClickListener { doCut() }
        b.ctxCopy.setOnClickListener { doCopy() }
        b.ctxPaste.setOnClickListener { doPaste() }
        b.ctxPaste.setOnLongClickListener { AppClipboard.clear(); updateCtxBars(); toast("Pano temizlendi"); true }
    }

    fun updateCtxBars() {
        if (_b == null) return
        when {
            AppClipboard.hasContent() -> {
                b.ctxBarPaste.visibility = View.VISIBLE
                b.ctxBarNormal.visibility = View.GONE
            }
            selection.isNotEmpty() -> {
                b.ctxBarNormal.visibility = View.VISIBLE
                b.ctxBarPaste.visibility = View.GONE
            }
            else -> {
                b.ctxBarNormal.visibility = View.GONE
                b.ctxBarPaste.visibility = View.GONE
            }
        }
    }

    // ---------- office / archive openers ----------

    private fun openDocx(f: File) {
        viewLifecycleOwner.lifecycleScope.launch {
            val text = withContext(Dispatchers.IO) { DocxReader.readDocx(f) }
            if (text != null) openAsText(f.name, text) else openWith(f)
        }
    }

    private fun openPptx(f: File) {
        viewLifecycleOwner.lifecycleScope.launch {
            val text = withContext(Dispatchers.IO) { DocxReader.readPptx(f) }
            if (text != null) openAsText(f.name, text) else openWith(f)
        }
    }

    private fun openAsText(name: String, content: String) {
        // Geçici .txt dosyasına yaz ve metin editörde aç
        val tmp = File(requireContext().cacheDir, name + ".txt")
        try {
            tmp.writeText(content)
            main().openTextFile(tmp, readOnly = true)
        } catch (_: Exception) { toast("Açılamadı") }
    }

    private fun archiveDialog(f: File) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(f.name)
            .setItems(arrayOf("İçine gör", "Buraya ayıkla", "Şununla aç")) { _, i ->
                when (i) {
                    0 -> ArchiveViewActivity.open(requireContext(), f.absolutePath)
                    1 -> extractArchive(f)
                    else -> openWith(f)
                }
            }.show()
    }

    private fun extractArchive(f: File) {
        val destDir = FileOps.uniqueIn(f.parentFile ?: return, f.nameWithoutExtension)
        val isRar = f.extension.lowercase(Locale.ROOT) == "rar"
        val dlg = progress("Ayıklanıyor…")
        viewLifecycleOwner.lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                if (isRar) FileOps.unrar(f, destDir)
                else if (FileOps.unzip(f, destDir)) "ok" else "fail"
            }
            dlg.dismiss()
            when (result) {
                "ok" -> { toast("Ayıklandı: ${destDir.name}"); loadCurrentDir() }
                "rar5" -> toast("RAR5 formatı — dahili ayıklama yalnızca RAR4 (ZArchiver gerekir)")
                "encrypted" -> toast("Şifreli arşiv desteklenmiyor")
                else -> toast("Ayıklanamadı")
            }
        }
    }

    private fun openXlsx(f: File) {
        viewLifecycleOwner.lifecycleScope.launch {
            val text = withContext(Dispatchers.IO) { XlsxReader.read(f) }
            if (text != null) openAsText(f.name, text) else externalFallback(f, "Tablo okunamadı")
        }
    }

    /** Eski ikili DOC/XLS: deneysel kaba metin çıkarma. */
    private fun openLegacyOffice(f: File) {
        val dlg = progress("Metin çıkarılıyor…")
        viewLifecycleOwner.lifecycleScope.launch {
            val text = withContext(Dispatchers.IO) { OleTextExtractor.extract(f) }
            dlg.dismiss()
            if (text != null) {
                openAsText(f.name,
                    "⚠ Eski ikili format — deneysel metin çıkarma.\n" +
                    "Biçim, tablolar ve sayısal hücreler görünmez.\n\n" + text)
            } else externalFallback(f, "Metin çıkarılamadı")
        }
    }

    private fun externalFallback(f: File, why: String) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(f.name)
            .setMessage("$why. Harici uygulamayla açılsın mı?")
            .setPositiveButton("Şununla aç") { _, _ -> openWith(f) }
            .setNegativeButton("İptal", null).show()
    }

    // ---------- operations ----------

    private fun doDelete() {
        val files = selected(); if (files.isEmpty()) return
        if (main().currentBinMode()) {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Kalıcı sil")
                .setMessage("${files.size} öğe geri alınamaz biçimde silinecek.")
                .setPositiveButton("Sil") { _, _ ->
                    val dlg = progress("Siliniyor…")
                    viewLifecycleOwner.lifecycleScope.launch {
                        withContext(Dispatchers.IO) { files.forEach { FileOps.permDelete(it) } }
                        dlg.dismiss(); clearSelection(); loadCurrentDir()
                    }
                }.setNegativeButton("İptal", null).show()
        } else {
            val dlg = progress("Çöp kutusuna taşınıyor…")
            viewLifecycleOwner.lifecycleScope.launch {
                withContext(Dispatchers.IO) { files.forEach { FileOps.toBin(it); scan(it) } }
                dlg.dismiss(); clearSelection(); loadCurrentDir()
            }
        }
    }

    private fun doRename() {
        val f = selected().singleOrNull() ?: return toast("Tek öğe seç")
        val et = EditText(requireContext()).apply {
            setText(f.name)
            setSelection(0, f.name.lastIndexOf('.').takeIf { it > 0 } ?: f.name.length)
        }
        val wrap = LinearLayout(requireContext()).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 16, 48, 0); addView(et) }
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Yeniden adlandır").setView(wrap)
            .setPositiveButton("Tamam") { _, _ ->
                val name = et.text.toString().trim()
                if (name.isEmpty() || name.contains('/')) return@setPositiveButton toast("Geçersiz ad")
                val target = File(f.parentFile, name)
                if (target.exists()) return@setPositiveButton toast("Bu adla dosya zaten var")
                if (f.renameTo(target)) { scan(f); scan(target); clearSelection(); loadCurrentDir() }
                else toast("Adlandırılamadı")
            }.setNegativeButton("İptal", null).show()
    }

    private fun doZip() {
        val files = selected(); if (files.isEmpty()) return
        val destDir = main().currentDir() ?: return
        val name = "arsiv_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) + ".zip"
        val destZip = FileOps.uniqueIn(destDir, name)
        val dlg = progress("Sıkıştırılıyor…")
        viewLifecycleOwner.lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) { FileOps.zipFiles(files, destZip) }
            dlg.dismiss()
            toast(if (ok) "Oluşturuldu: ${destZip.name}" else "Sıkıştırılamadı")
            scan(destZip); clearSelection(); loadCurrentDir()
        }
    }

    private fun doShare() {
        val files = selected().filter { it.isFile }
        if (files.isEmpty()) return toast("Klasör paylaşmak için önce ZIP")
        try {
            val i = if (files.size == 1) {
                Intent(Intent.ACTION_SEND).apply { type = mimeOf(files[0]); putExtra(Intent.EXTRA_STREAM, uriFor(files[0])) }
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                    type = "*/*"; putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(files.map { uriFor(it) }))
                }
            }
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "Paylaş")); clearSelection()
        } catch (_: Exception) { toast("Paylaşılamadı") }
    }

    private fun doCut() {
        val f = selected(); if (f.isEmpty()) return
        AppClipboard.set(f, cut = true)
        toast("${f.size} öğe kesildi — klasöre gidip Yapıştır"); clearSelection()
    }

    private fun doCopy() {
        val f = selected(); if (f.isEmpty()) return
        AppClipboard.set(f, cut = false)
        toast("${f.size} öğe kopyalandı — klasöre gidip Yapıştır"); clearSelection()
    }

    private fun doPaste() {
        val cb = AppClipboard.files; val isMove = AppClipboard.isCut
        val dest = main().currentDir() ?: return
        val dlg = progress(if (isMove) "Taşınıyor…" else "Kopyalanıyor…")
        viewLifecycleOwner.lifecycleScope.launch {
            var ok = 0
            withContext(Dispatchers.IO) {
                for (f in cb) {
                    val done = if (isMove) FileOps.moveInto(f, dest) else FileOps.copyInto(f, dest)
                    if (done) ok++
                    scan(f); scan(File(dest, f.name))
                }
            }
            dlg.dismiss(); AppClipboard.clear()
            toast("$ok öğe tamam"); clearSelection(); loadCurrentDir()
        }
    }

    private fun binItemDialog(f: File) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(f.name)
            .setItems(arrayOf("Geri yükle", "Kalıcı sil")) { _, i ->
                if (i == 0) {
                    val dlg = progress("Geri yükleniyor…")
                    viewLifecycleOwner.lifecycleScope.launch {
                        val ok = withContext(Dispatchers.IO) { FileOps.restore(f) }
                        dlg.dismiss(); toast(if (ok) "Geri yüklendi" else "Geri yüklenemedi"); loadCurrentDir()
                    }
                } else {
                    MaterialAlertDialogBuilder(requireContext())
                        .setMessage("${f.name} kalıcı silinsin mi?")
                        .setPositiveButton("Sil") { _, _ ->
                            viewLifecycleOwner.lifecycleScope.launch {
                                withContext(Dispatchers.IO) { FileOps.permDelete(f) }; loadCurrentDir()
                            }
                        }.setNegativeButton("İptal", null).show()
                }
            }.show()
    }

    // ---------- music ----------

    private fun playMusic(file: File) {
        val dir = file.parentFile ?: return
        val playlist = dir.listFiles()
            ?.filter { it.extension.lowercase(Locale.ROOT) in MUSIC_EXTS }
            ?.sortedWith(NaturalSort.fileComparator) ?: return
        val idx = playlist.indexOfFirst { it.absolutePath == file.absolutePath }
        val svc = Intent(requireContext(), MusicService::class.java)
        requireContext().startForegroundService(svc)
        requireContext().bindService(svc, object : ServiceConnection {
            override fun onServiceConnected(n: ComponentName?, s: IBinder?) {
                val ms = (s as MusicService.LocalBinder).get()
                ms.play(playlist, if (idx >= 0) idx else 0)
                try { requireContext().unbindService(this) } catch (_: Exception) {}
            }
            override fun onServiceDisconnected(n: ComponentName?) {}
        }, Context.BIND_AUTO_CREATE)
    }

    // ---------- helpers ----------

    private fun uriFor(f: File): Uri = FileProvider.getUriForFile(requireContext(), "${requireContext().packageName}.fileprovider", f)
    private fun mimeOf(f: File) = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase(Locale.ROOT)) ?: "*/*"

    private fun openWith(f: File) {
        try {
            startActivity(Intent.createChooser(
                Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uriFor(f), mimeOf(f))
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }, "Şununla aç"
            ))
        } catch (_: Exception) { toast("Açacak uygulama bulunamadı") }
    }

    private fun scan(f: File) {
        try { MediaScannerConnection.scanFile(requireContext(), arrayOf(f.absolutePath), null, null) } catch (_: Exception) {}
    }

    private fun progress(msg: String) = MaterialAlertDialogBuilder(requireContext())
        .setView(LinearLayout(requireContext()).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(48, 40, 48, 40)
            addView(ProgressBar(requireContext()))
            addView(TextView(requireContext()).apply { text = msg; setPadding(28, 8, 0, 0); textSize = 14f })
        }).setCancelable(false).show()

    private fun toast(s: String) = Toast.makeText(requireContext(), s, Toast.LENGTH_SHORT).show()
}
