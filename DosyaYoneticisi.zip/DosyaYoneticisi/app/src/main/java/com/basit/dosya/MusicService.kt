package com.basit.dosya

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.core.app.NotificationCompat
import androidx.media.app.NotificationCompat as MediaNotif
import androidx.media.session.MediaButtonReceiver
import java.io.File

/**
 * Arka plan müzik servisi.
 * KRİTİK PERFORMANS: Albüm kapağı yalnızca şarkı değişince BİR KEZ ve arka planda
 * çözülür (önbelleğe alınır). İlerleme döngüsü SADECE MediaSession durumunu günceller,
 * bildirimi yeniden OLUŞTURMAZ — önceki sürümde her saniye ana thread'de kapak çözmek
 * ANR/çökmeye yol açıyordu.
 */
class MusicService : Service() {

    companion object {
        const val CHANNEL_ID = "muzik_ch"
        const val NOTIF_ID = 77
        const val MODE_REPEAT_ONE = 0
        const val MODE_SEQUENTIAL = 1
        const val ACTION_PREV = "com.basit.dosya.PREV"
        const val ACTION_PLAY_PAUSE = "com.basit.dosya.PLAY_PAUSE"
        const val ACTION_NEXT = "com.basit.dosya.NEXT"
        const val ACTION_STOP = "com.basit.dosya.STOP_SVC"
        const val ACTION_MODE_TOGGLE = "com.basit.dosya.MODE_TOGGLE"
        var instance: MusicService? = null
    }

    var playlist: List<File> = emptyList(); private set
    var currentIndex: Int = 0; private set
    var playMode: Int = MODE_SEQUENTIAL
    var isPlaying: Boolean = false; private set
    var sourceFolderPath: String? = null; private set   // müziğin başlatıldığı klasör

    private var player: MediaPlayer? = null
    private var currentArt: Bitmap? = null              // önbellek: yalnızca şarkı değişince çözülür
    private val cbs = mutableListOf<() -> Unit>()
    private lateinit var mediaSession: MediaSessionCompat
    private val mainHandler = Handler(Looper.getMainLooper())
    private val progressHandler = Handler(Looper.getMainLooper())

    fun addCb(c: () -> Unit) { if (!cbs.contains(c)) cbs.add(c) }
    fun removeCb(c: () -> Unit) { cbs.remove(c) }
    private fun fire() { cbs.toList().forEach { try { it() } catch (_: Exception) {} } }

    inner class LocalBinder : Binder() { fun get(): MusicService = this@MusicService }
    override fun onBind(intent: Intent?): IBinder = LocalBinder()

    override fun onCreate() {
        super.onCreate()
        instance = this
        createChannel()
        setupMediaSession()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Kilit ekranı / kulaklık medya tuşları
        if (intent?.action == Intent.ACTION_MEDIA_BUTTON) {
            MediaButtonReceiver.handleIntent(mediaSession, intent)
            return START_STICKY
        }
        when (intent?.action) {
            ACTION_PREV -> { prev(); return START_STICKY }
            ACTION_PLAY_PAUSE -> { togglePlayPause(); return START_STICKY }
            ACTION_NEXT -> { next(); return START_STICKY }
            ACTION_STOP -> { stop(); return START_NOT_STICKY }
            ACTION_MODE_TOGGLE -> {
                playMode = if (playMode == MODE_REPEAT_ONE) MODE_SEQUENTIAL else MODE_REPEAT_ONE
                refreshNotification(); fire(); return START_STICKY
            }
        }
        startForeground(NOTIF_ID, buildNotif())
        return START_STICKY
    }

    override fun onDestroy() {
        instance = null
        progressHandler.removeCallbacksAndMessages(null)
        mainHandler.removeCallbacksAndMessages(null)
        if (::mediaSession.isInitialized) mediaSession.release()
        player?.release(); player = null
        currentArt = null
        super.onDestroy()
    }

    private fun setupMediaSession() {
        mediaSession = MediaSessionCompat(this, "BVEMuzik").apply {
            setFlags(MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS or MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS)
            setCallback(object : MediaSessionCompat.Callback() {
                override fun onPlay() { if (!isPlaying) { player?.start(); isPlaying = true; onPlayStateChanged() } }
                override fun onPause() { if (isPlaying) { player?.pause(); isPlaying = false; onPlayStateChanged() } }
                override fun onSkipToNext() { next() }
                override fun onSkipToPrevious() { prev() }
                override fun onStop() { stop() }
                override fun onSeekTo(pos: Long) { seekTo(pos) }
            })
            isActive = true
        }
    }

    fun currentFile(): File? = playlist.getOrNull(currentIndex)
    fun duration(): Int = player?.duration?.takeIf { it > 0 } ?: 0
    fun position(): Int = try { player?.currentPosition ?: 0 } catch (_: Exception) { 0 }

    fun play(files: List<File>, startAt: Int = 0) {
        playlist = files
        sourceFolderPath = files.firstOrNull()?.parentFile?.absolutePath
        currentIndex = startAt.coerceIn(0, (files.size - 1).coerceAtLeast(0))
        startCurrent()
    }

    fun togglePlayPause() {
        val p = player ?: return
        if (p.isPlaying) { p.pause(); isPlaying = false } else { p.start(); isPlaying = true }
        onPlayStateChanged()
    }

    fun stop() {
        progressHandler.removeCallbacksAndMessages(null)
        player?.stop(); player?.release(); player = null
        isPlaying = false
        currentArt = null
        playlist = emptyList()
        sourceFolderPath = null
        mediaSession.isActive = false
        @Suppress("DEPRECATION") stopForeground(true)
        fire()
        stopSelf()
    }

    fun next() { if (playlist.isNotEmpty()) { currentIndex = (currentIndex + 1) % playlist.size; startCurrent() } }

    fun prev() {
        if (playlist.isEmpty()) return
        val p = player
        if (p != null && p.currentPosition > 3000) { p.seekTo(0); updatePlaybackState(); fire() }
        else { currentIndex = if (currentIndex > 0) currentIndex - 1 else playlist.size - 1; startCurrent() }
    }

    fun seekTo(ms: Long) { try { player?.seekTo(ms.toInt()) } catch (_: Exception) {}; updatePlaybackState(); fire() }

    private fun onPlayStateChanged() {
        updatePlaybackState()
        refreshNotification()
        if (isPlaying) startProgressLoop() else progressHandler.removeCallbacksAndMessages(null)
        fire()
    }

    private fun startCurrent() {
        progressHandler.removeCallbacksAndMessages(null)
        val f = playlist.getOrNull(currentIndex) ?: return
        player?.release()
        currentArt = null
        try {
            player = MediaPlayer().apply {
                setDataSource(f.absolutePath)
                prepare()
                start()
                this@MusicService.isPlaying = true
                setOnCompletionListener {
                    when (playMode) {
                        MODE_REPEAT_ONE -> startCurrent()
                        else -> {
                            val nx = currentIndex + 1
                            if (nx < playlist.size) { currentIndex = nx; startCurrent() }
                            else { this@MusicService.isPlaying = false; onPlayStateChanged() }
                        }
                    }
                }
                setOnErrorListener { _, _, _ -> this@MusicService.isPlaying = false; onPlayStateChanged(); true }
            }
        } catch (_: Exception) { isPlaying = false }

        updateMetadata(f, null)     // önce kapaksız hızlıca
        updatePlaybackState()
        refreshNotification()
        startProgressLoop()
        fire()

        // Albüm kapağını ARKA PLANDA bir kez çöz, hazır olunca güncelle
        val target = f
        Thread {
            val art = getAlbumArt(target)
            if (art != null && currentFile()?.absolutePath == target.absolutePath) {
                mainHandler.post {
                    currentArt = art
                    updateMetadata(target, art)
                    refreshNotification()
                }
            }
        }.start()
    }

    private fun updateMetadata(f: File, art: Bitmap?) {
        val dur = player?.duration?.toLong()?.takeIf { it > 0 } ?: 0L
        val builder = MediaMetadataCompat.Builder()
            .putString(MediaMetadataCompat.METADATA_KEY_TITLE, f.nameWithoutExtension)
            .putString(MediaMetadataCompat.METADATA_KEY_DISPLAY_TITLE, f.nameWithoutExtension)
            .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, if (playMode == MODE_REPEAT_ONE) "Tek tekrar" else "Sırayla")
            .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, dur)
        if (art != null) builder.putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, art)
        mediaSession.setMetadata(builder.build())
    }

    /** SADECE oynatma durumunu günceller (hafif). İlerleme döngüsü bunu çağırır. */
    private fun updatePlaybackState() {
        val state = if (isPlaying) PlaybackStateCompat.STATE_PLAYING else PlaybackStateCompat.STATE_PAUSED
        val pos = position().toLong()
        mediaSession.setPlaybackState(
            PlaybackStateCompat.Builder()
                .setState(state, pos, if (isPlaying) 1f else 0f)
                .setActions(
                    PlaybackStateCompat.ACTION_PLAY or PlaybackStateCompat.ACTION_PAUSE or
                    PlaybackStateCompat.ACTION_PLAY_PAUSE or PlaybackStateCompat.ACTION_SKIP_TO_NEXT or
                    PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or PlaybackStateCompat.ACTION_STOP or
                    PlaybackStateCompat.ACTION_SEEK_TO
                ).build()
        )
    }

    private fun startProgressLoop() {
        progressHandler.removeCallbacksAndMessages(null)
        progressHandler.post(object : Runnable {
            override fun run() {
                if (isPlaying && player != null) {
                    updatePlaybackState()   // hafif — bildirim YENİDEN OLUŞTURULMAZ
                    fire()                  // uygulama içi player bar ilerlemesi
                    progressHandler.postDelayed(this, 1000)
                }
            }
        })
    }

    private fun getAlbumArt(f: File): Bitmap? = try {
        MediaMetadataRetriever().use { r ->
            r.setDataSource(f.absolutePath)
            r.embeddedPicture?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
        }
    } catch (_: Exception) { null }

    private fun pi(action: String, req: Int): PendingIntent {
        val flags = if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        return PendingIntent.getService(this, req, Intent(this, MusicService::class.java).apply { this.action = action }, flags)
    }

    /** Bildirimi yeniden oluşturur — YALNIZCA şarkı/durum/mod değişince çağrılır. */
    private fun refreshNotification() {
        try {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotif())
        } catch (_: Exception) {}
    }

    private fun buildNotif(): Notification {
        val f = currentFile()
        val title = f?.nameWithoutExtension ?: "Müzik"
        val art = currentArt   // önbellekten — burada ÇÖZÜLMEZ

        val prefs = getSharedPreferences("ayar", MODE_PRIVATE)
        val savedMode = prefs.getInt("theme", -1)
        val accentColor = if (savedMode == androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_YES)
            0xFFA38AE2.toInt() else 0xFF2B6CB0.toInt()

        val modeIcon = if (playMode == MODE_REPEAT_ONE) R.drawable.ic_repeat_one else R.drawable.ic_seq_play
        val modeLabel = if (playMode == MODE_REPEAT_ONE) "Tek tekrar" else "Sırayla"

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setColor(accentColor)
            .setColorized(true)
            .setStyle(
                MediaNotif.MediaStyle()
                    .setMediaSession(mediaSession.sessionToken)
                    .setShowActionsInCompactView(0, 2, 3)
            )
            .setContentTitle(title)
            .setContentText(modeLabel)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(isPlaying)
            .setSilent(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(R.drawable.ic_prev, "Önceki", pi(ACTION_PREV, 1))
            .addAction(modeIcon, modeLabel, pi(ACTION_MODE_TOGGLE, 5))
            .addAction(
                if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play,
                if (isPlaying) "Duraklat" else "Oynat", pi(ACTION_PLAY_PAUSE, 2)
            )
            .addAction(R.drawable.ic_next, "Sonraki", pi(ACTION_NEXT, 3))
            .addAction(R.drawable.ic_stop, "Durdur", pi(ACTION_STOP, 4))

        if (art != null) builder.setLargeIcon(art)
        return builder.build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL_ID, "Müzik", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }
}
