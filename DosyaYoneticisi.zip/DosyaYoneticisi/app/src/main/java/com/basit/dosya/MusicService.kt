package com.basit.dosya

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.os.Binder
import android.os.Build
import android.os.IBinder
import java.io.File

class MusicService : Service() {

    companion object {
        const val CHANNEL_ID = "muzik_ch"
        const val NOTIF_ID = 77
        const val MODE_REPEAT_ONE = 0
        const val MODE_SEQUENTIAL = 1
        var instance: MusicService? = null
    }

    var playlist: List<File> = emptyList()
        private set
    var currentIndex: Int = 0
        private set
    var playMode: Int = MODE_SEQUENTIAL
    var isPlaying: Boolean = false
        private set

    private var player: MediaPlayer? = null
    private val cbs = mutableListOf<() -> Unit>()

    fun addCb(c: () -> Unit) { cbs.add(c) }
    fun removeCb(c: () -> Unit) { cbs.remove(c) }
    private fun fire() { cbs.toList().forEach { it() } }

    inner class LocalBinder : Binder() {
        fun get(): MusicService = this@MusicService
    }

    override fun onBind(intent: Intent?): IBinder = LocalBinder()

    override fun onCreate() {
        super.onCreate()
        instance = this
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotif())
        return START_STICKY
    }

    override fun onDestroy() {
        instance = null
        player?.release()
        player = null
        super.onDestroy()
    }

    fun currentFile(): File? = playlist.getOrNull(currentIndex)

    fun play(files: List<File>, startAt: Int = 0) {
        playlist = files
        currentIndex = startAt.coerceIn(0, (files.size - 1).coerceAtLeast(0))
        startCurrent()
    }

    fun togglePlayPause() {
        val p = player ?: return
        if (p.isPlaying) { p.pause(); isPlaying = false }
        else { p.start(); isPlaying = true }
        updateNotif(); fire()
    }

    fun stop() {
        player?.stop(); player?.release(); player = null
        isPlaying = false
        @Suppress("DEPRECATION")
        stopForeground(true)
        stopSelf(); fire()
    }

    fun next() {
        if (playlist.isEmpty()) return
        currentIndex = (currentIndex + 1) % playlist.size
        startCurrent()
    }

    fun prev() {
        if (playlist.isEmpty()) return
        currentIndex = if (currentIndex > 0) currentIndex - 1 else playlist.size - 1
        startCurrent()
    }

    private fun startCurrent() {
        val f = playlist.getOrNull(currentIndex) ?: return
        player?.release()
        try {
            player = MediaPlayer().apply {
                setDataSource(f.absolutePath)
                prepare()
                start()
                this@MusicService.isPlaying = true
                setOnCompletionListener {
                    when (playMode) {
                        MODE_REPEAT_ONE -> startCurrent()
                        else -> {
                            val nx = currentIndex + 1
                            if (nx < playlist.size) { currentIndex = nx; startCurrent() }
                            else { this@MusicService.isPlaying = false; fire() }
                        }
                    }
                }
                setOnErrorListener { _, _, _ ->
                    this@MusicService.isPlaying = false; fire(); true
                }
            }
        } catch (_: Exception) {
            isPlaying = false
        }
        updateNotif(); fire()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL_ID, "Müzik", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun buildNotif(): Notification {
        val title = currentFile()?.nameWithoutExtension ?: "Müzik Çalıcı"
        val state = if (isPlaying) "▶ " else "⏸ "
        val builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder
            .setContentTitle("$state$title")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(isPlaying)
            .build()
    }

    private fun updateNotif() {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotif())
    }
}
