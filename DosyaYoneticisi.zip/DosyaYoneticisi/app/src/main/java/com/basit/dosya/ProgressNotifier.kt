package com.basit.dosya

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat

/**
 * Uzun dosya işlemleri (silme, taşıma, ayıklama) için engellemeyen ilerleme
 * bildirimi. Modal "bekleyin" penceresi yerine üstteki bildirim çubuğunda
 * gösterilir; kullanıcı uygulamayı kullanmaya devam edebilir.
 */
object ProgressNotifier {

    private const val CHANNEL_ID = "dosya_islem"
    private var nextId = 5000

    private fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            val ch = NotificationChannel(
                CHANNEL_ID, "Dosya işlemleri", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Silme, taşıma ve ayıklama ilerlemesi" }
            nm.createNotificationChannel(ch)
        }
    }

    /** Yeni bir ilerleme bildirimi başlatır, id döner. */
    fun start(ctx: Context, title: String): Int {
        ensureChannel(ctx)
        val id = nextId++
        val n = build(ctx, title, "Sürüyor…", true, 0, 0)
        notify(ctx, id, n)
        return id
    }

    /** İlerlemeyi günceller (opsiyonel yüzde). */
    fun update(ctx: Context, id: Int, title: String, text: String, max: Int = 0, progress: Int = 0) {
        val indeterminate = max <= 0
        notify(ctx, id, build(ctx, title, text, indeterminate, max, progress))
    }

    /** İşlemi tamamlar: kısa bir "bitti" bildirimi bırakıp otomatik kapanır. */
    fun finish(ctx: Context, id: Int, title: String, result: String) {
        ensureChannel(ctx)
        val n = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_check)
            .setContentTitle(title)
            .setContentText(result)
            .setOngoing(false)
            .setAutoCancel(true)
            .setTimeoutAfter(4000)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        notify(ctx, id, n)
    }

    fun cancel(ctx: Context, id: Int) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(id)
    }

    private fun build(
        ctx: Context, title: String, text: String,
        indeterminate: Boolean, max: Int, progress: Int
    ): Notification =
        NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setProgress(max, progress, indeterminate)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

    private fun notify(ctx: Context, id: Int, n: Notification) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        try { nm.notify(id, n) } catch (_: Exception) {}
    }
}
