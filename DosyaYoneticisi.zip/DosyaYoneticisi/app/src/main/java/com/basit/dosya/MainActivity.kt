package com.basit.dosya

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import com.basit.dosya.databinding.ActivityMainBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.io.File

class MainActivity : AppCompatActivity() {

    companion object {
        val TEXT_EXTS = setOf("txt", "log", "md", "json", "csv", "srt", "ini")
    }

    private lateinit var b: ActivityMainBinding
    private val prefs by lazy { getSharedPreferences("ayar", MODE_PRIVATE) }

    private var rootLabel: String = ""
    private var binMode: Boolean = false
    private val navChain = mutableListOf<File>()
    private var openFile: File? = null
    private var recentFiles: List<File>? = null   // null = normal klasör, non-null = son dosyalar modu

    private var searchActive = false
    private var _searchQuery = ""

    fun currentDir(): File? = navChain.lastOrNull()
    fun currentBinMode(): Boolean = binMode
    fun showHiddenFiles(): Boolean = prefs.getBoolean("showHidden", false)
    fun currentSearchQuery(): String = if (searchActive) _searchQuery else ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mode = prefs.getInt("theme", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        AppCompatDelegate.setDefaultNightMode(mode)

        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnTheme.setOnClickListener { toggleTheme() }
        b.btnCreate.setOnClickListener { showCreateDialog() }
        b.btnEye.setOnClickListener { toggleHiddenFiles() }
        b.btnSearch.setOnClickListener { toggleSearch() }
        b.btnSearchClose.setOnClickListener { closeSearch() }

        b.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, c: Int, d: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, c: Int, d: Int) {}
            override fun afterTextChanged(s: Editable?) {
                _searchQuery = s?.toString() ?: ""
                (supportFragmentManager.findFragmentById(R.id.fragmentContainer) as? FolderFragment)
                    ?.applySearch(_searchQuery)
            }
        })

        updateThemeIcon()
        updateEyeIcon()

        savedInstanceState?.let { st ->
            rootLabel = st.getString("rootLabel", "")
            binMode = st.getBoolean("binMode", false)
            st.getStringArrayList("navChain")?.forEach { navChain.add(File(it)) }
            st.getString("openFile")?.let { openFile = File(it) }
        }

        when {
            openFile != null && openFile!!.exists() -> showTextEditor()
            navChain.isNotEmpty() && navChain.last().exists() -> { openFile = null; showFolder() }
            else -> { navChain.clear(); openFile = null; showHome() }
        }
        updateBreadcrumb()

        onBackPressedDispatcher.addCallback(this) { handleBack() }
        if (!hasPerm()) askPerm()
        handleOpenIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent); setIntent(intent); handleOpenIntent(intent)
    }

    private fun handleOpenIntent(intent: Intent?) {
        val path = intent?.getStringExtra("openFolderPath") ?: return
        val label = intent.getStringExtra("openFolderLabel") ?: File(path).name
        intent.removeExtra("openFolderPath"); intent.removeExtra("openFolderLabel")
        val dir = File(path); if (dir.exists()) openFolderRoot(dir, label)
    }

    override fun onSaveInstanceState(out: Bundle) {
        super.onSaveInstanceState(out)
        out.putString("rootLabel", rootLabel)
        out.putBoolean("binMode", binMode)
        out.putStringArrayList("navChain", ArrayList(navChain.map { it.absolutePath }))
        openFile?.let { out.putString("openFile", it.absolutePath) }
    }

    override fun onResume() { super.onResume(); updateThemeIcon(); updateEyeIcon() }

    // ---------- navigasyon ----------

    fun openFolderRoot(path: File, label: String, binMode: Boolean = false) {
        this.rootLabel = label; this.binMode = binMode
        navChain.clear(); navChain.add(path)
        openFile = null; recentFiles = null
        closeSearch(); safeReplace(FolderFragment()); updateBreadcrumb()
    }

    fun openRecentFiles(files: List<File>) {
        recentFiles = files
        rootLabel = "Son Dosyalar"; binMode = false
        navChain.clear()
        openFile = null; closeSearch()
        safeReplace(RecentFilesFragment.newInstance(files)); updateBreadcrumb()
    }

    fun navigateInto(dir: File) {
        navChain.add(dir); openFile = null
        closeSearch(); safeReplace(FolderFragment()); updateBreadcrumb()
    }

    fun openTextFile(file: File, readOnly: Boolean = false) {
        openFile = file
        safeReplace(TextEditorFragment.newInstance(file.absolutePath, readOnly)); updateBreadcrumb()
    }

    fun closeTextFile() { openFile = null; safeReplace(FolderFragment()); updateBreadcrumb() }

    fun openMediaCategory(type: Int, title: String) {
        startActivity(Intent(this, MediaFolderActivity::class.java).apply {
            putExtra(MediaFolderActivity.EXTRA_TYPE, type)
            putExtra(MediaFolderActivity.EXTRA_TITLE, title)
        })
    }

    private fun safeReplace(fragment: androidx.fragment.app.Fragment) {
        if (isFinishing || isDestroyed) return
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commitAllowingStateLoss()
    }

    private fun showHome() = safeReplace(HomeFragment())
    private fun showFolder() = safeReplace(FolderFragment())
    private fun showTextEditor() { val f = openFile ?: return; safeReplace(TextEditorFragment.newInstance(f.absolutePath)) }

    // ---------- breadcrumb ----------

    fun updateBreadcrumb() {
        b.breadcrumbBar.removeAllViews()
        val d = resources.displayMetrics.density
        fun dp(v: Float) = (v * d).toInt()

        fun addSep() = b.breadcrumbBar.addView(TextView(this).apply {
            text = " › "; textSize = 12f
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_dim))
        })

        fun chip(label: String, current: Boolean, onClick: (() -> Unit)?) {
            val chip = TextView(this).apply {
                text = label; textSize = 12f
                setPadding(dp(10f), dp(6f), dp(10f), dp(6f))
                background = ContextCompat.getDrawable(this@MainActivity,
                    if (current) R.drawable.bg_chip_accent else R.drawable.bg_chip)
                setTextColor(ContextCompat.getColor(this@MainActivity,
                    if (current) R.color.on_accent else R.color.text_main))
                maxLines = 1
                if (onClick != null) { isClickable = true; setOnClickListener { onClick() } }
            }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.marginEnd = dp(4f); chip.layoutParams = lp
            b.breadcrumbBar.addView(chip)
        }

        val atHome = navChain.isEmpty() && openFile == null && recentFiles == null
        chip("Ana Sayfa", current = atHome) {
            navChain.clear(); openFile = null; recentFiles = null; closeSearch(); showHome(); updateBreadcrumb()
        }

        recentFiles?.let {
            addSep()
            chip("Son Dosyalar", current = openFile == null) {
                openFile = null; safeReplace(RecentFilesFragment.newInstance(it)); updateBreadcrumb()
            }
            openFile?.let { f -> addSep(); chip(f.name, current = true, onClick = null) }
        } ?: run {
            navChain.forEachIndexed { i, dir ->
                val label = if (i == 0) rootLabel else dir.name
                val isLast = i == navChain.lastIndex && openFile == null
                addSep()
                chip(label, current = isLast) {
                    while (navChain.size > i + 1) navChain.removeAt(navChain.size - 1)
                    openFile = null; closeSearch()
                    (supportFragmentManager.findFragmentById(R.id.fragmentContainer) as? FolderFragment)
                        ?.loadDirFromMain() ?: safeReplace(FolderFragment())
                    updateBreadcrumb()
                }
            }
            openFile?.let { f -> addSep(); chip(f.name, current = true, onClick = null) }
        }

        // Üst çubuk butonları görünürlüğü
        val inFolder = navChain.isNotEmpty() && openFile == null && recentFiles == null
        val inHome = atHome
        b.btnTheme.visibility = if (inHome) View.VISIBLE else View.GONE
        b.btnEye.visibility = if (inHome) View.VISIBLE else View.GONE
        b.btnCreate.visibility = if (inFolder && !binMode) View.VISIBLE else View.GONE
        b.btnSearch.visibility = if (inFolder) View.VISIBLE else View.GONE
        if (!inFolder) { closeSearch() }

        b.breadcrumbBar.post {
            (b.breadcrumbBar.parent as? android.widget.HorizontalScrollView)?.fullScroll(View.FOCUS_RIGHT)
        }
    }

    // ---------- arama ----------

    private fun toggleSearch() {
        if (searchActive) closeSearch() else {
            searchActive = true
            b.searchRow.visibility = View.VISIBLE
            b.etSearch.requestFocus()
        }
    }

    private fun closeSearch() {
        searchActive = false
        _searchQuery = ""
        b.searchRow.visibility = View.GONE
        b.etSearch.setText("")
        (supportFragmentManager.findFragmentById(R.id.fragmentContainer) as? FolderFragment)?.applySearch("")
    }

    // ---------- gizli dosyalar ----------

    private fun toggleHiddenFiles() {
        val current = prefs.getBoolean("showHidden", false)
        prefs.edit().putBoolean("showHidden", !current).apply()
        updateEyeIcon()
        (supportFragmentManager.findFragmentById(R.id.fragmentContainer) as? FolderFragment)?.refreshList()
    }

    private fun updateEyeIcon() {
        val show = prefs.getBoolean("showHidden", false)
        b.btnEye.setImageResource(if (show) R.drawable.ic_eye else R.drawable.ic_eye_off)
        b.btnEye.imageTintList = android.content.res.ColorStateList.valueOf(
            ContextCompat.getColor(this, R.color.accent))
    }

    // ---------- yeni oluştur ----------

    private fun showCreateDialog() {
        val dir = currentDir() ?: return
        MaterialAlertDialogBuilder(this)
            .setItems(arrayOf("Yeni klasör", "Yeni dosya")) { _, which ->
                val isFolder = which == 0
                val et = EditText(this).apply { hint = if (isFolder) "Klasör adı" else "örnek.txt" }
                val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 16, 48, 0); addView(et) }
                MaterialAlertDialogBuilder(this)
                    .setTitle(if (isFolder) "Yeni klasör" else "Yeni dosya").setView(wrap)
                    .setPositiveButton("Oluştur") { _, _ ->
                        val name = et.text.toString().trim()
                        if (name.isEmpty() || name.contains('/')) return@setPositiveButton showMsg("Geçersiz ad")
                        val target = File(dir, name)
                        if (target.exists()) return@setPositiveButton showMsg("Bu adla öğe zaten var")
                        val ok = try { if (isFolder) target.mkdirs() else target.createNewFile() } catch (_: Exception) { false }
                        if (ok) { refreshFolder(); showMsg("Oluşturuldu: $name") }
                        else showMsg("Oluşturulamadı")
                    }.setNegativeButton("İptal", null).show()
            }.show()
    }

    private fun refreshFolder() {
        (supportFragmentManager.findFragmentById(R.id.fragmentContainer) as? FolderFragment)?.refreshList()
    }

    // ---------- geri tuşu ----------

    private fun handleBack() {
        if (searchActive) { closeSearch(); return }
        when {
            openFile != null -> {
                val frag = supportFragmentManager.findFragmentById(R.id.fragmentContainer) as? TextEditorFragment
                frag?.requestClose() ?: closeTextFile()
            }
            recentFiles != null -> { recentFiles = null; showHome(); updateBreadcrumb() }
            navChain.size > 1 -> {
                navChain.removeAt(navChain.size - 1); closeSearch()
                safeReplace(FolderFragment()); updateBreadcrumb()
            }
            navChain.size == 1 -> { navChain.clear(); closeSearch(); showHome(); updateBreadcrumb() }
            else -> showExitDialog()
        }
    }

    private fun showExitDialog() {
        MaterialAlertDialogBuilder(this)
            .setMessage("Uygulamadan çık?")
            .setPositiveButton("Çık") { _, _ -> finish() }
            .setNegativeButton("Hayır", null).show()
    }

    // ---------- tema ----------

    private fun toggleTheme() {
        val night = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        val newMode = if (night) AppCompatDelegate.MODE_NIGHT_NO else AppCompatDelegate.MODE_NIGHT_YES
        prefs.edit().putInt("theme", newMode).apply()
        AppCompatDelegate.setDefaultNightMode(newMode)
    }

    private fun updateThemeIcon() {
        val night = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        b.btnTheme.setImageResource(if (night) R.drawable.ic_sun else R.drawable.ic_moon)
        b.btnTheme.imageTintList = android.content.res.ColorStateList.valueOf(ContextCompat.getColor(this, R.color.accent))
    }

    // ---------- izin ----------

    private fun hasPerm() = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
    else ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    private fun askPerm() {
        if (Build.VERSION.SDK_INT >= 30) {
            MaterialAlertDialogBuilder(this)
                .setTitle("İzin gerekli").setMessage("'Tüm dosyalara erişim' izni gerekiyor.")
                .setCancelable(false)
                .setPositiveButton("Ayarları aç") { _, _ ->
                    try { startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))) }
                    catch (_: Exception) { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
                }.show()
        } else permLauncher.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
    }

    fun sdRoot(): File? = getExternalFilesDirs(null).filterNotNull().drop(1).firstOrNull()
        ?.absolutePath?.substringBefore("/Android/")?.let { File(it) }?.takeIf { it.exists() }

    fun showMsg(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
