package com.basit.dosya

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.webkit.MimeTypeMap
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.basit.dosya.databinding.ActivityMainBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding

    enum class Screen { HOME, BROWSE, CATEGORY, BIN }

    private var screen = Screen.HOME
    private var curDir: File? = null
    private var categoryType = 0            // 1=görüntü 2=ses 3=video
    private var categoryTitle = ""
    private val navStack = ArrayDeque<File>()

    private var master: List<File> = emptyList()
    private var filter = ""
    private val selection = LinkedHashSet<String>()
    private lateinit var adapter: FileAdapter

    private var clipboard: List<File> = emptyList()
    private var clipMove = false

    private var started = false
    private var pendingState: Bundle? = null

    private val prefs by lazy { getSharedPreferences("ayar", MODE_PRIVATE) }
    private var showHidden
        get() = prefs.getBoolean("gizli", false)
        set(v) { prefs.edit().putBoolean("gizli", v).apply() }

    companion object {
        val TEXT_EXTS = setOf("txt", "log", "md", "json", "csv", "srt", "ini")
    }

    // ---------- yaşam döngüsü ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        pendingState = savedInstanceState

        adapter = FileAdapter(selection, ::onItemClick, ::onItemLong)
        b.rv.layoutManager = LinearLayoutManager(this)
        b.rv.addItemDecoration(DividerItemDecoration(this, DividerItemDecoration.VERTICAL))
        b.rv.adapter = adapter

        b.btnTheme.setOnClickListener { toggleTheme() }
        b.btnMenu.setOnClickListener { showMenu() }
        b.btnUp.setOnClickListener { onUp() }
        b.btnSearch.setOnClickListener { toggleSearch(true) }
        b.btnSearchClose.setOnClickListener { toggleSearch(false) }
        b.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, c: Int, d: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, c: Int, d: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filter = s?.toString()?.trim() ?: ""
                applyFilter()
            }
        })

        b.tileInternal.setOnClickListener { enterRoot(Environment.getExternalStorageDirectory()) }
        b.tileSd.setOnClickListener {
            val sd = sdRoot()
            if (sd != null) enterRoot(sd) else toast("SD kart bulunamadı")
        }
        b.tileDownloads.setOnClickListener {
            enterRoot(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS))
        }
        b.tileImages.setOnClickListener { openCategory(1, "Görüntüler") }
        b.tileAudio.setOnClickListener { openCategory(2, "Ses") }
        b.tileVideos.setOnClickListener { openCategory(3, "Videolar") }
        b.tileBin.setOnClickListener { openBin() }

        b.btnPasteOk.setOnClickListener { doPaste() }
        b.btnPasteCancel.setOnClickListener { clipboard = emptyList(); updateBars() }

        b.actCopy.setOnClickListener { setClipboard(false) }
        b.actMove.setOnClickListener { setClipboard(true) }
        b.actRename.setOnClickListener { renameSelected() }
        b.actDelete.setOnClickListener { deleteSelected() }
        b.actMore.setOnClickListener { moreMenu() }
        b.actRestore.setOnClickListener { restoreSelected() }
        b.actPermDelete.setOnClickListener { permDeleteSelected() }

        onBackPressedDispatcher.addCallback(this) {
            when {
                selection.isNotEmpty() -> clearSelection()
                b.searchRow.visibility == View.VISIBLE -> toggleSearch(false)
                screen == Screen.BROWSE -> {
                    if (navStack.size > 1) {
                        navStack.removeLast()
                        openDir(navStack.last(), push = false)
                    } else showHome()
                }
                screen == Screen.CATEGORY || screen == Screen.BIN -> showHome()
                else -> finish()
            }
        }
        updateThemeIcon()
    }

    override fun onResume() {
        super.onResume()
        if (hasPerm()) {
            if (!started) { started = true; restoreOrHome() } else refresh()
        } else askPerm()
    }

    override fun onSaveInstanceState(out: Bundle) {
        super.onSaveInstanceState(out)
        out.putString("screen", screen.name)
        out.putString("dir", curDir?.absolutePath)
        out.putInt("catT", categoryType)
        out.putString("catN", categoryTitle)
        out.putStringArrayList("stack", ArrayList(navStack.map { it.absolutePath }))
    }

    private fun restoreOrHome() {
        val st = pendingState
        pendingState = null
        if (st == null) { showHome(); return }
        val sc = st.getString("screen") ?: return showHome()
        st.getStringArrayList("stack")?.forEach { navStack.addLast(File(it)) }
        when (sc) {
            Screen.BROWSE.name -> {
                val d = st.getString("dir")?.let { File(it) }
                if (d != null && d.exists()) openDir(d, push = navStack.isEmpty()) else showHome()
            }
            Screen.CATEGORY.name -> openCategory(st.getInt("catT", 1), st.getString("catN") ?: "Görüntüler")
            Screen.BIN.name -> openBin()
            else -> showHome()
        }
    }

    // ---------- izin ----------

    private fun hasPerm(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) ==
            PackageManager.PERMISSION_GRANTED

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    private var permDialog: AlertDialog? = null

    private fun askPerm() {
        if (Build.VERSION.SDK_INT >= 30) {
            if (permDialog?.isShowing == true) return
            permDialog = MaterialAlertDialogBuilder(this)
                .setTitle("İzin gerekli")
                .setMessage("Dosyalarını yönetebilmek için \"Tüm dosyalara erişim\" iznini vermen gerekiyor.")
                .setCancelable(false)
                .setPositiveButton("Ayarları aç") { _, _ ->
                    try {
                        startActivity(
                            Intent(
                                Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                Uri.parse("package:$packageName")
                            )
                        )
                    } catch (_: Exception) {
                        startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                    }
                }
                .show()
        } else {
            permLauncher.launch(
                arrayOf(
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                )
            )
        }
    }

    // ---------- ekranlar ----------

    private fun sdRoot(): File? =
        getExternalFilesDirs(null).filterNotNull().drop(1).firstOrNull()
            ?.absolutePath?.substringBefore("/Android/")?.let { File(it) }
            ?.takeIf { it.exists() }

    private fun enterRoot(dir: File) {
        navStack.clear()
        openDir(dir)
    }

    private fun showHome() {
        screen = Screen.HOME
        curDir = null
        navStack.clear()
        clearSelection()
        b.homeScroll.visibility = View.VISIBLE
        b.rv.visibility = View.GONE
        b.tvEmpty.visibility = View.GONE
        b.btnUp.visibility = View.GONE
        b.tvPath.text = "Ana sayfa"
        toggleSearch(false)
        updateBars()

        val internal = Environment.getExternalStorageDirectory()
        try {
            val st = StatFs(internal.absolutePath)
            val total = st.blockCountLong * st.blockSizeLong
            val free = st.availableBlocksLong * st.blockSizeLong
            b.subInternal.text = FileOps.fmtSize(total - free) + " / " + FileOps.fmtSize(total)
        } catch (_: Exception) { b.subInternal.text = "" }

        val sd = sdRoot()
        if (sd != null) {
            b.tileSd.alpha = 1f
            try {
                val st = StatFs(sd.absolutePath)
                val total = st.blockCountLong * st.blockSizeLong
                val free = st.availableBlocksLong * st.blockSizeLong
                b.subSd.text = FileOps.fmtSize(total - free) + " / " + FileOps.fmtSize(total)
            } catch (_: Exception) { b.subSd.text = "" }
        } else {
            b.tileSd.alpha = 0.4f
            b.subSd.text = "yok"
        }
        val binCount = FileOps.binDir().list()?.count { it != "index.json" } ?: 0
        b.subBin.text = "$binCount öğe"
    }

    private fun showList() {
        b.homeScroll.visibility = View.GONE
        b.rv.visibility = View.VISIBLE
        b.btnUp.visibility = View.VISIBLE
    }

    private fun prettyPath(f: File): String {
        val p = f.absolutePath
        val internal = Environment.getExternalStorageDirectory().absolutePath
        val sd = sdRoot()?.absolutePath
        return when {
            p == internal -> "Ana bellek"
            p.startsWith("$internal/") -> "Ana bellek" + p.removePrefix(internal)
            sd != null && p == sd -> "SD kart"
            sd != null && p.startsWith("$sd/") -> "SD kart" + p.removePrefix(sd)
            else -> p
        }
    }

    private fun openDir(dir: File, push: Boolean = true) {
        screen = Screen.BROWSE
        curDir = dir
        if (push) navStack.addLast(dir)
        clearSelection()
        showList()
        b.tvPath.text = prettyPath(dir)
        updateBars()
        loadList { listDir(dir) }
    }

    private fun listDir(dir: File): List<File> {
        val all = dir.listFiles()?.toList() ?: emptyList()
        val vis = if (showHidden) all else all.filter { !it.name.startsWith(".") }
        return vis.sortedWith(
            compareBy({ !it.isDirectory }, { it.name.lowercase(Locale("tr")) })
        )
    }

    private fun openCategory(type: Int, title: String) {
        screen = Screen.CATEGORY
        curDir = null
        navStack.clear()
        categoryType = type
        categoryTitle = title
        clearSelection()
        showList()
        b.tvPath.text = title
        updateBars()
        loadList { queryMedia(type) }
    }

    private fun queryMedia(type: Int): List<File> {
        val uri = when (type) {
            1 -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            2 -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            else -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }
        val out = ArrayList<File>()
        try {
            contentResolver.query(
                uri, arrayOf(MediaStore.MediaColumns.DATA),
                null, null, MediaStore.MediaColumns.DATE_MODIFIED + " DESC"
            )?.use { c ->
                val di = c.getColumnIndex(MediaStore.MediaColumns.DATA)
                while (c.moveToNext()) {
                    val p = c.getString(di) ?: continue
                    val f = File(p)
                    if (f.exists()) out.add(f)
                }
            }
        } catch (_: Exception) {}
        return out
    }

    private fun openBin() {
        screen = Screen.BIN
        curDir = FileOps.binDir()
        navStack.clear()
        clearSelection()
        showList()
        b.tvPath.text = "Geri Dönüşüm Kutusu"
        updateBars()
        loadList {
            FileOps.binDir().listFiles()?.filter { it.name != "index.json" }
                ?.sortedByDescending { it.lastModified() } ?: emptyList()
        }
    }

    private fun loadList(block: () -> List<File>) {
        lifecycleScope.launch {
            val list = withContext(Dispatchers.IO) { block() }
            master = list
            applyFilter()
        }
    }

    private fun applyFilter() {
        val shown = if (filter.isEmpty()) master
        else master.filter { it.name.lowercase(Locale("tr")).contains(filter.lowercase(Locale("tr"))) }
        adapter.submit(shown)
        b.tvEmpty.visibility =
            if (shown.isEmpty() && screen != Screen.HOME) View.VISIBLE else View.GONE
    }

    private fun refresh() {
        when (screen) {
            Screen.HOME -> showHome()
            Screen.BROWSE -> curDir?.let { d -> loadList { listDir(d) } }
            Screen.CATEGORY -> loadList { queryMedia(categoryType) }
            Screen.BIN -> loadList {
                FileOps.binDir().listFiles()?.filter { it.name != "index.json" }
                    ?.sortedByDescending { it.lastModified() } ?: emptyList()
            }
        }
    }

    private fun onUp() {
        if (selection.isNotEmpty()) { clearSelection(); return }
        when (screen) {
            Screen.BROWSE -> {
                val parent = curDir?.parentFile
                if (parent != null && parent.canRead() &&
                    parent.absolutePath.startsWith("/storage")
                ) openDir(parent) else showHome()
            }
            Screen.CATEGORY, Screen.BIN -> showHome()
            else -> {}
        }
    }

    private fun toggleSearch(show: Boolean) {
        b.searchRow.visibility = if (show) View.VISIBLE else View.GONE
        if (!show) { b.etSearch.setText(""); filter = ""; applyFilter() }
        else b.etSearch.requestFocus()
    }

    // ---------- öğe etkileşimi ----------

    private fun onItemClick(f: File) {
        if (selection.isNotEmpty()) { toggleSel(f); return }
        if (f.isDirectory) {
            if (screen == Screen.BIN) toast("Kutudaki klasörler önce geri yüklenmeli")
            else openDir(f)
            return
        }
        val ext = f.extension.lowercase(Locale.ROOT)
        when {
            ext in TEXT_EXTS -> startActivity(
                Intent(this, ViewerActivity::class.java).putExtra("path", f.absolutePath)
            )
            ext == "zip" -> zipDialog(f)
            else -> openWith(f)
        }
    }

    private fun onItemLong(f: File) {
        toggleSel(f)
    }

    private fun toggleSel(f: File) {
        val p = f.absolutePath
        if (selection.contains(p)) selection.remove(p) else selection.add(p)
        if (selection.isEmpty()) clearSelection() else enterSelUi()
        adapter.notifyDataSetChanged()
    }

    private fun enterSelUi() {
        b.btnUp.setImageResource(R.drawable.ic_close)
        b.btnUp.visibility = View.VISIBLE
        b.tvPath.text = "${selection.size} seçildi"
        b.selBar.visibility = if (screen == Screen.BIN) View.GONE else View.VISIBLE
        b.binBar.visibility = if (screen == Screen.BIN) View.VISIBLE else View.GONE
        b.pasteBar.visibility = View.GONE
    }

    private fun clearSelection() {
        selection.clear()
        b.btnUp.setImageResource(R.drawable.ic_up)
        b.selBar.visibility = View.GONE
        b.binBar.visibility = View.GONE
        when (screen) {
            Screen.BROWSE -> b.tvPath.text = curDir?.let { prettyPath(it) } ?: ""
            Screen.CATEGORY -> b.tvPath.text = categoryTitle
            Screen.BIN -> b.tvPath.text = "Geri Dönüşüm Kutusu"
            Screen.HOME -> b.tvPath.text = "Ana sayfa"
        }
        adapter.notifyDataSetChanged()
        updateBars()
    }

    private fun selectedFiles(): List<File> = master.filter { selection.contains(it.absolutePath) }

    // ---------- pano / yapıştır ----------

    private fun setClipboard(move: Boolean) {
        clipboard = selectedFiles()
        clipMove = move
        clearSelection()
        toast(if (move) "Taşınacak: hedef klasöre git" else "Kopyalanacak: hedef klasöre git")
        updateBars()
    }

    private fun updateBars() {
        val show = clipboard.isNotEmpty() && screen == Screen.BROWSE && selection.isEmpty()
        b.pasteBar.visibility = if (show) View.VISIBLE else View.GONE
        if (show) {
            b.tvPaste.text = "${clipboard.size} öğe — " +
                (if (clipMove) "buraya taşı" else "buraya kopyala")
        }
    }

    private fun doPaste() {
        val dest = curDir ?: return
        val items = clipboard
        if (items.isEmpty()) return
        val dlg = progress(if (clipMove) "Taşınıyor…" else "Kopyalanıyor…")
        lifecycleScope.launch {
            var ok = 0
            withContext(Dispatchers.IO) {
                for (f in items) {
                    if (clipMove && f.parentFile?.absolutePath == dest.absolutePath) continue
                    val done = if (clipMove) FileOps.moveInto(f, dest) else FileOps.copyInto(f, dest)
                    if (done) ok++
                    scan(f); scan(File(dest, f.name))
                }
            }
            dlg.dismiss()
            clipboard = emptyList()
            toast("$ok öğe tamam")
            refresh()
            updateBars()
        }
    }

    // ---------- seçim eylemleri ----------

    private fun renameSelected() {
        val f = selectedFiles().singleOrNull()
            ?: return toast("Yeniden adlandırmak için tek öğe seç")
        val et = EditText(this).apply { setText(f.name); setSelection(f.name.length) }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 16, 48, 0)
            addView(et)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Yeniden adlandır")
            .setView(box)
            .setPositiveButton("Tamam") { _, _ ->
                val name = et.text.toString().trim()
                if (name.isEmpty() || name.contains('/')) return@setPositiveButton toast("Geçersiz ad")
                val target = File(f.parentFile, name)
                if (target.exists()) return@setPositiveButton toast("Bu adla bir öğe zaten var")
                if (f.renameTo(target)) { scan(f); scan(target); clearSelection(); refresh() }
                else toast("Yeniden adlandırılamadı")
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun deleteSelected() {
        val files = selectedFiles()
        if (files.isEmpty()) return
        MaterialAlertDialogBuilder(this)
            .setTitle("Sil")
            .setMessage("${files.size} öğe geri dönüşüm kutusuna taşınacak.")
            .setPositiveButton("Sil") { _, _ ->
                val dlg = progress("Siliniyor…")
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) { files.forEach { FileOps.toBin(it); scan(it) } }
                    dlg.dismiss(); clearSelection(); refresh()
                }
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun restoreSelected() {
        val files = selectedFiles()
        if (files.isEmpty()) return
        val dlg = progress("Geri yükleniyor…")
        lifecycleScope.launch {
            var ok = 0
            withContext(Dispatchers.IO) {
                files.forEach { if (FileOps.restore(it)) ok++ }
            }
            dlg.dismiss()
            toast("$ok öğe geri yüklendi")
            clearSelection(); refresh()
        }
    }

    private fun permDeleteSelected() {
        val files = selectedFiles()
        if (files.isEmpty()) return
        MaterialAlertDialogBuilder(this)
            .setTitle("Kalıcı sil")
            .setMessage("${files.size} öğe KALICI olarak silinecek. Bu işlem geri alınamaz.")
            .setPositiveButton("Kalıcı sil") { _, _ ->
                val dlg = progress("Siliniyor…")
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) { files.forEach { FileOps.permDelete(it) } }
                    dlg.dismiss(); clearSelection(); refresh()
                }
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun moreMenu() {
        val files = selectedFiles()
        if (files.isEmpty()) return
        val single = files.size == 1
        val items = mutableListOf("Paylaş", "Sıkıştır (zip)")
        if (single && files[0].isFile) items.add("Şununla aç")
        if (single) items.add("Özellikler")
        MaterialAlertDialogBuilder(this)
            .setItems(items.toTypedArray()) { _, i ->
                when (items[i]) {
                    "Paylaş" -> share(files)
                    "Sıkıştır (zip)" -> compress(files)
                    "Şununla aç" -> openWith(files[0])
                    "Özellikler" -> properties(files[0])
                }
            }
            .show()
    }

    private fun uriFor(f: File): Uri =
        FileProvider.getUriForFile(this, "$packageName.fileprovider", f)

    private fun mimeOf(f: File): String =
        MimeTypeMap.getSingleton()
            .getMimeTypeFromExtension(f.extension.lowercase(Locale.ROOT)) ?: "*/*"

    private fun share(files: List<File>) {
        try {
            val flat = files.filter { it.isFile }
            if (flat.isEmpty()) return toast("Klasörler paylaşılamaz — önce sıkıştır")
            val intent = if (flat.size == 1) {
                Intent(Intent.ACTION_SEND).apply {
                    type = mimeOf(flat[0])
                    putExtra(Intent.EXTRA_STREAM, uriFor(flat[0]))
                }
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                    type = "*/*"
                    putParcelableArrayListExtra(
                        Intent.EXTRA_STREAM, ArrayList(flat.map { uriFor(it) })
                    )
                }
            }
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(intent, "Paylaş"))
            clearSelection()
        } catch (_: Exception) { toast("Paylaşılamadı") }
    }

    private fun compress(files: List<File>) {
        val destDir = curDir ?: files[0].parentFile ?: return
        val name = "arsiv_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) + ".zip"
        val destZip = FileOps.uniqueIn(destDir, name)
        val dlg = progress("Sıkıştırılıyor…")
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) { FileOps.zipFiles(files, destZip) }
            dlg.dismiss()
            toast(if (ok) "Oluşturuldu: ${destZip.name}" else "Sıkıştırılamadı")
            scan(destZip)
            clearSelection(); refresh()
        }
    }

    private fun zipDialog(f: File) {
        MaterialAlertDialogBuilder(this)
            .setTitle(f.name)
            .setItems(arrayOf("Buraya ayıkla", "Şununla aç")) { _, i ->
                if (i == 0) {
                    val destDir = FileOps.uniqueIn(
                        f.parentFile ?: return@setItems, f.nameWithoutExtension
                    )
                    val dlg = progress("Ayıklanıyor…")
                    lifecycleScope.launch {
                        val ok = withContext(Dispatchers.IO) { FileOps.unzip(f, destDir) }
                        dlg.dismiss()
                        toast(if (ok) "Ayıklandı: ${destDir.name}" else "Ayıklanamadı")
                        refresh()
                    }
                } else openWith(f)
            }
            .show()
    }

    private fun openWith(f: File) {
        try {
            val i = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uriFor(f), mimeOf(f))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(i, "Şununla aç"))
        } catch (_: Exception) { toast("Açacak uygulama bulunamadı") }
    }

    private fun properties(f: File) {
        val dlg = progress("Hesaplanıyor…")
        lifecycleScope.launch {
            val size = withContext(Dispatchers.IO) { FileOps.sizeOf(f) }
            dlg.dismiss()
            val df = SimpleDateFormat("d MMM yyyy HH:mm", Locale("tr"))
            val sb = StringBuilder()
            sb.append("Ad: ${f.name}\n\n")
            if (screen == Screen.BIN) {
                val orig = FileOps.binOriginal(f.name)
                if (orig != null) sb.append("Asıl yer: $orig\n\n")
            }
            sb.append("Yol: ${f.absolutePath}\n\n")
            sb.append("Tür: ${if (f.isDirectory) "Klasör" else (f.extension.uppercase(Locale.ROOT).ifEmpty { "Dosya" })}\n\n")
            sb.append("Boyut: ${FileOps.fmtSize(size)}\n\n")
            if (f.isDirectory) sb.append("İçerik: ${f.list()?.size ?: 0} öğe\n\n")
            sb.append("Değiştirilme: ${df.format(Date(f.lastModified()))}")
            MaterialAlertDialogBuilder(this@MainActivity)
                .setTitle("Özellikler")
                .setMessage(sb.toString())
                .setPositiveButton("Tamam", null)
                .show()
        }
    }

    // ---------- menü / tema ----------

    private fun showMenu() {
        val items = mutableListOf(
            if (showHidden) "Gizli dosyaları gizle" else "Gizli dosyaları göster"
        )
        if (screen == Screen.BIN) items.add("Kutuyu boşalt")
        MaterialAlertDialogBuilder(this)
            .setItems(items.toTypedArray()) { _, i ->
                when (items[i]) {
                    "Gizli dosyaları gizle", "Gizli dosyaları göster" -> {
                        showHidden = !showHidden; refresh()
                    }
                    "Kutuyu boşalt" -> {
                        MaterialAlertDialogBuilder(this)
                            .setMessage("Kutudaki her şey KALICI olarak silinecek.")
                            .setPositiveButton("Boşalt") { _, _ ->
                                val dlg = progress("Boşaltılıyor…")
                                lifecycleScope.launch {
                                    withContext(Dispatchers.IO) { FileOps.emptyBin() }
                                    dlg.dismiss(); refresh()
                                }
                            }
                            .setNegativeButton("İptal", null)
                            .show()
                    }
                }
            }
            .show()
    }

    private fun toggleTheme() {
        val night = resources.configuration.uiMode and
            android.content.res.Configuration.UI_MODE_NIGHT_MASK ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        AppCompatDelegate.setDefaultNightMode(
            if (night) AppCompatDelegate.MODE_NIGHT_NO else AppCompatDelegate.MODE_NIGHT_YES
        )
    }

    private fun updateThemeIcon() {
        val night = resources.configuration.uiMode and
            android.content.res.Configuration.UI_MODE_NIGHT_MASK ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        b.btnTheme.setImageResource(if (night) R.drawable.ic_sun else R.drawable.ic_moon)
    }

    // ---------- yardımcılar ----------

    private fun progress(msg: String): AlertDialog {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(48, 40, 48, 40)
            addView(ProgressBar(this@MainActivity))
            addView(TextView(this@MainActivity).apply {
                text = msg
                setPadding(32, 12, 0, 0)
                textSize = 15f
            })
        }
        return MaterialAlertDialogBuilder(this)
            .setView(box)
            .setCancelable(false)
            .show()
    }

    private fun scan(f: File) {
        try {
            MediaScannerConnection.scanFile(this, arrayOf(f.absolutePath), null, null)
        } catch (_: Exception) {}
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
