package com.basit.dosya

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.basit.dosya.databinding.ActivityMainBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.io.File
import java.util.UUID

class MainActivity : AppCompatActivity() {

    companion object {
        val TEXT_EXTS = setOf("txt", "log", "md", "json", "csv", "srt", "ini")
        const val HOME_TAB_ID = "home"
    }

    private lateinit var b: ActivityMainBinding
    private val prefs by lazy { getSharedPreferences("ayar", MODE_PRIVATE) }

    private val tabs = mutableListOf<TabData>()
    private var activeTabId: String = HOME_TAB_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mode = prefs.getInt("theme", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        AppCompatDelegate.setDefaultNightMode(mode)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnTheme.setOnClickListener { toggleTheme() }
        updateThemeIcon()

        tabs.add(TabData(id = HOME_TAB_ID, type = TabType.HOME))
        ensureFragment(HOME_TAB_ID)
        showFragment(HOME_TAB_ID)
        updateBreadcrumb()
        updateTabStrip()

        onBackPressedDispatcher.addCallback(this) { handleBack() }
        if (!hasPerm()) askPerm()
    }

    override fun onResume() { super.onResume(); updateThemeIcon(); updateBreadcrumb(); updateTabStrip() }

    fun getTabData(tabId: String): TabData? = tabs.firstOrNull { it.id == tabId }

    fun openFolderTab(path: File, rootLabel: String, binMode: Boolean = false) {
        val existing = tabs.firstOrNull { it.type == TabType.FOLDER && it.currentPath == path && it.rootLabel == rootLabel }
        if (existing != null) { switchToTab(existing.id); return }
        val id = "folder_${UUID.randomUUID().toString().take(8)}"
        tabs.add(TabData(id = id, type = TabType.FOLDER, currentPath = path, rootLabel = rootLabel, binMode = binMode))
        ensureFragment(id); switchToTab(id)
    }

    fun openFileTab(file: File, fromFolderTabId: String? = null) {
        val existing = tabs.firstOrNull { it.type == TabType.FILE && it.filePath == file }
        if (existing != null) { switchToTab(existing.id); return }
        val id = "file_${UUID.randomUUID().toString().take(8)}"
        tabs.add(TabData(id = id, type = TabType.FILE, filePath = file, parentFolderTabId = fromFolderTabId))
        ensureFragment(id); switchToTab(id)
    }

    fun openMediaCategory(type: Int, title: String) {
        startActivity(Intent(this, MediaFolderActivity::class.java).apply {
            putExtra(MediaFolderActivity.EXTRA_TYPE, type)
            putExtra(MediaFolderActivity.EXTRA_TITLE, title)
        })
    }

    private fun switchToTab(tabId: String) {
        activeTabId = tabId; showFragment(tabId); updateBreadcrumb(); updateTabStrip()
    }

    fun closeTab(tabId: String) {
        if (tabId == HOME_TAB_ID) return
        val td = getTabData(tabId) ?: return
        if (td.type == TabType.FILE && td.isDirty) {
            MaterialAlertDialogBuilder(this)
                .setTitle(td.filePath?.name ?: "Dosya")
                .setMessage("Kaydedilmemiş değişiklikler var.")
                .setPositiveButton("Kaydet ve kapat") { _, _ ->
                    td.filePath?.let { try { it.writeText(td.fileContent ?: "") } catch (_: Exception) {} }
                    doCloseTab(tabId)
                }
                .setNegativeButton("Kapat") { _, _ -> doCloseTab(tabId) }
                .setNeutralButton("İptal", null).show()
        } else doCloseTab(tabId)
    }

    private fun doCloseTab(tabId: String) {
        val idx = tabs.indexOfFirst { it.id == tabId }
        if (idx < 0) return
        supportFragmentManager.findFragmentByTag(tabId)?.let {
            supportFragmentManager.beginTransaction().remove(it).commitNow()
        }
        tabs.removeAt(idx)
        if (tabs.isEmpty()) { tabs.add(TabData(id = HOME_TAB_ID, type = TabType.HOME)); ensureFragment(HOME_TAB_ID) }
        val newActive = if (activeTabId == tabId) tabs[((idx - 1).coerceAtLeast(0)).coerceAtMost(tabs.size - 1)].id else activeTabId
        switchToTab(newActive)
    }

    private fun ensureFragment(tabId: String) {
        if (supportFragmentManager.findFragmentByTag(tabId) != null) return
        val td = getTabData(tabId) ?: return
        val f: Fragment = when (td.type) {
            TabType.HOME -> HomeFragment()
            TabType.FOLDER -> FolderFragment.newInstance(tabId)
            TabType.FILE -> TextEditorFragment.newInstance(tabId)
        }
        supportFragmentManager.beginTransaction().add(R.id.fragmentContainer, f, tabId).hide(f).commitNow()
    }

    private fun showFragment(tabId: String) {
        val tx = supportFragmentManager.beginTransaction()
        supportFragmentManager.fragments.forEach { tx.hide(it) }
        supportFragmentManager.findFragmentByTag(tabId)?.let { tx.show(it) }
        tx.commitNow()
        b.btnTheme.visibility = if (tabId == HOME_TAB_ID) View.VISIBLE else View.GONE
    }

    fun updateBreadcrumb() {
        b.breadcrumbBar.removeAllViews()
        val td = getTabData(activeTabId) ?: return
        val d = resources.displayMetrics.density
        fun dp(v: Float) = (v * d).toInt()
        fun sep() = TextView(this).apply { text = " ›"; textSize = 12f; setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_dim)); setPadding(0, dp(4f), 0, dp(4f)) }
        fun seg(label: String, clickable: Boolean = false, onClick: (() -> Unit)? = null) = TextView(this).apply {
            text = label; textSize = 13f
            setPadding(dp(5f), dp(5f), dp(5f), dp(5f))
            setTextColor(ContextCompat.getColor(this@MainActivity, if (!clickable) R.color.text_main else R.color.accent))
            setTypeface(null, if (!clickable) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
            isClickable = clickable; isFocusable = clickable
            if (onClick != null) setOnClickListener { onClick() }
        }
        fun add(v: View) = b.breadcrumbBar.addView(v)

        when (td.type) {
            TabType.HOME -> add(seg("Ana Sayfa"))
            TabType.FOLDER -> {
                add(seg("Ana Sayfa", true) { switchToTab(HOME_TAB_ID) })
                // Köke giden geçmiş yolu
                val segments = mutableListOf<Pair<String, File>>()
                td.navHistory.forEachIndexed { i, f ->
                    segments.add((if (i == 0) td.rootLabel else f.name) to f)
                }
                td.currentPath?.let { segments.add(it.name to it) }
                segments.forEachIndexed { i, (label, f) ->
                    add(sep())
                    val isLast = i == segments.lastIndex
                    if (isLast) add(seg(label))
                    else add(seg(label, true) {
                        // Bu dizine kadar geri dön
                        val frag = supportFragmentManager.findFragmentByTag(activeTabId) as? FolderFragment
                        val histIdx = td.navHistory.indexOfFirst { it.absolutePath == f.absolutePath }
                        if (histIdx >= 0) {
                            while (td.navHistory.size > histIdx) td.navHistory.removeLast()
                            td.currentPath = f
                            frag?.run {
                                // FolderFragment'i yeniden başlat
                                loadDirDirect(f)
                            }
                        }
                        updateBreadcrumb(); updateTabStrip()
                    })
                }
            }
            TabType.FILE -> {
                add(seg("Ana Sayfa", true) { switchToTab(HOME_TAB_ID) })
                val f = td.filePath ?: return
                f.parentFile?.let { parent ->
                    add(sep())
                    val pid = td.parentFolderTabId
                    add(seg(parent.name, true) {
                        if (pid != null && getTabData(pid) != null) switchToTab(pid)
                        else openFolderTab(parent, parent.name)
                    })
                }
                add(sep()); add(seg(f.name))
            }
        }
        b.breadcrumbBar.post { (b.breadcrumbBar.parent as? android.widget.HorizontalScrollView)?.fullScroll(View.FOCUS_RIGHT) }
    }

    fun updateTabStrip() {
        b.tabStrip.removeAllViews()
        val d = resources.displayMetrics.density
        fun dp(v: Float) = (v * d).toInt()
        tabs.forEach { td ->
            val isActive = td.id == activeTabId
            val chip = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = ContextCompat.getDrawable(this@MainActivity, if (isActive) R.drawable.bg_chip_accent else R.drawable.bg_chip)
                setPadding(dp(12f), 0, dp(4f), 0)
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(36f)).apply { marginEnd = dp(6f) }
                setOnClickListener { switchToTab(td.id) }
            }
            val titleText = buildString { if (td.type == TabType.FILE && td.isDirty) append("● "); append(td.title) }
            chip.addView(TextView(this).apply {
                text = titleText; textSize = 11f; maxEms = 10; maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
                setTextColor(ContextCompat.getColor(this@MainActivity, if (isActive) R.color.on_accent else R.color.text_main))
            })
            if (td.id != HOME_TAB_ID) {
                chip.addView(TextView(this).apply {
                    text = " ✕"; textSize = 11f; setPadding(dp(6f), dp(4f), dp(8f), dp(4f))
                    setTextColor(ContextCompat.getColor(this@MainActivity, if (isActive) R.color.on_accent else R.color.text_dim))
                    setOnClickListener { closeTab(td.id) }
                })
            } else chip.addView(TextView(this).apply { text = " "; setPadding(0, 0, dp(8f), 0) })
            b.tabStrip.addView(chip)
        }
        val idx = tabs.indexOfFirst { it.id == activeTabId }
        b.tabStrip.post {
            if (idx >= 0 && b.tabStrip.childCount > idx)
                (b.tabStrip.parent as? android.widget.HorizontalScrollView)?.smoothScrollTo(b.tabStrip.getChildAt(idx).left, 0)
        }
    }

    private fun handleBack() {
        val td = getTabData(activeTabId) ?: return
        when (td.type) {
            TabType.FOLDER -> {
                val f = supportFragmentManager.findFragmentByTag(activeTabId) as? FolderFragment
                if (f?.navigateUp() != true) {
                    if (activeTabId != HOME_TAB_ID) closeTab(activeTabId) else showExitDialog()
                }
            }
            TabType.FILE -> closeTab(activeTabId)
            TabType.HOME -> showExitDialog()
        }
    }

    private fun showExitDialog() {
        MaterialAlertDialogBuilder(this)
            .setMessage("Uygulamadan çık?")
            .setPositiveButton("Çık") { _, _ -> finish() }
            .setNegativeButton("Hayır", null).show()
    }

    private fun hasPerm() = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
    else ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    private fun askPerm() {
        if (Build.VERSION.SDK_INT >= 30) {
            MaterialAlertDialogBuilder(this)
                .setTitle("İzin gerekli").setMessage("'Tüm dosyalara erişim' izni gerekiyor.")
                .setCancelable(false)
                .setPositiveButton("Ayarları aç") { _, _ ->
                    try { startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))) }
                    catch (_: Exception) { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
                }.show()
        } else permLauncher.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
    }

    private fun toggleTheme() {
        val night = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK == android.content.res.Configuration.UI_MODE_NIGHT_YES
        val newMode = if (night) AppCompatDelegate.MODE_NIGHT_NO else AppCompatDelegate.MODE_NIGHT_YES
        prefs.edit().putInt("theme", newMode).apply(); AppCompatDelegate.setDefaultNightMode(newMode); updateThemeIcon()
    }

    private fun updateThemeIcon() {
        val night = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK == android.content.res.Configuration.UI_MODE_NIGHT_YES
        b.btnTheme.setImageResource(if (night) R.drawable.ic_sun else R.drawable.ic_moon)
        b.btnTheme.imageTintList = android.content.res.ColorStateList.valueOf(ContextCompat.getColor(this, R.color.accent))
    }

    fun sdRoot(): File? = getExternalFilesDirs(null).filterNotNull().drop(1).firstOrNull()
        ?.absolutePath?.substringBefore("/Android/")?.let { File(it) }?.takeIf { it.exists() }

    fun showMsg(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
