package com.basit.dosya

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.IBinder
import android.os.StatFs
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import com.basit.dosya.databinding.ActivityMainBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.io.File

class MainActivity : AppCompatActivity() {

    companion object {
        val TEXT_EXTS = setOf("txt", "log", "md", "json", "csv", "srt", "ini")
    }

    private lateinit var b: ActivityMainBinding
    private val prefs by lazy { getSharedPreferences("ayar", MODE_PRIVATE) }

    private var musicSvc: MusicService? = null
    private val musicConn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, s: IBinder?) {
            musicSvc = (s as MusicService.LocalBinder).get()
            musicSvc?.addCb(::refreshPlayer)
            refreshPlayer()
        }
        override fun onServiceDisconnected(n: ComponentName?) { musicSvc = null }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Kayıtlı tema tercihi
        val mode = prefs.getInt("theme", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        AppCompatDelegate.setDefaultNightMode(mode)

        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnTheme.setOnClickListener { toggleTheme() }
        updateThemeIcon()

        b.tileInternal.setOnClickListener { openDir(Environment.getExternalStorageDirectory(), "Ana Bellek") }
        b.tileSd.setOnClickListener {
            val sd = sdRoot()
            if (sd != null) openDir(sd, "SD Kart") else toast("SD kart bulunamadı")
        }
        b.tileDownloads.setOnClickListener {
            openDir(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "İndirilenler")
        }
        b.tileImages.setOnClickListener { MediaFolderActivity.open(this, FolderGridAdapter.TYPE_IMAGE, "Resimler") }
        b.tileVideos.setOnClickListener { MediaFolderActivity.open(this, FolderGridAdapter.TYPE_VIDEO, "Videolar") }
        b.tileMusic.setOnClickListener { MediaFolderActivity.open(this, FolderGridAdapter.TYPE_MUSIC, "Müzikler") }
        b.tileBin.setOnClickListener { BrowseActivity.open(this, FileOps.binDir(), "Çöp Kutusu", bin = true) }

        b.btnPlayerPlayPause.setOnClickListener { MusicService.instance?.togglePlayPause() }
        b.btnPlayerStop.setOnClickListener { MusicService.instance?.stop(); b.playerBar.visibility = View.GONE }
        b.btnPlayerPrev.setOnClickListener { MusicService.instance?.prev(); refreshPlayer() }
        b.btnPlayerNext.setOnClickListener { MusicService.instance?.next(); refreshPlayer() }
        b.btnPlayerMode.setOnClickListener {
            val svc = MusicService.instance ?: return@setOnClickListener
            svc.playMode = if (svc.playMode == MusicService.MODE_REPEAT_ONE)
                MusicService.MODE_SEQUENTIAL else MusicService.MODE_REPEAT_ONE
            refreshPlayer()
        }
    }

    override fun onResume() {
        super.onResume()
        if (hasPerm()) {
            populateHomeInfo()
            populateSdGrid()
        } else {
            askPerm()
        }
        MusicService.instance?.let {
            bindService(Intent(this, MusicService::class.java), musicConn, Context.BIND_AUTO_CREATE)
        }
        refreshPlayer()
        updateThemeIcon()
    }

    override fun onPause() {
        musicSvc?.removeCb(::refreshPlayer)
        try { unbindService(musicConn) } catch (_: Exception) {}
        musicSvc = null
        super.onPause()
    }

    // ---------- tema ----------

    private fun toggleTheme() {
        val current = resources.configuration.uiMode and
            android.content.res.Configuration.UI_MODE_NIGHT_MASK
        val isNight = current == android.content.res.Configuration.UI_MODE_NIGHT_YES
        val newMode = if (isNight) AppCompatDelegate.MODE_NIGHT_NO else AppCompatDelegate.MODE_NIGHT_YES
        prefs.edit().putInt("theme", newMode).apply()
        AppCompatDelegate.setDefaultNightMode(newMode)
        updateThemeIcon()
    }

    private fun updateThemeIcon() {
        val isNight = resources.configuration.uiMode and
            android.content.res.Configuration.UI_MODE_NIGHT_MASK ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        b.btnTheme.setImageResource(if (isNight) R.drawable.ic_sun else R.drawable.ic_moon)
        b.btnTheme.imageTintList = android.content.res.ColorStateList.valueOf(
            ContextCompat.getColor(this, R.color.accent)
        )
    }

    // ---------- izin ----------

    private fun hasPerm() = if (Build.VERSION.SDK_INT >= 30)
        Environment.isExternalStorageManager()
    else ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) ==
        PackageManager.PERMISSION_GRANTED

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    private fun askPerm() {
        if (Build.VERSION.SDK_INT >= 30) {
            MaterialAlertDialogBuilder(this)
                .setTitle("İzin gerekli")
                .setMessage("Dosyaları yönetebilmek için 'Tüm dosyalara erişim' izni gerekiyor.")
                .setCancelable(false)
                .setPositiveButton("Ayarları aç") { _, _ ->
                    try {
                        startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
                    } catch (_: Exception) {
                        startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                    }
                }.show()
        } else {
            permLauncher.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
        }
    }

    // ---------- ana sayfa dolduruluyor ----------

    private fun sdRoot(): File? = getExternalFilesDirs(null).filterNotNull().drop(1).firstOrNull()
        ?.absolutePath?.substringBefore("/Android/")?.let { File(it) }?.takeIf { it.exists() }

    private fun populateHomeInfo() {
        try {
            val st = StatFs(Environment.getExternalStorageDirectory().absolutePath)
            val total = st.blockCountLong * st.blockSizeLong
            val free = st.availableBlocksLong * st.blockSizeLong
            b.subInternal.text = FileOps.fmtSize(total - free) + " / " + FileOps.fmtSize(total)
        } catch (_: Exception) {}
        val sd = sdRoot()
        if (sd != null) {
            try {
                val st = StatFs(sd.absolutePath)
                val total = st.blockCountLong * st.blockSizeLong
                val free = st.availableBlocksLong * st.blockSizeLong
                b.subSd.text = FileOps.fmtSize(total - free) + " / " + FileOps.fmtSize(total)
            } catch (_: Exception) {}
        } else {
            b.tileSd.alpha = 0.4f; b.subSd.text = "yok"
        }
        val binCount = FileOps.binDir().list()?.count { it != "index.json" } ?: 0
        b.subBin.text = if (binCount > 0) "$binCount öğe" else ""
    }

    private fun populateSdGrid() {
        val sd = sdRoot()
        if (sd == null) {
            b.rvSdCard.visibility = View.GONE
            b.tvNoSd.visibility = View.VISIBLE
            return
        }
        b.tvNoSd.visibility = View.GONE
        b.rvSdCard.visibility = View.VISIBLE
        val folders = sd.listFiles()
            ?.filter { it.isDirectory && !it.name.startsWith(".") }
            ?.sortedWith(NaturalSort.fileComparator) ?: emptyList()
        val adapter = FolderGridAdapter(FolderGridAdapter.TYPE_FOLDER) { item ->
            BrowseActivity.open(this, File(item.dirPath), item.name)
        }
        b.rvSdCard.layoutManager = GridLayoutManager(this, 4)
        b.rvSdCard.adapter = adapter
        adapter.items = folders.map { FolderGridAdapter.FolderItem(it.absolutePath, it.name, it.list()?.size ?: 0, null) }
    }

    // ---------- müzik player bar ----------

    private fun refreshPlayer() {
        val svc = MusicService.instance
        if (svc == null || (!svc.isPlaying && svc.currentFile() == null)) {
            b.playerBar.visibility = View.GONE; return
        }
        b.playerBar.visibility = View.VISIBLE
        b.tvNowPlaying.text = svc.currentFile()?.nameWithoutExtension ?: ""
        b.btnPlayerPlayPause.setImageResource(if (svc.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        b.btnPlayerMode.text = if (svc.playMode == MusicService.MODE_REPEAT_ONE) "1×" else "Sıra"
    }

    private fun openDir(dir: File, label: String) = BrowseActivity.open(this, dir, label)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
