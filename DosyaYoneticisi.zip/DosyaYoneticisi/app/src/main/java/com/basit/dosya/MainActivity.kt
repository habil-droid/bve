package com.basit.dosya

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import com.basit.dosya.databinding.ActivityMainBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.io.File

/**
 * TEK Activity, TEK bölme (pane) mimarisi.
 * Ekranlar: Ana Sayfa | Klasör (breadcrumb ile gezinilir) | Metin editörü (tek dosya)
 * Sekme sistemi YOK — kullanıcı isteğiyle kaldırıldı. Breadcrumb'ın kendisi tek
 * navigasyon göstergesi; her segment ızgaralı (chip) bir buton.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        val TEXT_EXTS = setOf("txt", "log", "md", "json", "csv", "srt", "ini")
    }

    private lateinit var b: ActivityMainBinding
    private val prefs by lazy { getSharedPreferences("ayar", MODE_PRIVATE) }

    // ---------- navigasyon durumu ----------
    private var rootLabel: String = ""
    private var binMode: Boolean = false
    private val navChain = mutableListOf<File>()   // boşsa: Ana Sayfa'dayız
    private var openFile: File? = null              // null değilse: metin editörü açık

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mode = prefs.getInt("theme", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        AppCompatDelegate.setDefaultNightMode(mode)

        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnTheme.setOnClickListener { toggleTheme() }
        updateThemeIcon()

        // Durum geri yükleme (tema değişimi sonrası Activity yeniden oluşunca)
        savedInstanceState?.let { st ->
            rootLabel = st.getString("rootLabel", "")
            binMode = st.getBoolean("binMode", false)
            st.getStringArrayList("navChain")?.forEach { navChain.add(File(it)) }
            st.getString("openFile")?.let { openFile = File(it) }
        }

        when {
            openFile != null && openFile!!.exists() -> showTextEditor()
            navChain.isNotEmpty() && navChain.last().exists() -> { openFile = null; showFolder() }
            else -> { navChain.clear(); openFile = null; showHome() }
        }
        updateBreadcrumb()

        onBackPressedDispatcher.addCallback(this) { handleBack() }
        if (!hasPerm()) askPerm()

        // MediaFolderActivity'den klasör açma isteği
        handleOpenIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleOpenIntent(intent)
    }

    private fun handleOpenIntent(intent: Intent?) {
        val path = intent?.getStringExtra("openFolderPath") ?: return
        val label = intent.getStringExtra("openFolderLabel") ?: File(path).name
        // Tek seferlik: tekrar açılmasın diye extra'yı temizle
        intent.removeExtra("openFolderPath")
        intent.removeExtra("openFolderLabel")
        val dir = File(path)
        if (dir.exists()) openFolderRoot(dir, label)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("rootLabel", rootLabel)
        outState.putBoolean("binMode", binMode)
        outState.putStringArrayList("navChain", ArrayList(navChain.map { it.absolutePath }))
        openFile?.let { outState.putString("openFile", it.absolutePath) }
    }

    override fun onResume() {
        super.onResume()
        updateThemeIcon()
    }

    // ---------- ekran geçişleri ----------

    fun openFolderRoot(path: File, label: String, binMode: Boolean = false) {
        rootLabel = label; this.binMode = binMode
        navChain.clear(); navChain.add(path)
        openFile = null
        showFolder(); updateBreadcrumb()
    }

    /** Alt klasöre gir (FolderFragment çağırır). */
    fun navigateInto(dir: File) {
        navChain.add(dir)
        showFolder(); updateBreadcrumb()
    }

    /** Breadcrumb'da bir segmente dokununca doğrudan o noktaya dön. */
    private fun navigateToChainIndex(idx: Int) {
        openFile = null
        while (navChain.size > idx + 1) navChain.removeAt(navChain.size - 1)
        showFolder(); updateBreadcrumb()
    }

    /** TXT dosyasını aç (FolderFragment çağırır). Klasör görünümünün "üstüne" biner. */
    fun openTextFile(file: File) {
        openFile = file
        showTextEditor(); updateBreadcrumb()
    }

    /** Metin editörünü kapat, aynı klasöre dön (TextEditorFragment çağırır). */
    fun closeTextFile() {
        openFile = null
        showFolder(); updateBreadcrumb()
    }

    fun openMediaCategory(type: Int, title: String) {
        startActivity(Intent(this, MediaFolderActivity::class.java).apply {
            putExtra(MediaFolderActivity.EXTRA_TYPE, type)
            putExtra(MediaFolderActivity.EXTRA_TITLE, title)
        })
    }

    fun currentDir(): File? = navChain.lastOrNull()
    fun currentBinMode(): Boolean = binMode

    private fun safeReplace(fragment: androidx.fragment.app.Fragment) {
        if (isFinishing || isDestroyed) return
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commitAllowingStateLoss()
    }

    private fun showHome() = safeReplace(HomeFragment())

    private fun showFolder() = safeReplace(FolderFragment())

    private fun showTextEditor() {
        val f = openFile ?: return
        safeReplace(TextEditorFragment.newInstance(f.absolutePath))
    }

    // ---------- breadcrumb (ızgaralı/chip) ----------

    fun updateBreadcrumb() {
        b.breadcrumbBar.removeAllViews()
        val d = resources.displayMetrics.density
        fun dp(v: Float) = (v * d).toInt()

        fun addSep() {
            b.breadcrumbBar.addView(TextView(this).apply {
                text = "  ›  "; textSize = 12f
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_dim))
            })
        }

        fun addChip(label: String, current: Boolean, onClick: (() -> Unit)?) {
            val chip = TextView(this).apply {
                text = label; textSize = 12f
                setPadding(dp(12f), dp(7f), dp(12f), dp(7f))
                background = ContextCompat.getDrawable(
                    this@MainActivity, if (current) R.drawable.bg_chip_accent else R.drawable.bg_chip
                )
                setTextColor(ContextCompat.getColor(this@MainActivity, if (current) R.color.on_accent else R.color.text_main))
                maxLines = 1
                if (onClick != null) { isClickable = true; setOnClickListener { onClick() } }
            }
            val lp = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.marginEnd = dp(6f)
            chip.layoutParams = lp
            b.breadcrumbBar.addView(chip)
        }

        val atHome = navChain.isEmpty() && openFile == null
        addChip("Ana Sayfa", current = atHome, onClick = if (atHome) null else { {
            navChain.clear(); openFile = null; showHome(); updateBreadcrumb()
        } })

        navChain.forEachIndexed { i, dir ->
            val label = if (i == 0) rootLabel else dir.name
            val isLastAndNoFile = (i == navChain.lastIndex) && openFile == null
            addChip(label, current = isLastAndNoFile, onClick = if (isLastAndNoFile) null else { {
                navigateToChainIndex(i)
            } })
        }

        openFile?.let { f ->
            addChip(f.name, current = true, onClick = null)
        }

        b.breadcrumbBar.post {
            (b.breadcrumbBar.parent as? android.widget.HorizontalScrollView)?.fullScroll(View.FOCUS_RIGHT)
        }
    }

    // ---------- geri tuşu ----------

    private fun handleBack() {
        when {
            openFile != null -> {
                val frag = supportFragmentManager.findFragmentById(R.id.fragmentContainer) as? TextEditorFragment
                frag?.requestClose() ?: closeTextFile()
            }
            navChain.size > 1 -> {
                navChain.removeAt(navChain.size - 1)
                showFolder(); updateBreadcrumb()
            }
            navChain.size == 1 -> {
                navChain.clear(); showHome(); updateBreadcrumb()
            }
            else -> showExitDialog()
        }
    }

    private fun showExitDialog() {
        MaterialAlertDialogBuilder(this)
            .setMessage("Uygulamadan çık?")
            .setPositiveButton("Çık") { _, _ -> finish() }
            .setNegativeButton("Hayır", null).show()
    }

    // ---------- izin ----------

    private fun hasPerm() = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
    else ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    private fun askPerm() {
        if (Build.VERSION.SDK_INT >= 30) {
            MaterialAlertDialogBuilder(this)
                .setTitle("İzin gerekli").setMessage("'Tüm dosyalara erişim' izni gerekiyor.")
                .setCancelable(false)
                .setPositiveButton("Ayarları aç") { _, _ ->
                    try { startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))) }
                    catch (_: Exception) { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
                }.show()
        } else permLauncher.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
    }

    // ---------- tema ----------
    // Not: manifest'te configChanges="uiMode" YOK — tema değişince Activity gerçekten
    // yeniden oluşur (Android'in önerdiği güvenilir yöntem). Konum onSaveInstanceState
    // ile korunur, kullanıcı kaldığı yerde devam eder.

    private fun toggleTheme() {
        val night = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        val newMode = if (night) AppCompatDelegate.MODE_NIGHT_NO else AppCompatDelegate.MODE_NIGHT_YES
        prefs.edit().putInt("theme", newMode).apply()
        AppCompatDelegate.setDefaultNightMode(newMode)
    }

    private fun updateThemeIcon() {
        val night = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        b.btnTheme.setImageResource(if (night) R.drawable.ic_sun else R.drawable.ic_moon)
        b.btnTheme.imageTintList = android.content.res.ColorStateList.valueOf(ContextCompat.getColor(this, R.color.accent))
    }

    // ---------- yardımcılar ----------

    fun sdRoot(): File? = getExternalFilesDirs(null).filterNotNull().drop(1).firstOrNull()
        ?.absolutePath?.substringBefore("/Android/")?.let { File(it) }?.takeIf { it.exists() }

    fun showMsg(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
