package com.basit.dosya

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.View
import android.widget.MediaController
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.basit.dosya.databinding.ActivityMediaViewBinding
import java.io.File
import java.util.Locale

/**
 * Yerleşik görüntü/video görüntüleyici — harici uygulama (VLC vb.) gerekmez.
 * - Resim: bellek-güvenli (örneklemeli) yükleme; aynı klasördeki resimler arasında
 *   önceki/sonraki ile gezinme.
 * - Video: sistem VideoView + MediaController (oynat/duraklat/sar); müzik çalıyorsa
 *   otomatik duraklatılır.
 */
class MediaViewActivity : AppCompatActivity() {

    companion object {
        val IMAGE_EXTS = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic")
        val VIDEO_EXTS = setOf("mp4", "mkv", "avi", "mov", "webm", "3gp")

        fun open(ctx: Context, path: String) {
            ctx.startActivity(Intent(ctx, MediaViewActivity::class.java).putExtra("path", path))
        }
    }

    private lateinit var b: ActivityMediaViewBinding
    private var siblings: List<File> = emptyList()
    private var idx = 0
    private var isVideo = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMediaViewBinding.inflate(layoutInflater)
        setContentView(b.root)

        val path = intent.getStringExtra("path")
        val f = path?.let { File(it) }
        if (f == null || !f.exists()) { finish(); return }

        isVideo = f.extension.lowercase(Locale.ROOT) in VIDEO_EXTS
        val exts = if (isVideo) VIDEO_EXTS else IMAGE_EXTS
        siblings = f.parentFile?.listFiles()
            ?.filter { it.extension.lowercase(Locale.ROOT) in exts }
            ?.sortedWith(NaturalSort.fileComparator)
            ?: listOf(f)
        idx = siblings.indexOfFirst { it.absolutePath == f.absolutePath }.coerceAtLeast(0)

        b.btnBack.setOnClickListener { finish() }
        b.btnPrevMedia.setOnClickListener {
            if (siblings.size > 1) { idx = (idx - 1 + siblings.size) % siblings.size; show() }
        }
        b.btnNextMedia.setOnClickListener {
            if (siblings.size > 1) { idx = (idx + 1) % siblings.size; show() }
        }
        if (siblings.size <= 1) {
            b.btnPrevMedia.visibility = View.GONE
            b.btnNextMedia.visibility = View.GONE
        }

        if (isVideo) {
            val mc = MediaController(this)
            mc.setAnchorView(b.videoView)
            b.videoView.setMediaController(mc)
            b.videoView.setOnErrorListener { _, _, _ ->
                Toast.makeText(
                    this,
                    "Oynatılamadı — bu format cihaz tarafından desteklenmiyor olabilir",
                    Toast.LENGTH_LONG
                ).show()
                true
            }
            // Müzik çalıyorsa videoyla çakışmasın diye duraklat
            MusicService.instance?.let { if (it.isPlaying) it.togglePlayPause() }
        }

        show()
    }

    private fun show() {
        val f = siblings.getOrNull(idx) ?: return
        b.tvTitle.text = f.name
        if (isVideo) {
            b.ivPhoto.visibility = View.GONE
            b.videoView.visibility = View.VISIBLE
            b.videoView.setVideoPath(f.absolutePath)
            b.videoView.setOnPreparedListener { it.start() }
        } else {
            b.videoView.visibility = View.GONE
            b.ivPhoto.visibility = View.VISIBLE
            Thread {
                val bm = decodeSampled(f.absolutePath, 2048, 2048)
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    if (bm != null) b.ivPhoto.setImageBitmap(bm)
                    else Toast.makeText(this, "Görüntü açılamadı", Toast.LENGTH_SHORT).show()
                }
            }.start()
        }
    }

    /** Büyük fotoğraflarda OOM'u önlemek için örneklemeli çözme. */
    private fun decodeSampled(path: String, reqW: Int, reqH: Int): Bitmap? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= reqW || bounds.outHeight / (sample * 2) >= reqH) {
            sample *= 2
        }
        BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
    } catch (_: Exception) { null }

    override fun onPause() {
        super.onPause()
        if (isVideo) b.videoView.pause()
    }
}
