package com.basit.dosya

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.basit.dosya.databinding.ActivityMediaViewBinding
import java.io.File
import java.util.Locale

/**
 * Yerleşik görüntü/video görüntüleyici.
 * - Video: TextureView + MediaPlayer (VideoView'in aksine sorunsuz döndürülür/ölçeklenir).
 * - Telefon döndürmede Activity yeniden yaratılmaz (manifest configChanges) → video
 *   sıfırlanmaz, klasördeki ilk videoya atlamaz.
 * - Ekrana bir kez dokunma üst paneli gizler/gösterir; 3 sn dokunulmazsa gizlenir.
 * - Fotoğraf: ZoomableImageView ile pinch-zoom + kaydırma + çift dokunuş.
 */
class MediaViewActivity : AppCompatActivity() {

    companion object {
        val IMAGE_EXTS = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic")
        val VIDEO_EXTS = setOf("mp4", "mkv", "avi", "mov", "webm", "3gp")

        fun open(ctx: Context, path: String) {
            ctx.startActivity(Intent(ctx, MediaViewActivity::class.java).putExtra("path", path))
        }
    }

    private lateinit var b: ActivityMediaViewBinding
    private var siblings: List<File> = emptyList()
    private var idx = 0
    private var isVideo = false
    private var userSeeking = false
    private var rotDeg = 0

    private var player: MediaPlayer? = null
    private var surface: Surface? = null
    private var videoW = 0
    private var videoH = 0
    private var pendingPath: String? = null
    private var wasPlaying = true

    private val ui = Handler(Looper.getMainLooper())
    private var controlsVisible = true

    private val hideRunnable = Runnable { setControls(false) }

    private val progressTick = object : Runnable {
        override fun run() {
            val p = player
            if (isVideo && p != null && p.isPlaying && !userSeeking) {
                b.videoSeek.progress = p.currentPosition
                b.tvTime.text = fmt(p.currentPosition) + " / " + fmt(p.duration)
            }
            ui.postDelayed(this, 500)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMediaViewBinding.inflate(layoutInflater)
        setContentView(b.root)

        val path = intent.getStringExtra("path")
        val f = path?.let { File(it) }
        if (f == null || !f.exists()) { finish(); return }

        isVideo = f.extension.lowercase(Locale.ROOT) in VIDEO_EXTS
        val exts = if (isVideo) VIDEO_EXTS else IMAGE_EXTS
        siblings = f.parentFile?.listFiles()
            ?.filter { it.extension.lowercase(Locale.ROOT) in exts }
            ?.sortedWith(NaturalSort.fileComparator)
            ?: listOf(f)
        idx = siblings.indexOfFirst { it.absolutePath == f.absolutePath }.coerceAtLeast(0)

        b.btnBack.setOnClickListener { finish() }
        b.btnRotate.setOnClickListener { rotDeg = (rotDeg + 90) % 360; applyRotation(); poke() }
        b.btnPrevMedia.setOnClickListener { step(-1) }
        b.btnNextMedia.setOnClickListener { step(+1) }
        if (siblings.size <= 1) {
            b.btnPrevMedia.visibility = View.GONE
            b.btnNextMedia.visibility = View.GONE
        }

        b.btnPlayPause.setOnClickListener { togglePlay(); poke() }
        b.videoSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) b.tvTime.text = fmt(p) + " / " + fmt(player?.duration ?: 0)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) { userSeeking = true; ui.removeCallbacks(hideRunnable) }
            override fun onStopTrackingTouch(sb: SeekBar?) {
                userSeeking = false
                player?.seekTo(sb?.progress ?: 0)
                poke()
            }
        })

        // Fotoğraf: tek dokunuş paneli değiştirir; kaydırma pinch-zoom bileşeninden
        b.ivPhoto.onSingleTap = { toggleControls() }
        b.ivPhoto.onEdgeSwipe = { dir -> step(dir) }

        if (isVideo) {
            b.videoControls.visibility = View.VISIBLE
            setupVideoTouch()
            b.textureVideo.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                    surface = Surface(st)
                    pendingPath?.let { startVideo(it) }
                }
                override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) { scaleTexture() }
                override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { surface = null; return true }
                override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
            }
            MusicService.instance?.let { if (it.isPlaying) it.togglePlayPause() }
            ui.post(progressTick)
        } else {
            b.textureVideo.visibility = View.GONE
            b.videoControls.visibility = View.GONE
        }

        show()
        scheduleHide()
    }

    // ---------- gezinme ----------

    private fun step(dir: Int) {
        if (siblings.size <= 1) return
        idx = (idx + dir + siblings.size) % siblings.size
        show()
        poke()
    }

    private fun show() {
        val f = siblings.getOrNull(idx) ?: return
        b.tvTitle.text = f.name
        rotDeg = 0

        if (isVideo) {
            b.ivPhoto.visibility = View.GONE
            b.textureVideo.visibility = View.VISIBLE
            wasPlaying = true
            if (surface != null) startVideo(f.absolutePath) else pendingPath = f.absolutePath
        } else {
            b.textureVideo.visibility = View.GONE
            b.ivPhoto.visibility = View.VISIBLE
            Thread {
                val bm = decodeSampled(f.absolutePath, 3000, 3000)
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    if (bm != null) {
                        b.ivPhoto.setImageBitmap(bm)
                        b.ivPhoto.resetForNewImage(0)
                    } else Toast.makeText(this, "Görüntü açılamadı", Toast.LENGTH_SHORT).show()
                }
            }.start()
        }
    }

    // ---------- video (MediaPlayer + TextureView) ----------

    private fun startVideo(path: String) {
        pendingPath = null
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(path)
                setSurface(surface)
                setOnVideoSizeChangedListener { _, w, h -> videoW = w; videoH = h; scaleTexture() }
                setOnPreparedListener {
                    b.videoSeek.max = it.duration
                    b.tvTime.text = "00:00 / " + fmt(it.duration)
                    b.btnPlayPause.setImageResource(R.drawable.ic_pause)
                    scaleTexture()
                    if (wasPlaying) it.start()
                }
                setOnCompletionListener { b.btnPlayPause.setImageResource(R.drawable.ic_play) }
                setOnErrorListener { _, _, _ ->
                    Toast.makeText(this@MediaViewActivity,
                        "Oynatılamadı — bu format cihaz tarafından desteklenmiyor olabilir",
                        Toast.LENGTH_LONG).show()
                    true
                }
                prepareAsync()
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Video açılamadı", Toast.LENGTH_SHORT).show()
        }
    }

    private fun togglePlay() {
        val p = player ?: return
        if (p.isPlaying) { p.pause(); wasPlaying = false; b.btnPlayPause.setImageResource(R.drawable.ic_play) }
        else { p.start(); wasPlaying = true; b.btnPlayPause.setImageResource(R.drawable.ic_pause) }
    }

    /** TextureView'i video oranına + döndürmeye göre ölçekler (merkezde sığdırma). */
    private fun scaleTexture() {
        if (videoW == 0 || videoH == 0) return
        val vw = b.textureVideo.width.toFloat()
        val vh = b.textureVideo.height.toFloat()
        if (vw == 0f || vh == 0f) return

        val m = Matrix()
        val rotated = rotDeg % 180 != 0
        val contentW = if (rotated) videoH.toFloat() else videoW.toFloat()
        val contentH = if (rotated) videoW.toFloat() else videoH.toFloat()
        val scale = minOf(vw / contentW, vh / contentH)
        val dispW = contentW * scale
        val dispH = contentH * scale

        m.setScale(dispW / vw, dispH / vh)
        m.postTranslate((vw - dispW) / 2f, (vh - dispH) / 2f)
        if (rotDeg != 0) m.postRotate(rotDeg.toFloat(), vw / 2f, vh / 2f)
        b.textureVideo.setTransform(m)
        b.textureVideo.invalidate()
    }

    // ---------- döndürme ----------

    private fun applyRotation() {
        if (isVideo) scaleTexture()
        else b.ivPhoto.setRotationDegrees(rotDeg)
    }

    // ---------- kontrol panelinin otomatik gizlenmesi ----------

    @SuppressLint("ClickableViewAccessibility")
    private fun setupVideoTouch() {
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean { toggleControls(); return true }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vX: Float, vY: Float): Boolean {
                val dX = e2.x - (e1?.x ?: e2.x)
                val dY = e2.y - (e1?.y ?: e2.y)
                if (Math.abs(dX) > 100 && Math.abs(dX) > Math.abs(dY) * 1.5f) {
                    if (dX < 0) step(+1) else step(-1); return true
                }
                return false
            }
        })
        b.textureVideo.setOnTouchListener { _, e -> gd.onTouchEvent(e); true }
    }

    private fun toggleControls() = setControls(!controlsVisible)

    private fun setControls(visible: Boolean) {
        controlsVisible = visible
        b.topPanel.animate().alpha(if (visible) 1f else 0f).setDuration(180)
            .withStartAction { if (visible) b.topPanel.visibility = View.VISIBLE }
            .withEndAction { if (!visible) b.topPanel.visibility = View.INVISIBLE }
            .start()
        if (visible) scheduleHide() else ui.removeCallbacks(hideRunnable)
    }

    private fun poke() { if (!controlsVisible) setControls(true) else scheduleHide() }

    private fun scheduleHide() {
        ui.removeCallbacks(hideRunnable)
        ui.postDelayed(hideRunnable, 3000)
    }

    // ---------- yardımcılar ----------

    private fun fmt(ms: Int): String {
        val s = ms / 1000
        return String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
    }

    private fun decodeSampled(path: String, reqW: Int, reqH: Int): Bitmap? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= reqW || bounds.outHeight / (sample * 2) >= reqH) sample *= 2
        BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
    } catch (_: Exception) { null }

    override fun onPause() {
        super.onPause()
        player?.let { if (it.isPlaying) { it.pause(); wasPlaying = true; b.btnPlayPause.setImageResource(R.drawable.ic_play) } }
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        player?.release(); player = null
        surface?.release(); surface = null
        super.onDestroy()
    }
}
