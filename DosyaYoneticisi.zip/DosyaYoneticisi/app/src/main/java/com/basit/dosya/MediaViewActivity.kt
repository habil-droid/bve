package com.basit.dosya

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.basit.dosya.databinding.ActivityMediaViewBinding
import java.io.File
import java.util.Locale

/**
 * Yerleşik görüntü/video görüntüleyici.
 * - Kontroller ÜSTTE: oynat/duraklat + ilerleme çubuğu + süre.
 * - Sola/sağa kaydırma (fling) hem fotoğrafta hem videoda yandaki medyaya geçer.
 *   Not: dokunma dinleyicisi DOWN'ı tüketir (true döner) — önceki sürümde false
 *   dönüldüğü için sonraki hareket olayları hiç gelmiyor, kaydırma çalışmıyordu.
 */
class MediaViewActivity : AppCompatActivity() {

    companion object {
        val IMAGE_EXTS = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic")
        val VIDEO_EXTS = setOf("mp4", "mkv", "avi", "mov", "webm", "3gp")

        fun open(ctx: Context, path: String) {
            ctx.startActivity(Intent(ctx, MediaViewActivity::class.java).putExtra("path", path))
        }
    }

    private lateinit var b: ActivityMediaViewBinding
    private var siblings: List<File> = emptyList()
    private var idx = 0
    private var isVideo = false
    private var userSeeking = false
    private var rotDeg = 0
    private val ui = Handler(Looper.getMainLooper())

    private val progressTick = object : Runnable {
        override fun run() {
            if (isVideo && b.videoView.isPlaying) {
                if (!userSeeking) {
                    b.videoSeek.progress = b.videoView.currentPosition
                    b.tvTime.text = fmt(b.videoView.currentPosition) + " / " + fmt(b.videoView.duration)
                }
            }
            ui.postDelayed(this, 500)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMediaViewBinding.inflate(layoutInflater)
        setContentView(b.root)

        val path = intent.getStringExtra("path")
        val f = path?.let { File(it) }
        if (f == null || !f.exists()) { finish(); return }

        isVideo = f.extension.lowercase(Locale.ROOT) in VIDEO_EXTS
        val exts = if (isVideo) VIDEO_EXTS else IMAGE_EXTS
        siblings = f.parentFile?.listFiles()
            ?.filter { it.extension.lowercase(Locale.ROOT) in exts }
            ?.sortedWith(NaturalSort.fileComparator)
            ?: listOf(f)
        idx = siblings.indexOfFirst { it.absolutePath == f.absolutePath }.coerceAtLeast(0)

        b.btnBack.setOnClickListener { finish() }
        b.btnRotate.setOnClickListener { rotDeg = (rotDeg + 90) % 360; applyRotation() }
        b.btnPrevMedia.setOnClickListener { step(-1) }
        b.btnNextMedia.setOnClickListener { step(+1) }
        if (siblings.size <= 1) {
            b.btnPrevMedia.visibility = View.GONE
            b.btnNextMedia.visibility = View.GONE
        }

        // ÜSTTEKİ video kontrolleri
        b.btnPlayPause.setOnClickListener {
            if (b.videoView.isPlaying) { b.videoView.pause(); b.btnPlayPause.setImageResource(R.drawable.ic_play) }
            else { b.videoView.start(); b.btnPlayPause.setImageResource(R.drawable.ic_pause) }
        }
        b.videoSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) b.tvTime.text = fmt(p) + " / " + fmt(b.videoView.duration)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) { userSeeking = true }
            override fun onStopTrackingTouch(sb: SeekBar?) {
                userSeeking = false
                b.videoView.seekTo(sb?.progress ?: 0)
            }
        })

        if (isVideo) {
            b.videoControls.visibility = View.VISIBLE
            b.videoView.setOnErrorListener { _, _, _ ->
                Toast.makeText(this, "Oynatılamadı — bu format cihaz tarafından desteklenmiyor olabilir", Toast.LENGTH_LONG).show()
                true
            }
            MusicService.instance?.let { if (it.isPlaying) it.togglePlayPause() }
            ui.post(progressTick)
        }

        setupSwipe()
        show()
    }

    private fun step(dir: Int) {
        if (siblings.size <= 1) return
        idx = (idx + dir + siblings.size) % siblings.size
        show()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupSwipe() {
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true   // DOWN'ı tüket ki fling gelsin
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vX: Float, vY: Float): Boolean {
                val dX = e2.x - (e1?.x ?: e2.x)
                val dY = e2.y - (e1?.y ?: e2.y)
                if (Math.abs(dX) > 100 && Math.abs(dX) > Math.abs(dY) * 1.5f) {
                    if (dX < 0) step(+1) else step(-1)
                    return true
                }
                return false
            }
        })
        // true döndür: dokunuşu bu view alır, MOVE/UP olayları gelir → fling çalışır
        b.ivPhoto.setOnTouchListener { _, e -> gd.onTouchEvent(e); true }
        b.videoView.setOnTouchListener { _, e -> gd.onTouchEvent(e); true }
    }

    private fun show() {
        val f = siblings.getOrNull(idx) ?: return
        b.tvTitle.text = f.name
        rotDeg = 0; applyRotation()
        if (isVideo) {
            b.ivPhoto.visibility = View.GONE
            b.videoView.visibility = View.VISIBLE
            b.videoView.setVideoPath(f.absolutePath)
            b.videoView.setOnPreparedListener {
                b.videoSeek.max = it.duration
                b.tvTime.text = "00:00 / " + fmt(it.duration)
                b.btnPlayPause.setImageResource(R.drawable.ic_pause)
                it.start()
            }
        } else {
            b.videoView.visibility = View.GONE
            b.ivPhoto.visibility = View.VISIBLE
            Thread {
                val bm = decodeSampled(f.absolutePath, 2048, 2048)
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    if (bm != null) b.ivPhoto.setImageBitmap(bm)
                    else Toast.makeText(this, "Görüntü açılamadı", Toast.LENGTH_SHORT).show()
                }
            }.start()
        }
    }

    /** Görüntülenen medyayı 90° adımlarla döndürür; dikeyde sığması için ölçekler. */
    private fun applyRotation() {
        val target: View = if (isVideo) b.videoView else b.ivPhoto
        target.rotation = rotDeg.toFloat()
        val w = target.width.toFloat()
        val h = target.height.toFloat()
        val s = if (rotDeg % 180 != 0 && w > 0 && h > 0) minOf(w / h, h / w) else 1f
        target.scaleX = s
        target.scaleY = s
    }

    private fun fmt(ms: Int): String {
        val s = ms / 1000
        return String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
    }

    private fun decodeSampled(path: String, reqW: Int, reqH: Int): Bitmap? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= reqW || bounds.outHeight / (sample * 2) >= reqH) sample *= 2
        BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
    } catch (_: Exception) { null }

    override fun onPause() {
        super.onPause()
        if (isVideo) { b.videoView.pause(); b.btnPlayPause.setImageResource(R.drawable.ic_play) }
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
