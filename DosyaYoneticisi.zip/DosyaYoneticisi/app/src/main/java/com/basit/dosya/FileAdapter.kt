package com.basit.dosya

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.basit.dosya.databinding.ItemFileBinding
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FileAdapter(
    private val selected: Set<String>,
    private val onClick: (File) -> Unit,
    private val onLong: (File) -> Unit
) : RecyclerView.Adapter<FileAdapter.VH>() {

    var items: List<File> = emptyList()
        set(v) { field = v; notifyDataSetChanged() }

    /** Özyinelemeli arama modunda: alt satırda bu köke göre yol gösterilir. */
    var searchBase: File? = null

    private val df = SimpleDateFormat("d MMM yyyy", Locale("tr"))
    private val thumbCache = HashMap<String, Bitmap?>()

    class VH(val b: ItemFileBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(ItemFileBinding.inflate(LayoutInflater.from(p.context), p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val f = items[pos]
        val ctx = h.b.root.context
        h.b.tvName.text = f.name
        val base = searchBase
        h.b.tvSub.text = if (base != null) {
            val rel = f.parentFile?.absolutePath
                ?.removePrefix(base.absolutePath)?.trimStart('/') ?: ""
            val loc = if (rel.isEmpty()) "bu klasörde" else rel
            if (f.isDirectory) loc else loc + "  ·  " + FileOps.fmtSize(f.length())
        } else if (f.isDirectory) {
            val n = f.list()?.size ?: 0; "$n öğe"
        } else FileOps.fmtSize(f.length())
        h.b.tvDate.text = df.format(Date(f.lastModified()))

        val ext = f.extension.lowercase(Locale.ROOT)
        val isImg = ext in MediaViewActivity.IMAGE_EXTS
        h.b.ivIcon.imageTintList = null

        if (isImg && f.isFile) {
            val key = f.absolutePath
            if (thumbCache.containsKey(key)) {
                val bm = thumbCache[key]
                if (bm != null) h.b.ivIcon.setImageBitmap(bm)
                else { h.b.ivIcon.setImageResource(R.drawable.ic_image); h.b.ivIcon.imageTintList = android.content.res.ColorStateList.valueOf(ContextCompat.getColor(ctx, R.color.accent)) }
            } else {
                h.b.ivIcon.setImageResource(R.drawable.ic_image)
                h.b.ivIcon.imageTintList = android.content.res.ColorStateList.valueOf(ContextCompat.getColor(ctx, R.color.accent))
                h.b.ivIcon.tag = key
                Thread {
                    val bm: Bitmap? = try {
                        val opts = android.graphics.BitmapFactory.Options().apply { inSampleSize = 4 }
                        BitmapFactory.decodeFile(f.absolutePath, opts)
                    } catch (_: Exception) { null }
                    thumbCache[key] = bm
                    h.b.ivIcon.post {
                        if (h.b.ivIcon.tag == key) {
                            if (bm != null) { h.b.ivIcon.setImageBitmap(bm); h.b.ivIcon.imageTintList = null }
                        }
                    }
                }.start()
            }
        } else {
            h.b.ivIcon.setImageResource(iconFor(f, ext))
            h.b.ivIcon.imageTintList = android.content.res.ColorStateList.valueOf(ContextCompat.getColor(ctx, R.color.accent))
        }

        h.b.rowRoot.setBackgroundColor(
            if (selected.contains(f.absolutePath))
                ContextCompat.getColor(ctx, R.color.surface_alt)
            else ContextCompat.getColor(ctx, android.R.color.transparent)
        )
        h.b.rowRoot.setOnClickListener { onClick(f) }
        h.b.rowRoot.setOnLongClickListener { onLong(f); true }
    }

    private fun iconFor(f: File, ext: String): Int {
        if (f.isDirectory) return R.drawable.ic_folder
        return when (ext) {
            in MediaViewActivity.IMAGE_EXTS -> R.drawable.ic_image
            in setOf("mp3","wav","m4a","ogg","flac","aac","opus") -> R.drawable.ic_music_note
            in MediaViewActivity.VIDEO_EXTS -> R.drawable.ic_video
            in setOf("txt","log","md","json","csv","srt","ini") -> R.drawable.ic_text
            "pdf" -> R.drawable.ic_pdf
            in setOf("doc","docx","pptx","ppt") -> R.drawable.ic_docx
            in setOf("zip","rar","7z") -> R.drawable.ic_zip
            else -> R.drawable.ic_file
        }
    }
}
