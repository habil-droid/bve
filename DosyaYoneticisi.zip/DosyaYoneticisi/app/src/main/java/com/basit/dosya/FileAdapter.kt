package com.basit.dosya

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.basit.dosya.databinding.ItemFileBinding
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FileAdapter(
    private val selection: Set<String>,
    private val onClick: (File) -> Unit,
    private val onLong: (File) -> Unit
) : RecyclerView.Adapter<FileAdapter.VH>() {

    var items: List<File> = emptyList()

    fun submit(list: List<File>) {
        items = list
        notifyDataSetChanged()
    }

    private val df = SimpleDateFormat("d MMM yyyy", Locale("tr"))

    class VH(val b: ItemFileBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemFileBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val f = items[pos]
        val ctx = h.b.root.context
        h.b.tvName.text = f.name
        h.b.tvSub.text = if (f.isDirectory) {
            val n = f.list()?.size ?: 0
            "$n öğe"
        } else FileOps.fmtSize(f.length())
        h.b.tvDate.text = df.format(Date(f.lastModified()))
        h.b.ivIcon.setImageResource(iconFor(f))
        val sel = selection.contains(f.absolutePath)
        h.b.rowRoot.setBackgroundColor(
            if (sel) ContextCompat.getColor(ctx, R.color.surface_alt)
            else ContextCompat.getColor(ctx, android.R.color.transparent)
        )
        h.b.rowRoot.setOnClickListener { onClick(f) }
        h.b.rowRoot.setOnLongClickListener { onLong(f); true }
    }

    private fun iconFor(f: File): Int {
        if (f.isDirectory) return R.drawable.ic_folder
        return when (f.extension.lowercase(Locale.ROOT)) {
            "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic" -> R.drawable.ic_image
            "mp3", "wav", "m4a", "ogg", "flac", "aac", "opus" -> R.drawable.ic_audio
            "mp4", "mkv", "avi", "mov", "webm", "3gp" -> R.drawable.ic_video
            "txt", "log", "md", "json", "csv", "srt", "ini" -> R.drawable.ic_text
            else -> R.drawable.ic_file
        }
    }
}
