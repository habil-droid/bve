# 📁 Basit Dosya Yöneticisi — Sürüm 3.2

Tek Activity, tek bölme mimari. Kotlin. Bu sürüm ÇÖKME sorunlarını ve müzik
player tutarsızlığını kökten çözer.

## Sürüm 3.2 — kritik düzeltmeler

### 💥 ÇÖKME düzeltildi (kök neden bulundu)
İki ayrı çökme kaynağı vardı:

1. **Albüm kapağı ANA THREAD'de her saniye çözülüyordu.** Müzik çalarken bildirim
   her saniye yeniden oluşturuluyor, her seferinde albüm kapağı (bazen 1-2 MB)
   ana thread'de yeniden decode ediliyordu → ana thread kilitleniyor → Android
   "uygulama yanıt vermiyor" deyip öldürüyordu (ANR çökmesi). Bu yüzden müzik
   açıkken txt okurken geri çıkınca **her zaman**, müzik kapalıyken **bazen**
   çöküyordu. **Düzeltme:** Albüm kapağı artık yalnızca şarkı değişince BİR KEZ
   ve ARKA PLANDA çözülüp önbelleğe alınıyor. İlerleme döngüsü sadece hafif
   MediaSession durumunu güncelliyor, bildirimi yeniden oluşturmuyor.
   (Görsel 4'te bildirimin ancak çökünce düzgün görünmesi de bunu doğruluyordu:
   Activity ölünce ana thread boşalıp servis temiz render ediyordu.)

2. **Fragment `commitNow()` durum kaydından sonra çağrılınca çöküyordu.**
   Tema değişimi/geri tuşunda `IllegalStateException`. **Düzeltme:** Tüm fragment
   geçişleri artık `commitAllowingStateLoss()` ve durum-güvenli `safeReplace()`
   ile yapılıyor.

### 🎵 Müzik player tutarsızlığı düzeltildi (mimari birleştirme)
Önceki tutarsızlığın nedeni: "Müzikler" sekmesi ESKİ `BrowseActivity`'yi (kendi
player barıyla), SD karttan gezinme ise YENİ `FolderFragment`'ı kullanıyordu.
Bu yüzden müzik bazen görünüyor bazen görünmüyordu.
- **`BrowseActivity` ve `ViewerActivity` tamamen kaldırıldı.**
- `MediaFolderActivity`'de bir müzik/resim klasörüne dokununca artık ana sistemin
  klasör görünümüne yönlendiriliyor → **her yerde AYNI** klasör görünümü ve
  **AYNI** müzik player barı.
- **Uygulama içi player barı geri geldi** ve artık **ilerleme çubuğu (SeekBar)**
  içeriyor — sürükleyerek ileri/geri sarabilirsin.
- **Görünürlük kuralı:** player barı YALNIZCA (a) ana sayfada müzik çalarken ve
  (b) müziğin başlatıldığı o klasörde görünür. Başka klasöre geçince veya o
  klasörden çıkınca kaybolur.

### 🔔 Bildirim / kilit ekranı
- İlerleme çubuğunu bozan `setProgress()` kaldırıldı → sistemin kendi kaydırma
  çubuğu artık düzgün çalışıyor (dümdüz çizgi sorunu bitti).
- Mod değiştirme (tek tekrar / sırayla) bildirimde gerçek buton.
- `setColorized(true)` ile bildirim tema rengine boyanıyor.
- Medya tuşu (kulaklık/bluetooth) çökmesini önlemek için `MEDIA_BUTTON` alıcısı
  ve servis intent-filter'ı eklendi.
- **Samsung kilit ekranı sınırı**: Samsung, kilit ekranında OS seviyesinde
  yalnızca önceki/oynat/sonraki 3 butonu gösterir; mod ve durdur bildirim
  çubuğunda (aşağı çekince) görünür. Bu Samsung'un genel bir kısıtı.

### 📝 Metin editörü
- Alt çubuğa **"En Alt / En Üst"** butonu eklendi (Tümünü Sil ile Kopyala
  arasında). Bir kez bas → metnin en altına in; tekrar bas → en üste çık.
- Alt çubuk: `Geri Al | Tümünü Sil | En Alt | Kopyala | Kaydet`.

## Teknik
- `MusicService.kt` — önbellekli albüm kapağı, hafif ilerleme döngüsü, MediaButton
- `PlayerBarController.kt` — Home/Folder paylaşımlı player barı (SeekBar dahil)
- `MainActivity.kt` — `safeReplace()`, `onNewIntent` ile klasör yönlendirme
- `BrowseActivity`/`ViewerActivity` silindi; her şey tek Activity + Fragment
