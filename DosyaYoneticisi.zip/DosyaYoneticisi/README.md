# 📁 Basit Dosya Yöneticisi — Sürüm 3.3

## Sürüm 3.3 — kritik çökme düzeltmesi + 4 yeni özellik

### 💥 "Geri basınca uygulamadan atıyor" — KÖK NEDEN BULUNDU
`TextEditorFragment.onDestroyView()` içinde zorunlu `super.onDestroyView()`
çağrısı eksikti. AndroidX Fragment bu çağrıyı denetler; eksikse
`SuperNotCalledException` fırlatır. Yani:
- TXT'de geri tuşu → editör kapatılırken fragment yok ediliyor → çökme
- TXT açıkken breadcrumb'dan klasöre/ana sayfaya dönüş → aynı yıkım → çökme
Kullanıcının "uygulamadan komple çıkıyor" dediği şey bu çökmeydi.
Tek satırlık `super.onDestroyView()` eklendi; artık geri tuşu ve breadcrumb
düzgün çalışıyor (diğer iki fragment'ta çağrı zaten vardı).

### ➕ Yeni klasör / yeni dosya oluşturma
Üst çubuğa, tema butonunun yanına **+** butonu eklendi (yalnızca klasör
görünümünde görünür; ana sayfa/editör/çöp kutusunda gizli).
+ → "Yeni klasör" veya "Yeni dosya" → ad gir → oluştur. Liste anında yenilenir.

### 📋 Yapıştır çubuğu artık kalıcı
Bir şey kopyalandığında/kesildiğinde alttaki ızgara çubuk (Yapıştır dahil)
**yapıştırılana kadar her klasörde açık kalır** — boş klasörlerde de
yapıştırabilirsin. Yapıştır'a **uzun basmak** panoyu iptal eder.

### 🖼️🎬 Yerleşik görüntü ve video görüntüleyici
Artık resim/videoya dokununca VLC gibi harici uygulama gerekmez:
- **Resimler**: uygulama içinde tam ekran açılır; üst şeritteki ◀ ▶ ile aynı
  klasördeki resimler arasında gezinilir. Dev fotoğraflar bellek-güvenli
  (örneklemeli) yüklenir, OOM çökmesi olmaz.
- **Videolar**: uygulama içinde oynar; ekrana dokununca sistem kontrolleri
  (oynat/duraklat/ileri-geri sarma) çıkar. Video açılırken çalan müzik
  otomatik duraklatılır. Ekran döndürme serbest.
- **Dürüst sınır**: mp4/webm/3gp sorunsuz; **mkv/avi** gibi formatlar cihazın
  codec desteğine bağlıdır — desteklenmiyorsa uygulama açıklayıcı mesaj verir
  (bu durumda VLC hâlâ gerekebilir).

### ♻️ Bonus: Çöp kutusu geri yükleme geri geldi
Mimari birleştirmede kaybolmuştu: çöp kutusunda bir öğeye dokununca artık
"Geri yükle / Kalıcı sil" diyaloğu çıkıyor.
