# 📁 Basit Dosya Yöneticisi — Sürüm 1.0

Reklamsız, premium temalı, Türkçe dosya yöneticisi. Kotlin, tek APK.

## Özellikler
- **Ana ekran**: Ana bellek, SD kart (varsa), İndirilenler, Görüntüler, Ses, Videolar,
  Geri Dönüşüm Kutusu. (Bulut/Ağ/Uygulamalar gibi kalabalık yok — istenmedi.)
- **Gezinme**: klasörlere dalma, ⬆ ile üst klasör, klasörde ada göre arama,
  gizli dosyaları göster/gizle.
- **Çoklu seçim** (uzun bas): Kopyala · Taşı · Yeniden adlandır · Sil · Daha fazla
  (Paylaş / Sıkıştır (zip) / Şununla aç / Özellikler).
- **Geri dönüşüm kutusu**: silinen her şey önce kutuya gider; oradan Geri Yükle
  (asıl yerine) veya Kalıcı Sil; menüden Kutuyu Boşalt.
- **Zip**: seçilenleri sıkıştır; bir .zip'e dokununca "Buraya ayıkla".
- **Tema**: açık/koyu — renkler index.html referansından birebir
  (açık: mavi #2B6CB0 vurgu, koyu: saf siyah zemin + mor #A38AE2 vurgu).

## 📝 Metin görüntüleyici (txt/log/md/json/csv/srt/ini)
- **Çok sekmeli**: bir dosya açıkken geri dönüp başka bir txt açarsan
  **yeni sekme** olarak eklenir; sekmeler kalıcıdır (uygulama kapansa bile hatırlanır).
- Üstte **sekme şeridi**, altında **tam dosya yolu**.
- **Yazı boyutu**: A− / A+ (hatırlanır). Metin ekrana **sığar** (yatay kaydırma yok).
- **Kaydet**in yanında: **Tümünü kopyala · İlk yarıyı kopyala · Son yarıyı kopyala**
  (yarılar satır sınırında akıllıca bölünür).
- Metin içinde **arama** (Bul → sonraki eşleşmeye atlar), düzenleme + kaydet.
- Kapatırken kaydedilmemiş değişiklik varsa sorar (Tümünü kaydet / Kaydetme / İptal).

## İzin
İlk açılışta Android **"Tüm dosyalara erişim"** izni ister (Ayarlar sayfası açılır,
anahtarı aç, geri dön). Bu izin olmadan dosya yöneticisi çalışamaz.

## Derleme
GitHub Actions ile: repo köküne bu zip + `.github/workflows/derle.yml` → push →
Artifacts'ten `app-debug.apk`.
