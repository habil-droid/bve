# 📁 Basit Dosya Yöneticisi — Sürüm 3.1

Tek Activity, tek bölme (single-pane) mimari. Kotlin.

## Sürüm 3.1'de düzeltilenler

### 🧭 Sekme sistemi kaldırıldı, tek breadcrumb kaldı
- Kullanıcı isteğiyle çoklu sekme/çoklu dosya fikri tamamen terk edildi.
- Artık **tek** navigasyon göstergesi var: üstteki **ızgaralı (chip) breadcrumb**.
  `Ana Sayfa › İndirilenler › Hadis › 200.txt` — her segment ayrı bir buton,
  tıklanınca doğrudan o noktaya döner. Klasöre indikçe sağa doğru büyür,
  yatay kaydırılabilir.
- **Tek dosya açılır.** TXT'ye dokun → editör açılır (klasörün üzerine biner).
  Geri tuşuna bas veya kaydet → **aynı klasöre** döner. İki klasör/iki dosya
  aynı anda açık tutma yok.

### 🎨 Tema geçişi düzeltildi (kök neden bulundu)
Önceki sürümde `configChanges="uiMode"` manifestte tanımlıydı ama buna karşılık
gelen bir `onConfigurationChanged` kodu yoktu — bu yüzden tema değişince Activity
yeniden **oluşmuyor**, bazı görünümler eski renklerde kalıp karışık/bozuk
görünüyordu. Ayrıca tema butonu yalnızca ana sayfada görünürdü.
- `configChanges="uiMode"` kaldırıldı → tema değişince Activity **düzgünce**
  yeniden oluşuyor (Android'in önerdiği güvenilir yöntem).
- Konum (hangi klasördeydin / hangi dosya açıktı) `onSaveInstanceState` ile
  korunuyor — tema değiştirince kaldığın yerde devam ediyorsun.
- Tema butonu artık **her ekranda** (ana sayfa, klasör, editör) erişilebilir.

### 🎵 Müzik bildirimi/kilit ekranı düzeltildi
- Bildirimdeki `setProgress()` çağrısı kaldırıldı — bu, MediaStyle'ın kendi
  ilerleme çubuğuyla çakışıp "düz çizgi" görünümüne yol açıyordu. Artık sistem
  kendi kaydırma çubuğunu (scrubber) doğru gösteriyor.
- **Mod değiştirme (tek tekrar / sırayla)** artık bildirimde gerçek bir buton.
- Bildirim artık `setColorized(true)` ile tema rengine (açık: mavi, koyu: mor)
  gerçekten boyanıyor.
- **Dürüst bir not**: Samsung'un kilit ekranı medya kartı, OS seviyesinde
  yalnızca önceki/oynat-duraklat/sonraki 3 butonu gösterir; mod ve durdur
  butonları **bildirim çubuğunda** (aşağı çekince) görünür — bu bir uygulama
  eksikliği değil, Samsung'un kilit ekranı bileşeninin genel bir sınırı.

## GitHub Actions hakkında
Log'daki `"Resource not accessible by integration"` hatası **zararsızdır** —
yalnızca GitHub Release oluşturma adımı (isteğe bağlı, `continue-on-error: true`)
başarısız oluyor; APK derlemesi ve Artifacts'e yükleme **etkilenmiyor**,
`app-debug.apk` her zaman üretiliyor. İstersen bu adımı `derle.yml`'den
tamamen kaldırıp logu temizleyebilirim — söylemen yeterli.

## Kullanım
- **Breadcrumb**: herhangi bir segmente dokun → doğrudan oraya git
- **Klasöre dokun** → içine gir (breadcrumb büyür)
- **TXT'ye dokun** → editör açılır; geri tuşu/kaydet → klasöre döner
- **Uzun bas** → çoklu seçim (Sil/Adlandır/ZIP/Paylaş/Kes/Kopyala)
- **Tema butonu** → her ekranda sağ üstte

## Teknik
- `MainActivity.kt` — tek navigasyon durumu: `navChain` (klasör zinciri) + `openFile`
- `HomeFragment` / `FolderFragment` / `TextEditorFragment` — `replace()` ile
  değiştirilir, artık kalıcı sekme instance'ları yok
- `MusicService.kt` — MediaSessionCompat + doğru scrubber + mod-değiştirme aksiyonu
