package com.basit.videoeditor

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.basit.videoeditor.databinding.ItemClipBinding
import com.google.android.material.button.MaterialButton

/**
 * Kırmızı alan: yatay zaman çizelgesi.
 * Kliplerin küçük görüntülerini gösterir, sonda "+" butonu bulunur.
 */
class TimelineAdapter(
    private val clips: List<Clip>,
    private val onClipClick: (Int) -> Unit,
    private val onAddClick: () -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var selected: Int = -1
        set(value) {
            val old = field
            field = value
            if (old >= 0 && old < clips.size) notifyItemChanged(old)
            if (value >= 0 && value < clips.size) notifyItemChanged(value)
        }

    inner class ClipVH(val vb: ItemClipBinding) : RecyclerView.ViewHolder(vb.root) {
        init {
            vb.root.setOnClickListener {
                val p = bindingAdapterPosition
                if (p != RecyclerView.NO_POSITION && p < clips.size) onClipClick(p)
            }
        }
    }

    class AddVH(view: View) : RecyclerView.ViewHolder(view)

    override fun getItemViewType(position: Int) =
        if (position == clips.size) TYPE_ADD else TYPE_CLIP

    override fun getItemCount() = clips.size + 1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == TYPE_ADD) {
            val d = parent.resources.displayMetrics.density
            val btn = MaterialButton(parent.context).apply {
                text = "＋"
                textSize = 22f
                insetTop = 0
                insetBottom = 0
                layoutParams = ViewGroup.MarginLayoutParams(
                    (64 * d).toInt(), (72 * d).toInt()
                ).apply {
                    setMargins((4 * d).toInt(), (4 * d).toInt(), (4 * d).toInt(), (4 * d).toInt())
                }
                setOnClickListener { onAddClick() }
            }
            AddVH(btn)
        } else {
            ClipVH(ItemClipBinding.inflate(LayoutInflater.from(parent.context), parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder !is ClipVH) return
        val c = clips[position]
        holder.vb.tvDur.text = String.format("%.1f sn", c.durationMs / 1000f)
        if (c.thumb != null) {
            holder.vb.ivThumb.setImageBitmap(c.thumb)
        } else {
            holder.vb.ivThumb.setImageResource(
                if (c.type == ClipType.IMAGE) android.R.drawable.ic_menu_gallery
                else android.R.drawable.ic_media_play
            )
        }
        val d = holder.vb.root.resources.displayMetrics.density
        holder.vb.card.strokeWidth = if (position == selected) (3 * d).toInt() else 0
    }

    companion object {
        private const val TYPE_CLIP = 0
        private const val TYPE_ADD = 1
    }
}
