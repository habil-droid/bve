package com.basit.videoeditor

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.TextOverlay
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import java.io.File
import java.io.IOException

/**
 * 💾 Kaydet: klipleri birleştirir, müziği döngüyle alta serer,
 * yazı ve görsel katmanlarını videoya "yakar", sonucu galeriye MP4 yazar.
 */
@OptIn(UnstableApi::class)
object ExportHelper {

    fun export(
        context: Context,
        clips: List<Clip>,
        audios: List<AudioClip>,
        overlayText: String?,
        overlayImage: Bitmap?,
        onProgress: (Int) -> Unit,
        onDone: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        try {
            // 1) Video/fotoğraf sırası
            val videoItems = clips.map { c ->
                if (c.type == ClipType.IMAGE) {
                    val mi = MediaItem.Builder()
                        .setUri(c.uri)
                        .setMimeType(c.mime ?: MimeTypes.IMAGE_JPEG)
                        .build()
                    EditedMediaItem.Builder(mi)
                        .setDurationUs(c.durationMs * 1000)
                        .setFrameRate(30)
                        .build()
                } else {
                    val mi = MediaItem.Builder()
                        .setUri(c.uri)
                        .setClippingConfiguration(
                            MediaItem.ClippingConfiguration.Builder()
                                .setStartPositionMs(c.startMs)
                                .setEndPositionMs(c.endMs)
                                .build()
                        )
                        .build()
                    EditedMediaItem.Builder(mi).build()
                }
            }
            val sequences = mutableListOf(EditedMediaItemSequence(videoItems))

            // 2) Müzik sırası (video bitene kadar döngüde çalar)
            if (audios.isNotEmpty()) {
                val audioItems = audios.map {
                    EditedMediaItem.Builder(MediaItem.fromUri(it.uri))
                        .setRemoveVideo(true)
                        .build()
                }
                sequences.add(EditedMediaItemSequence(audioItems, /* isLooping = */ true))
            }

            // 3) Katmanlar (yazı + görsel) — videonun üzerine yakılır
            val overlays = mutableListOf<TextureOverlay>()
            if (!overlayText.isNullOrBlank()) {
                val s = SpannableString(overlayText)
                s.setSpan(ForegroundColorSpan(Color.WHITE), 0, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                s.setSpan(AbsoluteSizeSpan(96), 0, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                overlays.add(TextOverlay.createStaticTextOverlay(s))
            }
            overlayImage?.let { overlays.add(BitmapOverlay.createStaticBitmapOverlay(it)) }

            val builder = Composition.Builder(sequences)
            if (overlays.isNotEmpty()) {
                builder.setEffects(
                    Effects(emptyList(), listOf(OverlayEffect(ImmutableList.copyOf(overlays))))
                )
            }
            // Fotoğrafların sesi olmadığı için sessiz ses parçası zorunlu
            if (clips.any { it.type == ClipType.IMAGE }) {
                builder.experimentalSetForceAudioTrack(true)
            }
            val composition = builder.build()

            // 4) Dönüştür ve kaydet
            val outFile = File(context.cacheDir, "kayit_${System.currentTimeMillis()}.mp4")
            val handler = Handler(Looper.getMainLooper())
            var polling = true

            val transformer = Transformer.Builder(context)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        polling = false
                        try {
                            val where = saveToGallery(context, outFile)
                            outFile.delete()
                            onDone(where)
                        } catch (e: Exception) {
                            onError(e.message ?: "Kaydetme hatası")
                        }
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        polling = false
                        onError(exportException.message ?: "Dışa aktarma hatası")
                    }
                })
                .build()

            transformer.start(composition, outFile.absolutePath)

            // İlerleme takibi
            val progressHolder = ProgressHolder()
            handler.post(object : Runnable {
                override fun run() {
                    if (!polling) return
                    if (transformer.getProgress(progressHolder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                        onProgress(progressHolder.progress)
                    }
                    handler.postDelayed(this, 500)
                }
            })
        } catch (e: Exception) {
            onError(e.message ?: "Beklenmeyen hata")
        }
    }

    /** Bitmiş MP4'ü galerinin Movies/BasitVideoEditor klasörüne kopyalar. */
    private fun saveToGallery(context: Context, src: File): String {
        return if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, src.name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/BasitVideoEditor")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("Galeri kaydı oluşturulamadı")
            (resolver.openOutputStream(uri) ?: throw IOException("Çıkış akışı açılamadı")).use { out ->
                src.inputStream().use { it.copyTo(out) }
            }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            "Filmler (Movies)/BasitVideoEditor/${src.name}"
        } else {
            val dir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
                ?: throw IOException("Klasör bulunamadı")
            val dest = File(dir, src.name)
            src.copyTo(dest, overwrite = true)
            dest.absolutePath
        }
    }
}
