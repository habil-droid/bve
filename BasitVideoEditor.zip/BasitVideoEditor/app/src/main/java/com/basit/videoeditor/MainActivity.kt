package com.basit.videoeditor

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.recyclerview.widget.LinearLayoutManager
import com.basit.videoeditor.databinding.ActivityMainBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.slider.RangeSlider
import com.google.android.material.slider.Slider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Collections

@OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var player: ExoPlayer          // Siyah alan: önizleme
    private var audioPlayer: ExoPlayer? = null      // Müzik önizlemesi

    private val clips = mutableListOf<Clip>()       // Kırmızı alan: klipler
    private val audios = mutableListOf<AudioClip>() // Kırmızı alan: müzik satırı
    private var overlayText: String? = null         // Mavi alan: yazı katmanı
    private var overlayImageUri: Uri? = null        // Mavi alan: görsel katman
    private var nextId = 1L

    private lateinit var timelineAdapter: TimelineAdapter

    // Fotoğraf/video seçici (izin gerektirmez)
    private val mediaPicker =
        registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(10)) { uris ->
            uris.forEach { addClip(it) }
        }

    private val audioPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { addAudio(it) }
        }

    private val overlayImagePicker =
        registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            uri?.let {
                overlayImageUri = it
                updateOverlayViews()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        player = ExoPlayer.Builder(this).build()
        b.playerView.player = player
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                audioPlayer?.let { if (isPlaying) it.play() else it.pause() }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    audioPlayer?.pause()
                    audioPlayer?.seekTo(0, 0)
                }
            }
        })

        timelineAdapter = TimelineAdapter(
            clips,
            onClipClick = { pos ->
                timelineAdapter.selected = pos
                player.seekToDefaultPosition(pos)
            },
            onAddClick = { pickMedia() }
        )
        b.rvTimeline.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        b.rvTimeline.adapter = timelineAdapter

        // Mavi alan butonları
        b.btnAddMedia.setOnClickListener { pickMedia() }
        b.btnAddAudio.setOnClickListener { pickAudio() }
        b.btnAudioAdd.setOnClickListener { pickAudio() }
        b.btnText.setOnClickListener { showTextDialog() }
        b.btnOverlayImage.setOnClickListener {
            overlayImagePicker.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
            )
        }
        b.btnOverlayImage.setOnLongClickListener {
            overlayImageUri = null
            updateOverlayViews()
            toast(R.string.katman_kaldirildi)
            true
        }
        b.btnExport.setOnClickListener { startExport() }

        // Klip işlemleri
        b.btnTrim.setOnClickListener { trimSelected() }
        b.btnSplit.setOnClickListener { splitAtPlayhead() }
        b.btnDelete.setOnClickListener { deleteSelected() }
        b.btnMoveLeft.setOnClickListener { moveSelected(-1) }
        b.btnMoveRight.setOnClickListener { moveSelected(1) }

        b.tvAudio.setOnLongClickListener {
            if (audios.isNotEmpty()) {
                audios.clear()
                refreshAudioPlayer()
                updateAudioLabel()
                toast(R.string.muzik_kaldirildi)
            }
            true
        }
    }

    // ---------------- MEDYA EKLEME ----------------

    private fun pickMedia() = mediaPicker.launch(
        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
    )

    private fun pickAudio() = audioPicker.launch(arrayOf("audio/*"))

    private fun addClip(uri: Uri) {
        val mime = contentResolver.getType(uri) ?: ""
        val clip = if (mime.startsWith("image")) {
            Clip(nextId++, uri, ClipType.IMAGE, mime, 0L, 3000L, 15000L)
        } else {
            val dur = mediaDurationMs(uri)
            if (dur <= 0) {
                toast(R.string.dosya_okunamadi)
                return
            }
            Clip(nextId++, uri, ClipType.VIDEO, mime, 0L, dur, dur)
        }
        clips.add(clip)
        timelineAdapter.notifyDataSetChanged()
        timelineAdapter.selected = clips.size - 1
        loadThumb(clip)
        rebuildPlayer(keepPosition = clips.size > 1)
        updateHint()
    }

    private fun addAudio(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: Exception) {
        }
        audios.add(AudioClip(uri, displayName(uri)))
        refreshAudioPlayer()
        updateAudioLabel()
        if (audios.size == 1) toast(R.string.muzik_ipucu)
    }

    private fun mediaDurationMs(uri: Uri): Long = try {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(this, uri)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
        } finally {
            try { r.release() } catch (_: Exception) { }
        }
    } catch (_: Exception) {
        0L
    }

    private fun displayName(uri: Uri): String = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: "Ses"
    } catch (_: Exception) {
        "Ses"
    }

    private fun loadThumb(clip: Clip) {
        lifecycleScope.launch(Dispatchers.IO) {
            val bmp: Bitmap? = try {
                if (clip.type == ClipType.IMAGE) {
                    decodeScaled(clip.uri, 240)
                } else {
                    val r = MediaMetadataRetriever()
                    try {
                        r.setDataSource(this@MainActivity, clip.uri)
                        r.getFrameAtTime(
                            clip.startMs * 1000,
                            MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                        )
                    } finally {
                        try { r.release() } catch (_: Exception) { }
                    }
                }
            } catch (_: Exception) {
                null
            }
            withContext(Dispatchers.Main) {
                clip.thumb = bmp
                val idx = clips.indexOfFirst { it.id == clip.id }
                if (idx >= 0) timelineAdapter.notifyItemChanged(idx)
            }
        }
    }

    // ---------------- ÖNİZLEME (SİYAH ALAN) ----------------

    private fun rebuildPlayer(keepPosition: Boolean = true) {
        if (clips.isEmpty()) {
            player.clearMediaItems()
            return
        }
        val idx = player.currentMediaItemIndex
        val pos = player.currentPosition
        player.setMediaItems(clips.map { it.toPreviewMediaItem() })
        player.prepare()
        player.playWhenReady = false
        if (keepPosition && idx < clips.size) {
            player.seekTo(idx, pos.coerceAtLeast(0))
        }
    }

    private fun refreshAudioPlayer() {
        if (audios.isEmpty()) {
            audioPlayer?.release()
            audioPlayer = null
            return
        }
        val ap = audioPlayer ?: ExoPlayer.Builder(this).build().also {
            it.repeatMode = Player.REPEAT_MODE_ALL
            audioPlayer = it
        }
        ap.setMediaItems(audios.map { MediaItem.fromUri(it.uri) })
        ap.prepare()
    }

    private fun updateAudioLabel() {
        b.tvAudio.text =
            if (audios.isEmpty()) getString(R.string.muzik_yok)
            else "🎵 " + audios.joinToString(", ") { it.name }
    }

    private fun updateHint() {
        b.tvHint.visibility = if (clips.isEmpty()) View.VISIBLE else View.GONE
    }

    // ---------------- KLİP İŞLEMLERİ ----------------

    private fun trimSelected() {
        val i = timelineAdapter.selected
        if (i !in clips.indices) {
            toast(R.string.klip_sec)
            return
        }
        val c = clips[i]

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val info = TextView(this)

        if (c.type == ClipType.IMAGE) {
            // Fotoğraf: gösterim süresi
            val slider = Slider(this).apply {
                valueFrom = 0.5f
                valueTo = 15f
                stepSize = 0.5f
                value = (c.durationMs / 1000f).coerceIn(0.5f, 15f)
            }
            info.text = getString(R.string.sure_fmt, slider.value)
            slider.addOnChangeListener { _, v, _ ->
                info.text = getString(R.string.sure_fmt, v)
            }
            box.addView(info)
            box.addView(slider)
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.fotograf_suresi)
                .setView(box)
                .setPositiveButton(R.string.tamam) { _, _ ->
                    c.startMs = 0
                    c.endMs = (slider.value * 1000).toLong()
                    afterClipEdit(i)
                }
                .setNegativeButton(R.string.iptal, null)
                .show()
        } else {
            // Video: baş/son kırpma
            val total = (c.sourceDurationMs / 1000f).coerceAtLeast(0.2f)
            val slider = RangeSlider(this).apply {
                valueFrom = 0f
                valueTo = total
                setValues(
                    (c.startMs / 1000f).coerceIn(0f, total),
                    (c.endMs / 1000f).coerceIn(0f, total)
                )
            }
            fun refresh() {
                val v = slider.values
                info.text = getString(R.string.aralik_fmt, v[0], v[1])
            }
            refresh()
            slider.addOnChangeListener { _, _, _ -> refresh() }
            box.addView(info)
            box.addView(slider)
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.kirp)
                .setView(box)
                .setPositiveButton(R.string.tamam) { _, _ ->
                    val v = slider.values
                    if (v[1] - v[0] < 0.2f) {
                        toast(R.string.cok_kisa)
                        return@setPositiveButton
                    }
                    c.startMs = (v[0] * 1000).toLong()
                    c.endMs = (v[1] * 1000).toLong()
                    afterClipEdit(i)
                }
                .setNegativeButton(R.string.iptal, null)
                .show()
        }
    }

    private fun afterClipEdit(i: Int) {
        timelineAdapter.notifyItemChanged(i)
        loadThumb(clips[i])
        rebuildPlayer()
    }

    /** Oynatma çizgisinin bulunduğu klibi o noktadan ikiye böler. */
    private fun splitAtPlayhead() {
        val i = player.currentMediaItemIndex
        if (clips.isEmpty() || i !in clips.indices) {
            toast(R.string.bol_ipucu)
            return
        }
        val c = clips[i]
        if (c.type == ClipType.IMAGE) {
            toast(R.string.foto_bolunmez)
            return
        }
        val posInClip = player.currentPosition
        if (posInClip < 300 || posInClip > c.durationMs - 300) {
            toast(R.string.bol_kenar)
            return
        }
        val cutAbs = c.startMs + posInClip
        val second = c.copy(id = nextId++, startMs = cutAbs, thumb = null)
        c.endMs = cutAbs
        clips.add(i + 1, second)
        timelineAdapter.notifyDataSetChanged()
        timelineAdapter.selected = i + 1
        loadThumb(second)
        rebuildPlayer()
        player.seekTo(i + 1, 0)
    }

    private fun deleteSelected() {
        val i = timelineAdapter.selected
        if (i !in clips.indices) {
            toast(R.string.klip_sec)
            return
        }
        clips.removeAt(i)
        timelineAdapter.selected = -1
        timelineAdapter.notifyDataSetChanged()
        rebuildPlayer(keepPosition = false)
        updateHint()
    }

    private fun moveSelected(dir: Int) {
        val i = timelineAdapter.selected
        val j = i + dir
        if (i !in clips.indices || j !in clips.indices) return
        Collections.swap(clips, i, j)
        timelineAdapter.selected = j
        timelineAdapter.notifyDataSetChanged()
        rebuildPlayer()
    }

    // ---------------- KATMANLAR (MAVİ ALAN) ----------------

    private fun showTextDialog() {
        val et = EditText(this).apply {
            setText(overlayText ?: "")
            hint = getString(R.string.yazi_hint)
        }
        val wrap = FrameLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(et)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.yazi_ekle)
            .setView(wrap)
            .setPositiveButton(R.string.tamam) { _, _ ->
                overlayText = et.text.toString().trim().ifEmpty { null }
                updateOverlayViews()
            }
            .setNeutralButton(R.string.kaldir) { _, _ ->
                overlayText = null
                updateOverlayViews()
            }
            .setNegativeButton(R.string.iptal, null)
            .show()
    }

    /** Önizlemenin üzerindeki canlı katman görünümlerini yeniler. */
    private fun updateOverlayViews() {
        b.overlayContainer.removeAllViews()
        overlayText?.let { t ->
            b.overlayContainer.addView(TextView(this).apply {
                text = t
                setTextColor(Color.WHITE)
                textSize = 22f
                setShadowLayer(6f, 0f, 0f, Color.BLACK)
                gravity = Gravity.CENTER
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER
                )
            })
        }
        overlayImageUri?.let { uri ->
            val iv = ImageView(this).apply {
                layoutParams = FrameLayout.LayoutParams(dp(140), dp(140), Gravity.CENTER)
                alpha = 0.95f
            }
            b.overlayContainer.addView(iv)
            lifecycleScope.launch(Dispatchers.IO) {
                val bmp = decodeScaled(uri, 480)
                withContext(Dispatchers.Main) { iv.setImageBitmap(bmp) }
            }
        }
    }

    // ---------------- KAYDET ----------------

    private fun startExport() {
        if (clips.isEmpty()) {
            toast(R.string.once_klip)
            return
        }
        player.pause()

        val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            isIndeterminate = false
        }
        val msg = TextView(this).apply {
            text = getString(R.string.hazirlaniyor)
            setPadding(0, dp(8), 0, 0)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(8))
            addView(pb)
            addView(msg)
        }
        val dlg = MaterialAlertDialogBuilder(this)
            .setTitle(R.string.disa_aktariliyor)
            .setView(box)
            .setCancelable(false)
            .show()

        lifecycleScope.launch {
            val ovBmp = overlayImageUri?.let {
                withContext(Dispatchers.IO) { decodeScaled(it, 512) }
            }
            ExportHelper.export(
                this@MainActivity,
                clips.toList(),
                audios.toList(),
                overlayText,
                ovBmp,
                onProgress = { p ->
                    pb.progress = p
                    msg.text = "%$p"
                },
                onDone = { where ->
                    dlg.dismiss()
                    MaterialAlertDialogBuilder(this@MainActivity)
                        .setTitle(R.string.kaydedildi)
                        .setMessage(getString(R.string.kayit_yeri, where))
                        .setPositiveButton(R.string.tamam, null)
                        .show()
                },
                onError = { e ->
                    dlg.dismiss()
                    MaterialAlertDialogBuilder(this@MainActivity)
                        .setTitle(R.string.hata)
                        .setMessage(e)
                        .setPositiveButton(R.string.tamam, null)
                        .show()
                }
            )
        }
    }

    // ---------------- YARDIMCILAR ----------------

    private fun decodeScaled(uri: Uri, maxDim: Int): Bitmap? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, bounds)
        }
        var sample = 1
        while (bounds.outWidth / sample > maxDim || bounds.outHeight / sample > maxDim) sample *= 2
        contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        }
    } catch (_: Exception) {
        null
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(res: Int) = Toast.makeText(this, res, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        player.release()
        audioPlayer?.release()
        super.onDestroy()
    }
}
