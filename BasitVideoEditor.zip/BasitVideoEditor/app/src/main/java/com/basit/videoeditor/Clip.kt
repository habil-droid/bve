package com.basit.videoeditor

import android.graphics.Bitmap
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi

enum class ClipType { VIDEO, IMAGE }

/**
 * Zaman çizelgesindeki tek bir parça (kırmızı alan).
 * startMs/endMs kırpma aralığıdır; fotoğraflarda endMs = gösterim süresi.
 */
data class Clip(
    val id: Long,
    val uri: Uri,
    val type: ClipType,
    val mime: String?,
    var startMs: Long,
    var endMs: Long,
    val sourceDurationMs: Long,
    var thumb: Bitmap? = null
) {
    val durationMs: Long get() = endMs - startMs
}

/** Müzik satırındaki bir ses dosyası. */
data class AudioClip(val uri: Uri, val name: String)

/** Önizleme oynatıcısı (ExoPlayer) için MediaItem üretir. */
@OptIn(UnstableApi::class)
fun Clip.toPreviewMediaItem(): MediaItem =
    if (type == ClipType.IMAGE) {
        MediaItem.Builder()
            .setUri(uri)
            .setMimeType(mime)
            .setImageDurationMs(durationMs)
            .build()
    } else {
        MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(startMs)
                    .setEndPositionMs(endMs)
                    .build()
            )
            .build()
    }
