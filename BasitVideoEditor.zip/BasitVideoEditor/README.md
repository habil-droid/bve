# 🎬 Basit Video Editör

KineMaster tarzı, sade bir Android video kesme–birleştirme uygulaması. Çizimindeki üç alan birebir uygulandı:

| Çizimdeki alan | Uygulamadaki karşılığı |
|---|---|
| ⬛ Siyah alan | Üstteki önizleme ekranı (ExoPlayer). Klipleri oynatır, oynatma çizgisini burada kaydırırsın. |
| 🟦 Mavi kutular | Sağdaki buton sütunu: **T** yazı katmanı, **🖼** görsel katman, **🎬** video/fotoğraf ekle, **🎵** ses ekle, **💾** kaydet. |
| 🟥 Kırmızı şerit | Alttaki zaman çizelgesi: klip sırası (＋ ile ekleme) ve altında müzik satırı (＋ ile ekleme). |

## Özellikler
- Video ve fotoğraf ekleme (çoklu seçim, **izin gerektirmez** — Photo Picker)
- ✂ **Kırp**: seçili klibin başını/sonunu sürgüyle kes (fotoğraflarda gösterim süresi 0,5–15 sn)
- ∥ **Böl**: oynatma çizgisinin olduğu noktadan klibi ikiye ayır
- 🗑 Sil, ◀ ▶ ile klip sırasını değiştir
- 🎵 Arka plan müziği (video bitene kadar döngüde çalar, dışa aktarmaya karışır)
- **T** yazı katmanı ve **🖼** görsel katman (önizlemede canlı görünür, kaydederken videoya yakılır)
- 💾 MP4 olarak galeriye kaydetme: `Filmler (Movies)/BasitVideoEditor/` (ilerleme çubuğuyla)

## Kurulum
1. **Android Studio Ladybug (2024.2) veya daha yenisini** kur.
2. Bu klasörü `File → Open` ile aç.
3. İlk açılışta Gradle gerekli her şeyi internetten indirir (birkaç dakika sürebilir).
4. Telefonunu USB ile bağla, geliştirici modunu aç ve **Run ▶** de.
   - En az **Android 8.0** gerekir; **Android 10+** önerilir (galeriye kayıt Android 10 ve üzerinde `Movies/BasitVideoEditor` klasörüne, daha eskilerde uygulamanın kendi klasörüne yapılır).

## Kullanım
1. **🎬** ile (veya zaman çizelgesindeki ＋ ile) video/fotoğraf ekle.
2. Zaman çizelgesinde bir klibe dokun → mavi çerçeveyle seçilir, önizleme o klibe atlar.
3. **✂ Kırp** ile baş/son ayarla. **Bölmek için:** videoyu oynat ya da kaydır, nokta klibin içindeyken **∥ Böl** butonuna bas.
4. **🎵** ile müzik ekle (müzik satırına uzun basarak kaldırabilirsin).
5. **T** ile yazı, **🖼** ile görsel katman ekle (🖼 butonuna uzun basarak kaldır).
6. **💾** ile kaydet; bitince videonun yerini gösteren pencere açılır.

## Teknik yapı
- **Kotlin** + ViewBinding, tek ekran (`MainActivity`)
- **Media3 1.5.1**
  - `ExoPlayer` → önizleme (kırpılmış klip listesi + fotoğraflar)
  - `Transformer` + `Composition` → kesme, birleştirme, müzik miksleme, katman yakma, MP4 çıktı
- `Clip.kt` veri modeli, `TimelineAdapter.kt` zaman çizelgesi, `ExportHelper.kt` dışa aktarma

## Bilinen sınırlar (basit sürüm)
- Müzik önizlemede kabaca eşlenir (oynat/duraklat senkron, ileri-geri sarma senkronsuz); **dışa aktarılan videoda tam doğru** yerleşir.
- Yazı ve görsel katman ekranın ortasında durur ve videonun tamamı boyunca görünür.
- Klip başına ses seviyesi / sessize alma yok.
- Çok yüksek çözünürlüklü kaynaklarda cihazın kodek sınırına takılabilirsin; olursa daha düşük çözünürlüklü kaynak dene.

## Geliştirme fikirleri
- Katmanı sürükleyip konumlandırma (`StaticOverlaySettings` ile konum vermek)
- Klipler arası geçiş efektleri, hız değiştirme, filtreler
- Katmanların belirli zaman aralığında görünmesi
- Klip başına ses seviyesi
